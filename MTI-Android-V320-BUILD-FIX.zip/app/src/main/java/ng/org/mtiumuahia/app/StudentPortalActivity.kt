package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Space
import android.widget.ImageView
import android.widget.DatePicker
import android.app.DatePickerDialog
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.File
import java.io.InputStream
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.concurrent.Executors

class StudentPortalActivity : MtiBaseActivity() {
    private val green = Color.rgb(11, 61, 46)
    private val darkGreen = Color.rgb(6, 40, 30)
    private val cream = Color.rgb(246, 241, 230)
    private val gold = Color.rgb(184, 149, 74)
    private val ink = Color.rgb(23, 53, 44)
    private val white = Color.WHITE
    private val supabaseUrl = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabaseKey = "sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private val prefs by lazy { getSharedPreferences("mti_student_session", Context.MODE_PRIVATE) }
    private val executor = Executors.newSingleThreadExecutor()
    private var accessToken: String? = null
    private var userId: String? = null
    private var email: String? = null
    private var profile: JSONObject? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        // Security boundary: do not restore bearer/refresh tokens from plaintext app preferences.
        // A fresh authenticated session is required after process restart.
        accessToken = null
        userId = null
        email = null
        prefs.edit().clear().apply()
        showLogin()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun root(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cream) }
    private fun scroll(root: View): ScrollView = ScrollView(this).apply { isFillViewport = true; addView(root) }
    private fun text(value: String, size: Float = 15f, color: Int = ink, bold: Boolean = false): TextView = TextView(this).apply { text=value; textSize=size; setTextColor(color); setPadding(dp(20),dp(8),dp(20),dp(8)); if(bold) typeface=Typeface.DEFAULT_BOLD; setLineSpacing(0f,1.12f) }
    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply { text=label; isAllCaps=false; textSize=14f; setTextColor(white); backgroundTintList=ColorStateList.valueOf(green); setOnClickListener{onClick()}; layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(dp(20),dp(6),dp(20),dp(6))} }
    private fun field(hint: String, password: Boolean = false): EditText = EditText(this).apply { this.hint=hint; textSize=15f; setPadding(dp(16),dp(10),dp(16),dp(10)); layoutParams=LinearLayout.LayoutParams(-1,dp(58)).apply{setMargins(dp(20),dp(5),dp(20),dp(5))}; if(password) inputType=0x81 }
    private fun header(root: LinearLayout, kicker: String, heading: String, sub: String) { root.addView(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(green); setPadding(dp(20),dp(22),dp(20),dp(24)); addView(text(kicker,12f,gold,true)); addView(text(heading,27f,white,true)); addView(text(sub,14f,white,false)) }) }
    private fun message(root: LinearLayout, value: String, color: Int = ink) { root.addView(text(value,14f,color,false)) }

    private fun showLogin(messageText: String? = null) {
        val r=root(); header(r,"SECURE MTI ACCESS","Student Portal","Sign in to your authenticated MTI student workspace.")
        r.addView(text("Only officially activated MTI student accounts can access the Student Portal.",14f,ink))
        val emailField=field("Admitted email address"); val passwordField=field("Password",true); r.addView(emailField); r.addView(passwordField)
        val status=text(messageText ?: "",14f,ink); r.addView(status)
        r.addView(button("Sign in securely") {
            val e=emailField.text.toString().trim().lowercase(); val p=passwordField.text.toString();
            if(e.isBlank() || p.isBlank()){status.text="Enter your email address and password.";return@button}
            status.text="Authenticating…"; executor.execute { try { val obj=post("/auth/v1/token?grant_type=password", JSONObject().put("email",e).put("password",p)); val token=obj.optString("access_token"); val uid=obj.optJSONObject("user")?.optString("id"); if(token.isBlank()||uid.isNullOrBlank()) throw Exception("The MTI account session could not be established."); runOnUiThread{accessToken=token;userId=uid;email=e;loadProfile()} } catch(ex:Exception){runOnUiThread{status.text=ex.message ?: "Sign in failed. Please try again."}} }
        })
        r.addView(button("Activate an admitted student account") { showActivation() })
        r.addView(button("Open MTI Student Portal website") { openWebsite("/student-portal") })
        r.addView(text("Your MTI Registration Number and one-time activation token are issued by MTI after admission. Submitting an admission application does not itself create Student Portal access.",13f,ink))
        setContentView(scroll(r))
    }

    private fun showActivation() {
        val r=root(); header(r,"OFFICIAL MTI ADMISSION","Activate your account","Use the registration number and one-time token issued by MTI after admission.")
        val reg=field("MTI Registration Number"); val token=field("One-time Activation Token"); val emailField=field("Admitted email address"); val pw=field("Create password",true); val confirm=field("Confirm password",true)
        r.addView(reg);r.addView(token);r.addView(emailField);r.addView(pw);r.addView(confirm); val status=text("",14f,ink);r.addView(status)
        r.addView(button("Verify & activate") { val body=JSONObject().put("registration_number",reg.text.toString().trim()).put("activation_token",token.text.toString().trim()).put("email",emailField.text.toString().trim().lowercase()).put("password",pw.text.toString()); if(pw.text.toString()!=confirm.text.toString()){status.text="Passwords do not match.";return@button}; status.text="Verifying admission…"; executor.execute{try{val result=post("/functions/v1/activate-student-v137",body);runOnUiThread{status.text=result.optString("message","Admission verified. Your account has been activated. Sign in with your admitted email and new password.")}}catch(ex:Exception){runOnUiThread{status.text=ex.message ?: "Activation failed."}}} })
        r.addView(button("Back to Sign in") { showLogin() })
        r.addView(text("The activation token does not expire merely because time passes; it becomes invalid after successful use, according to the existing MTI portal workflow.",13f,ink))
        setContentView(scroll(r))
    }

    private fun revokeSession(token: String) {
        try {
            val c = URL("$supabaseUrl/auth/v1/logout").openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 10000
            c.readTimeout = 10000
            c.setRequestProperty("apikey", supabaseKey)
            c.setRequestProperty("Authorization", "Bearer $token")
            c.connect()
            c.inputStream?.close()
            c.disconnect()
        } catch (_: Exception) {
            // Local credentials are already discarded; server-side logout is best-effort.
        }
    }

    private fun loadProfile() {
        val r=root(); header(r,"STUDENT ACADEMIC WORKSPACE","Loading your portal…","Checking your authenticated MTI student profile."); r.addView(text("Please wait while your secure profile is loaded.",14f,ink)); setContentView(scroll(r))
        executor.execute { try { val id=userId ?: throw Exception("No authenticated MTI user was found."); val data=get("/rest/v1/student_profiles?select=*&user_id=eq.${URLEncoder.encode(id,"UTF-8")}&limit=1"); val arr=JSONArray(data); if(arr.length()==0) throw Exception("No MTI student profile is linked to this account."); profile=arr.getJSONObject(0); runOnUiThread{showDashboard()} } catch(ex:Exception){runOnUiThread{showLogin("Student profile could not be loaded: ${ex.message ?: "Unknown error"}")}} }
    }

    private data class ActionItem(val icon: String, val title: String, val action: () -> Unit)
    private fun portalHero(kicker:String, heading:String, sub:String): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(dp(20),dp(22),dp(20),dp(22))
        background=android.graphics.drawable.GradientDrawable().apply { setColor(darkGreen); cornerRadius=dp(24).toFloat() }
        elevation=dp(5).toFloat()
        addView(text(kicker,11f,gold,true).apply{setPadding(0,0,0,dp(5))})
        addView(text(heading,26f,white,true).apply{setPadding(0,0,0,dp(7))})
        addView(text(sub,14f,white).apply{setPadding(0,0,0,0)})
    }
    private fun actionTile(icon:String,titleText:String,sub:String,click:()->Unit):LinearLayout=LinearLayout(this).apply{
        orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(13),dp(14),dp(13));isClickable=true
        background=android.graphics.drawable.GradientDrawable().apply{setColor(white);cornerRadius=dp(18).toFloat();setStroke(dp(1),Color.rgb(225,221,211))}
        elevation=dp(2).toFloat();addView(text(icon,18f,gold,true).apply{setPadding(0,0,0,dp(5))});addView(text(titleText,15f,green,true).apply{setPadding(0,0,0,dp(3))});addView(text(sub,12f,Color.rgb(91,105,99)).apply{setPadding(0,0,0,0)});setOnTouchListener { view,event -> when(event.action){android.view.MotionEvent.ACTION_DOWN -> view.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start();android.view.MotionEvent.ACTION_UP,android.view.MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(110).start()};false };setOnClickListener{click()}
    }
    private fun addActionGrid(parent:LinearLayout,items:List<ActionItem>){
        items.chunked(2).forEach{rowItems->val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};rowItems.forEach{item->row.addView(actionTile(item.icon,item.title,"Open workspace",item.action),LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(dp(3),dp(4),dp(3),dp(4)})};if(rowItems.size==1)row.addView(Space(this),LinearLayout.LayoutParams(0,1,1f));parent.addView(row)}
    }
    private fun showDashboard() {
        val p=profile ?: JSONObject(); val display=listOf(p.optString("first_name"),p.optString("middle_name"),p.optString("last_name")).filter{it.isNotBlank()}.joinToString(" ").ifBlank{p.optString("full_name").ifBlank{"MTI Student"}}
        val r=root();r.setPadding(dp(14),dp(14),dp(14),dp(24));r.addView(portalHero("MTI STUDENT PORTAL","Welcome, $display","Your academic life, records and campus services in one place."))
        r.addView(text("YOUR ACADEMIC PROFILE",11f,gold,true).apply{setPadding(dp(4),dp(20),dp(4),dp(7))})
        val identity=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(15),dp(13),dp(15),dp(13));background=android.graphics.drawable.GradientDrawable().apply{setColor(white);cornerRadius=dp(18).toFloat()};elevation=dp(2).toFloat()}
        val left=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};left.addView(text(p.optString("student_number").ifBlank{"Student number pending"},16f,green,true).apply{setPadding(0,0,0,dp(4))});left.addView(text(p.optString("programme").ifBlank{"Programme not available"},13f,ink).apply{setPadding(0,0,0,dp(3))});left.addView(text("${p.optString("level").ifBlank{"Level —"}}  ·  ${p.optString("section").ifBlank{"Section —"}}",12f,Color.rgb(91,105,99)).apply{setPadding(0,0,0,0)});identity.addView(left,LinearLayout.LayoutParams(0,-2,1f));identity.addView(text("MTI",13f,gold,true).apply{gravity=Gravity.CENTER;setPadding(dp(12),dp(8),dp(4),dp(8))});r.addView(identity)
        r.addView(text("STUDENT SERVICES",11f,gold,true).apply{setPadding(dp(4),dp(22),dp(4),dp(7))})
        addActionGrid(r,listOf(
            ActionItem("◉", "My Profile") {showBiodataEditor()},ActionItem("▣", "My Courses") {showMyCourses()},ActionItem("✓", "Course Registration") {showCourseRegistration()},ActionItem("▤", "Results & Transcript") {showResults()},ActionItem("₦", "Fees & Payments") {showFeesPayments()},ActionItem("▥", "Learning Materials") {showLearningMaterials()},ActionItem("◷", "Class Schedule") {showClassSchedule()},ActionItem("◎", "Online Classroom") {showOnlineClassroom()},ActionItem("⌂", "Hostel") {showHostel()},ActionItem("✦", "Notice Board") {showNoticeBoard()}
        ))
        r.addView(text("QUICK ACCESS",11f,gold,true).apply{setPadding(dp(4),dp(20),dp(4),dp(7))});r.addView(button("Open Full Student Portal"){openWebsite("/student-portal")});r.addView(button("Sign out"){val token=accessToken;accessToken=null;userId=null;email=null;profile=null;prefs.edit().clear().apply();if(!token.isNullOrBlank())executor.execute{revokeSession(token)};showLogin("You have been signed out. Please sign in again.")});setContentView(scroll(r))
    }

    private fun showMyCourses() {
        val r = root(); header(r, "ACADEMIC COURSES", "My Courses", "Your registered MTI courses from the existing academic record.")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(text("REGISTERED COURSES", 12f, gold, true)); r.addView(box)
        r.addView(button("Course Registration") { showCourseRegistration() })
        r.addView(button("Registration Slip") { showRegistrationSlip() })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val id = userId ?: throw Exception("Your authenticated student session is missing.")
                val data = get("/rest/v1/student_courses?select=*&student_id=eq.${URLEncoder.encode(profile?.optString("id") ?: id, "UTF-8")}&order=created_at.desc&limit=300")
                val arr = JSONArray(data)
                runOnUiThread {
                    box.removeAllViews()
                    if (arr.length() == 0) { box.addView(card("No registered courses", "No registered courses were found in your current academic record.")) }
                    for (i in 0 until arr.length()) {
                        val x = arr.getJSONObject(i)
                        val code = x.optString("course_code").ifBlank { x.optString("code") }.ifBlank { "Course" }
                        val title = x.optString("course_title").ifBlank { x.optString("title") }.ifBlank { "—" }
                        val details = "${x.optString("level").ifBlank { profile?.optString("level").orEmpty().ifBlank { "—" } }} · ${x.optString("semester").ifBlank { "—" }} · ${x.optString("credit_load").ifBlank { x.optString("credits").ifBlank { "—" } }} units"
                        box.addView(card(code, "$title\n$details"))
                    }
                }
            } catch (ex: Exception) { runOnUiThread { box.removeAllViews(); box.addView(text(ex.message ?: "Unable to load your courses.", 14f, ink)) } }
        }
    }

    private fun showCourseRegistration() {
        val r = root(); header(r, "COURSE REGISTRATION", "Register Your Courses", "Select courses available under the MTI academic registration window.")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = text("Loading available courses…", 14f, ink)
        r.addView(status); r.addView(box)
        lateinit var register: Button
        register = button("Register Selected Courses") { registerSelectedCourses(box, status, register) }
        register.isEnabled = false
        r.addView(register)
        r.addView(button("Refresh") { showCourseRegistration() })
        r.addView(button("My Courses") { showMyCourses() })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val raw = postRaw("/rest/v1/rpc/mti_get_my_course_registration_v112", JSONObject())
                val rows = JSONArray(raw)
                runOnUiThread {
                    box.removeAllViews()
                    var available = 0
                    var currentSession = ""
                    var currentSemester = ""
                    for (i in 0 until rows.length()) {
                        val x = rows.getJSONObject(i)
                        if (x.optBoolean("is_current")) { currentSession = x.optString("academic_session"); currentSemester = x.optString("semester") }
                        val registered = x.optString("registration_status").equals("registered", true)
                        val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(white) }
                        val label = "${x.optString("course_code").ifBlank { "Course" }} — ${x.optString("course_title").ifBlank { "Untitled course" }}"
                        val details = "${x.optString("level").ifBlank { "—" }} · ${x.optString("semester").ifBlank { "—" }} · ${x.optString("credit_load").ifBlank { "0" }} units"
                        val cb = android.widget.CheckBox(this).apply { text = "$label\n$details"; textSize = 14f; setTextColor(ink); isChecked = registered; isEnabled = !registered; tag = x.optString("course_id") }
                        row.addView(cb); box.addView(row)
                        if (!registered) available++
                    }
                    if (rows.length() == 0) box.addView(card("No courses available", "MTI has not returned any courses for your account."))
                    status.text = if (currentSession.isNotBlank()) "$currentSession · $currentSemester" else if (available == 0) "No new courses are available for registration." else "Select available courses below."
                    register.isEnabled = available > 0 && currentSession.isNotBlank() && currentSemester.isNotBlank()
                    register.tag = JSONObject().put("session", currentSession).put("semester", currentSemester).toString()
                }
            } catch (ex: Exception) { runOnUiThread { status.text = ex.message ?: "Unable to load course registration."; register.isEnabled = false } }
        }
    }

    private fun registerSelectedCourses(box: LinearLayout, status: TextView, register: Button) {
        val meta = try { JSONObject(register.tag?.toString() ?: "{}") } catch (_: Exception) { JSONObject() }
        val session = meta.optString("session"); val semester = meta.optString("semester")
        val selected = mutableListOf<String>()
        for (i in 0 until box.childCount) {
            val row = box.getChildAt(i) as? LinearLayout ?: continue
            val cb = row.getChildAt(0) as? android.widget.CheckBox ?: continue
            if (cb.isChecked && cb.isEnabled && cb.tag?.toString()?.isNotBlank() == true) selected.add(cb.tag.toString())
        }
        if (selected.isEmpty()) { status.text = "Select at least one available course."; return }
        if (session.isBlank() || semester.isBlank()) { status.text = "There is no active registration window."; return }
        register.isEnabled = false; register.text = "Registering…"; status.text = "Submitting your course registration…"
        executor.execute {
            try {
                selected.forEach { id -> postRaw("/rest/v1/rpc/mti_register_student_course_v87", JSONObject().put("p_course_id", id).put("p_academic_session", session).put("p_semester", semester)) }
                runOnUiThread { status.text = "✓ Course registration completed successfully."; register.text = "Registration Saved"; register.isEnabled = false; android.os.Handler(mainLooper).postDelayed({ showCourseRegistration() }, 700) }
            } catch (ex: Exception) { runOnUiThread { status.text = ex.message ?: "Course registration failed."; register.isEnabled = true; register.text = "Register Selected Courses" } }
        }
    }

    private fun showResults() {
        val r = root()
        header(r, "ACADEMIC RECORD", "Results & Academic Performance", "Only published MTI results are displayed in this secure student view.")
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val table = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(summary)
        r.addView(text("PUBLISHED RESULTS", 12f, gold, true))
        r.addView(table)
        r.addView(button("Official Transcript") { openWebsite("/official-transcript") })
        r.addView(button("Open Full Student Portal") { openWebsite("/student-portal#results") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        summary.addView(text("Loading your published academic record…", 14f, ink))
        setContentView(scroll(r))
        executor.execute {
            try {
                val sid = profile?.optString("id")?.takeIf { it.isNotBlank() } ?: throw Exception("No MTI student profile is linked to this account.")
                val resultUrl = "/rest/v1/student_results?select=*&student_id=eq.${URLEncoder.encode(sid, "UTF-8")}&status=eq.published&order=created_at.desc&limit=500"
                val results = JSONArray(get(resultUrl))
                var units = 0.0
                var weighted = 0.0
                var scoreTotal = 0.0
                var scoreCount = 0
                val gradeCounts = mutableMapOf("A" to 0, "B" to 0, "C" to 0, "D" to 0, "E" to 0, "F" to 0)
                for (i in 0 until results.length()) {
                    val x = results.getJSONObject(i)
                    val u = x.optDouble("credit_load", 0.0)
                    val gp = if (x.has("grade_points") && !x.isNull("grade_points")) x.optDouble("grade_points", 0.0) else gradePoint(x.optString("grade"))
                    units += u
                    weighted += gp * u
                    if (x.has("score") && !x.isNull("score")) { scoreTotal += x.optDouble("score", 0.0); scoreCount++ }
                    val g = x.optString("grade").uppercase()
                    if (gradeCounts.containsKey(g)) gradeCounts[g] = gradeCounts.getValue(g) + 1
                }
                val cgpa = if (units > 0) String.format(java.util.Locale.US, "%.2f", weighted / units) else "—"
                val average = if (scoreCount > 0) String.format(java.util.Locale.US, "%.2f", scoreTotal / scoreCount) else "—"
                runOnUiThread {
                    summary.removeAllViews()
                    summary.addView(card("CGPA", cgpa))
                    summary.addView(card("Credit Units", if (units == units.toInt().toDouble()) units.toInt().toString() else String.format(java.util.Locale.US, "%.1f", units)))
                    summary.addView(card("Average Score", average))
                    summary.addView(card("Published Courses", results.length().toString()))
                    summary.addView(text("Grade distribution: A ${gradeCounts["A"]} · B ${gradeCounts["B"]} · C ${gradeCounts["C"]} · D ${gradeCounts["D"]} · E ${gradeCounts["E"]} · F ${gradeCounts["F"]}", 13f, ink))
                    table.removeAllViews()
                    if (results.length() == 0) {
                        table.addView(card("No published results", "No published results are currently available. Draft or unapproved results are not shown."))
                    } else {
                        for (i in 0 until results.length()) {
                            val x = results.getJSONObject(i)
                            val code = x.optString("course_code").ifBlank { "Course" }
                            val title = x.optString("course_title").ifBlank { "—" }
                            val unitsText = x.optString("credit_load").ifBlank { "0" }
                            val session = x.optString("academic_session").ifBlank { x.optString("session") }.ifBlank { "—" }
                            val semester = x.optString("semester").ifBlank { "—" }
                            val score = if (x.has("score") && !x.isNull("score")) x.optString("score") else "—"
                            val grade = x.optString("grade").ifBlank { "—" }
                            val points = if (x.has("grade_points") && !x.isNull("grade_points")) x.optString("grade_points") else "—"
                            val remark = x.optString("remark").ifBlank { "—" }
                            table.addView(card(code, "$title\n$session · $semester\n$unitsText unit(s) · Score: $score · Grade: $grade · Points: $points\nRemark: $remark"))
                        }
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    summary.removeAllViews()
                    table.removeAllViews()
                    summary.addView(text("Unable to load your academic record: ${ex.message ?: "Unknown error"}", 14f, ink))
                }
            }
        }
    }

    private fun gradePoint(grade: String): Double = when (grade.uppercase()) {
        "A" -> 5.0
        "B" -> 4.0
        "C" -> 3.0
        "D" -> 2.0
        "E" -> 1.0
        else -> 0.0
    }

    private fun showRegistrationSlip() {
        val r = root(); header(r, "REGISTRATION SLIP", "Official Course Registration Slip", "Your current registered courses from the MTI academic registration record.")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(box); r.addView(button("My Courses") { showMyCourses() }); r.addView(button("Course Registration") { showCourseRegistration() }); r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val raw = postRaw("/rest/v1/rpc/mti_get_my_course_registration_v112", JSONObject())
                val rows = JSONArray(raw); var count = 0; var units = 0; var sessionName = "—"; var semester = "—"
                runOnUiThread {
                    box.removeAllViews()
                    for (i in 0 until rows.length()) {
                        val x = rows.getJSONObject(i)
                        if (!x.optString("registration_status").equals("registered", true)) continue
                        count++; units += x.optInt("credit_load", 0); if (x.optBoolean("is_current")) { sessionName=x.optString("academic_session").ifBlank { "—" }; semester=x.optString("semester").ifBlank { "—" } }
                        box.addView(card(x.optString("course_code").ifBlank { "Course" }, "${x.optString("course_title").ifBlank { "—" }}\n${x.optString("credit_load").ifBlank { "0" }} credit unit(s) · ${x.optString("semester").ifBlank { "—" }}"))
                    }
                    box.addView(text("Session: $sessionName\nSemester: $semester\nTotal registered courses: $count\nTotal credit load: $units", 14f, ink, true))
                    if (count == 0) box.addView(card("No registered courses", "No registered courses were found for the current registration record."))
                }
            } catch (ex: Exception) { runOnUiThread { box.removeAllViews(); box.addView(text(ex.message ?: "Unable to load registration slip.", 14f, ink)) } }
        }
    }

    private var pendingEvidencePaymentId: String? = null

    private fun showFeesPayments(messageText: String? = null) {
        val r = root()
        header(r, "SCHOOL FEES", "Fees & Payments", "Track your MTI invoices, payment history, balances and official receipts.")
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val invoicesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val paymentsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = text(messageText ?: "Loading your finance records…", 14f, ink)
        r.addView(stats)
        r.addView(text("MY INVOICES", 12f, gold, true))
        r.addView(invoicesBox)
        r.addView(text("PAYMENT HISTORY", 12f, gold, true))
        r.addView(paymentsBox)
        r.addView(text("FINANCE GUIDANCE", 12f, gold, true))
        r.addView(card("Keep every MTI payment record", "Use the receipt action for an official payment record. For a pending payment, you may submit transaction evidence for Finance staff to review."))
        r.addView(status)
        r.addView(button("Open Full MTI Finance Centre") { openWebsite("/student-portal#fees") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val uid = userId ?: throw Exception("Your authenticated student session is missing.")
                val invoiceRaw = get("/rest/v1/fee_invoices?select=*&user_id=eq.${URLEncoder.encode(uid, "UTF-8")}&order=created_at.desc&limit=300")
                val paymentStudentId = profile?.optString("id")?.takeIf { it.isNotBlank() }
                val paymentFilter = if (paymentStudentId != null) "student_id=eq.${URLEncoder.encode(paymentStudentId, "UTF-8")}" else "user_id=eq.${URLEncoder.encode(uid, "UTF-8")}"
                val paymentRaw = get("/rest/v1/student_payments?select=*&$paymentFilter&order=created_at.desc&limit=300")
                val invoices = JSONArray(invoiceRaw)
                val payments = JSONArray(paymentRaw)
                var totalInvoiced = 0.0
                var totalPaid = 0.0
                for (i in 0 until invoices.length()) totalInvoiced += invoices.getJSONObject(i).optDouble("amount", 0.0)
                for (i in 0 until payments.length()) {
                    val x = payments.getJSONObject(i)
                    if (x.optString("status").lowercase() in listOf("paid", "verified")) totalPaid += x.optDouble("amount", 0.0)
                }
                val balance = kotlin.math.max(0.0, totalInvoiced - totalPaid)
                runOnUiThread {
                    status.text = ""
                    stats.removeAllViews()
                    stats.addView(card("Total Invoiced", money(totalInvoiced)))
                    stats.addView(card("Total Paid", money(totalPaid)))
                    stats.addView(card("Outstanding", money(balance)))
                    stats.addView(card("Invoice Records", invoices.length().toString()))
                    invoicesBox.removeAllViews()
                    if (invoices.length() == 0) invoicesBox.addView(card("No invoices found", "No fee invoice is currently linked to your MTI account."))
                    for (i in 0 until invoices.length()) {
                        val x = invoices.getJSONObject(i)
                        val no = x.optString("invoice_no").ifBlank { "Invoice" }
                        val type = x.optString("fee_type").ifBlank { "Fee" }
                        val amount = money(x.optDouble("amount", 0.0))
                        val paid = money(x.optDouble("amount_paid", 0.0))
                        val st = x.optString("status").ifBlank { "Unpaid" }
                        val due = x.optString("due_date").ifBlank { "—" }
                        invoicesBox.addView(card(no, "$type\nAmount: $amount · Paid: $paid\nStatus: $st · Due: $due"))
                    }
                    paymentsBox.removeAllViews()
                    if (payments.length() == 0) paymentsBox.addView(card("No payment history", "No payment records were found for your account."))
                    for (i in 0 until payments.length()) {
                        val x = payments.getJSONObject(i)
                        val fee = x.optString("fee_type").ifBlank { "Payment" }
                        val amount = money(x.optDouble("amount", 0.0))
                        val method = x.optString("payment_method").ifBlank { "—" }
                        val ref = x.optString("payment_reference").ifBlank { x.optString("reference") }.ifBlank { "—" }
                        val st = x.optString("status").ifBlank { "pending" }
                        val date = x.optString("created_at").ifBlank { x.optString("payment_date") }.ifBlank { "—" }
                        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(white); setPadding(dp(20), dp(10), dp(20), dp(10)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(20), dp(5), dp(20), dp(5)) } }
                        box.addView(text("$fee\n$amount · $method\nReference: $ref\nStatus: $st\nDate: $date", 14f, ink))
                        val receiptId = x.optString("id")
                        box.addView(button("View Receipt") { showPaymentReceipt(x) })
                        if (st.lowercase() == "pending") box.addView(button("Submit Payment Evidence") { choosePaymentEvidence(receiptId) })
                        paymentsBox.addView(box)
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    status.text = "Unable to load your finance records: ${ex.message ?: "Unknown error"}"
                }
            }
        }
    }

    private fun money(amount: Double): String = "₦" + String.format(java.util.Locale.US, "%,.2f", amount)

    private fun showPaymentReceipt(payment: JSONObject) {
        val r = root()
        val no = payment.optString("receipt_no").ifBlank { payment.optString("receipt_number") }.ifBlank { "Payment Receipt" }
        header(r, "MTI FINANCE", "Payment Receipt", no)
        val studentName = listOf(profile?.optString("first_name"), profile?.optString("middle_name"), profile?.optString("last_name")).filter { !it.isNullOrBlank() }.joinToString(" ").ifBlank { "MTI Student" }
        r.addView(card("Student", studentName))
        r.addView(card("Student Number", profile?.optString("student_number")?.ifBlank { "—" } ?: "—"))
        r.addView(card("Fee Type", payment.optString("fee_type").ifBlank { "—" }))
        r.addView(card("Amount", money(payment.optDouble("amount", 0.0))))
        r.addView(card("Payment Method", payment.optString("payment_method").ifBlank { "—" }))
        r.addView(card("Payment Reference", payment.optString("payment_reference").ifBlank { payment.optString("reference") }.ifBlank { "—" }))
        r.addView(card("Status", payment.optString("status").ifBlank { "—" }))
        r.addView(card("Date", payment.optString("created_at").ifBlank { payment.optString("payment_date") }.ifBlank { "—" }))
        r.addView(text("This native receipt view reflects the payment record currently held by MTI. For printing or PDF saving, use the full MTI Finance Centre.", 13f, ink))
        r.addView(button("Open Printable Receipt") { openWebsite("/student-portal#fees") })
        r.addView(button("Back to Fees & Payments") { showFeesPayments() })
        setContentView(scroll(r))
    }

    private fun choosePaymentEvidence(paymentId: String) {
        if (paymentId.isBlank()) return
        pendingEvidencePaymentId = paymentId
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "image/png", "image/webp", "application/pdf"))
        }
        startActivityForResult(intent, 2333)
    }

    private fun uploadPaymentEvidence(uri: Uri, paymentId: String) {
        executor.execute {
            try {
                val uid = userId ?: throw Exception("Your authenticated student session is missing.")
                val mime = contentResolver.getType(uri) ?: "application/octet-stream"
                if (mime !in listOf("image/jpeg", "image/png", "image/webp", "application/pdf")) throw Exception("Evidence must be JPG, PNG, WebP or PDF.")
                val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw Exception("Unable to read the selected evidence file.")
                if (bytes.size > 5 * 1024 * 1024) throw Exception("Evidence file must not exceed 5 MB.")
                val original = (uri.lastPathSegment ?: "evidence").substringAfterLast('/').replace(Regex("[^a-zA-Z0-9._-]"), "_")
                val path = "$uid/$paymentId-${System.currentTimeMillis()}-$original"
                val bucket = URLEncoder.encode("Mti Payment Evidence", "UTF-8").replace("+", "%20")
                uploadBytes("/storage/v1/object/$bucket/${URLEncoder.encode(path, "UTF-8").replace("+", "%20")}", bytes, mime)
                val body = JSONObject().put("payment_id", paymentId).put("user_id", uid).put("file_name", original).put("storage_path", path).put("status", "pending")
                postRaw("/rest/v1/payment_evidence", body)
                runOnUiThread { showFeesPayments("✓ Payment evidence submitted successfully. Finance staff can now review it.") }
            } catch (ex: Exception) {
                runOnUiThread { showFeesPayments("Unable to submit payment evidence: ${ex.message ?: "Unknown error"}") }
            }
        }
    }

    private fun showLearningMaterials(messageText: String? = null) {
        val r = root()
        header(r, "LEARNING & LIBRARY", "Learning Materials", "Access published resources from lecturers assigned to your registered courses.")
        val status = text(messageText ?: "Loading your learning resources…", 14f, ink)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(status)
        r.addView(text("MY COURSE RESOURCES", 12f, gold, true))
        r.addView(content)
        r.addView(button("Open MTI Digital Library") { openWebsite("/library") })
        r.addView(button("Open Full Learning Materials") { openWebsite("/student-portal#materials") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val sid = profile?.optString("id")?.takeIf { it.isNotBlank() } ?: throw Exception("No MTI student profile is linked to this account.")
                val courses = JSONArray(get("/rest/v1/student_courses?select=*&student_id=eq.${URLEncoder.encode(sid,"UTF-8")}&order=created_at.desc&limit=300"))
                val ids = mutableSetOf<String>()
                val labels = mutableMapOf<String,String>()
                for (i in 0 until courses.length()) {
                    val c = courses.getJSONObject(i)
                    val id = c.optString("course_id").ifBlank { c.optString("id") }
                    if (id.isNotBlank()) { ids.add(id); labels[id] = listOf(c.optString("course_code"), c.optString("course_title")).filter { it.isNotBlank() }.joinToString(" — ") }
                }
                val materials = JSONArray(get("/rest/v1/lecturer_materials?select=*&published=eq.true&order=created_at.desc&limit=300"))
                val mine = mutableListOf<JSONObject>()
                for (i in 0 until materials.length()) {
                    val m = materials.getJSONObject(i)
                    val cid = m.optString("course_id")
                    if (cid.isNotBlank() && ids.contains(cid)) mine.add(m)
                }
                runOnUiThread {
                    content.removeAllViews()
                    status.text = if (mine.isEmpty()) "No published resources are currently available for your registered courses." else "${mine.size} published resource${if (mine.size == 1) "" else "s"} available."
                    if (mine.isEmpty()) {
                        content.addView(card("No resources yet", "Lecturers can publish notes, documents, slides, links, audio and video resources for your registered courses."))
                    } else {
                        mine.forEach { m ->
                            val title = m.optString("title").ifBlank { "Learning Resource" }
                            val type = m.optString("material_type").ifBlank { "Resource" }
                            val desc = m.optString("description").ifBlank { "Published learning resource for your course." }
                            val cid = m.optString("course_id")
                            val course = labels[cid].orEmpty().ifBlank { m.optString("course_code").ifBlank { "Registered Course" } }
                            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(white) }
                            box.addView(text(type.uppercase(), 11f, gold, true))
                            box.addView(text(title, 18f, ink, true))
                            box.addView(text(course, 13f, green, true))
                            box.addView(text(desc, 13f, ink))
                            val url = m.optString("file_url").ifBlank { m.optString("file_path") }.ifBlank { m.optString("url") }
                            if (url.isNotBlank()) box.addView(button("Open Resource") { openResource(url) }) else box.addView(text("No file or link is attached to this resource.", 12f, ink))
                            content.addView(box)
                        }
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread { status.text = ex.message ?: "Unable to load learning materials."; content.removeAllViews(); content.addView(card("Learning resources unavailable", "Please try again or open the full MTI Student Portal.")) }
            }
        }
    }

    private fun openResource(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { }
    }

    private fun showClassSchedule(messageText: String? = null) {
        val r = root()
        header(r, "ACADEMIC TIMETABLE", "Class Schedule", "View the published weekly timetable for your registered MTI courses.")
        val status = text(messageText ?: "Loading your timetable…", 14f, ink)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(status)
        r.addView(text("TODAY", 12f, gold, true))
        val todayBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(todayBox)
        r.addView(text("WEEKLY TIMETABLE", 12f, gold, true))
        r.addView(content)
        r.addView(button("Open Full MTI Timetable") { openWebsite("/student-portal#schedule") })
        r.addView(button("Attendance") { showAttendance() })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val sid = profile?.optString("id")?.takeIf { it.isNotBlank() } ?: throw Exception("No MTI student profile is linked to this account.")
                val courses = JSONArray(get("/rest/v1/student_courses?select=*&student_id=eq.${URLEncoder.encode(sid, "UTF-8")}&order=created_at.desc&limit=300"))
                val ids = mutableSetOf<String>()
                val semesters = mutableMapOf<String,String>()
                for (i in 0 until courses.length()) {
                    val c = courses.getJSONObject(i)
                    val id = c.optString("course_id").ifBlank { c.optString("id") }
                    if (id.isNotBlank()) { ids.add(id); semesters[id] = normalizeSemester(c.optString("semester")) }
                }
                val schedules = JSONArray(get("/rest/v1/academic_class_schedule?select=*&active=eq.true&order=day_of_week.asc,start_time.asc&limit=300"))
                val mine = mutableListOf<JSONObject>()
                for (i in 0 until schedules.length()) {
                    val x = schedules.getJSONObject(i)
                    val cid = x.optString("course_id")
                    if (cid.isBlank() || ids.contains(cid)) {
                        val a = normalizeSemester(x.optString("semester")); val b = semesters[cid].orEmpty()
                        if (a.isBlank() || b.isBlank() || a == b) mine.add(x)
                    }
                }
                runOnUiThread {
                    todayBox.removeAllViews(); content.removeAllViews()
                    status.text = if (mine.isEmpty()) "No published timetable entries were found for your registered courses." else "${mine.size} scheduled class${if (mine.size == 1) "" else "es"} found."
                    val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK).let { if (it == Calendar.SUNDAY) 7 else it - 1 }
                    val todayRows = mine.filter { it.optInt("day_of_week", 0) == today }.sortedBy { it.optString("start_time") }
                    if (todayRows.isEmpty()) todayBox.addView(card("No class today", "No class is currently published for you today."))
                    else todayRows.forEach { x ->
                        val code = x.optString("course_code").ifBlank { x.optString("course_title") }.ifBlank { "Class" }
                        val detail = "${formatTime(x.optString("start_time"))} – ${formatTime(x.optString("end_time"))} · ${x.optString("venue").ifBlank { "Venue pending" }}"
                        todayBox.addView(card(code, detail))
                    }
                    if (mine.isEmpty()) content.addView(card("No timetable yet", "MTI academic administration has not published timetable entries matching your registered courses."))
                    else {
                        val days = arrayOf("", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")
                        mine.forEach { x ->
                            val day = days.getOrElse(x.optInt("day_of_week", 0)) { x.optString("day_of_week").ifBlank { "Day pending" } }
                            val course = x.optString("course_code").ifBlank { x.optString("course_title") }.ifBlank { "Course" }
                            val title = x.optString("course_title")
                            val details = buildString {
                                append(day); append("\n")
                                append(formatTime(x.optString("start_time"))); append(" – "); append(formatTime(x.optString("end_time")))
                                append("\nVenue: "); append(x.optString("venue").ifBlank { "—" })
                                append("\nMode: "); append(x.optString("mode").ifBlank { "Physical" })
                                if (x.optString("lecturer_name").isNotBlank()) { append("\nLecturer: "); append(x.optString("lecturer_name")) }
                                if (title.isNotBlank() && title != course) { append("\n"); append(title) }
                            }
                            content.addView(card(course, details))
                        }
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread { status.text = ex.message ?: "Unable to load the timetable."; todayBox.removeAllViews(); content.removeAllViews(); content.addView(card("Timetable unavailable", "Please try again or open the full MTI Student Portal.")) }
            }
        }
    }

    private fun showOnlineClassroom(messageText: String? = null) {
        val r = root()
        header(r, "MTI DIGITAL CAMPUS", "Online Classroom", "Join scheduled virtual classes and academic conference sessions using your existing MTI account.")
        val status = text(messageText ?: "Loading your virtual sessions…", 14f, ink)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(status)
        r.addView(text("UPCOMING & RECENT SESSIONS", 12f, gold, true))
        r.addView(content)
        r.addView(button("Open Full MTI Online Classroom") { openWebsite("/online-classroom") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val sid = profile?.optString("id")?.takeIf { it.isNotBlank() } ?: throw Exception("No MTI student profile is linked to this account.")
                val courses = JSONArray(get("/rest/v1/student_courses?select=*&student_id=eq.${URLEncoder.encode(sid, "UTF-8")}&order=created_at.desc&limit=300"))
                val ids = mutableSetOf<String>()
                for (i in 0 until courses.length()) {
                    val c = courses.getJSONObject(i)
                    val id = c.optString("course_id").ifBlank { c.optString("id") }
                    if (id.isNotBlank()) ids.add(id)
                }
                val sessions = JSONArray(get("/rest/v1/online_classes?select=*&order=scheduled_start.asc&limit=300"))
                val mine = mutableListOf<JSONObject>()
                for (i in 0 until sessions.length()) {
                    val x = sessions.getJSONObject(i)
                    val cid = x.optString("course_id")
                    if (cid.isBlank() || ids.contains(cid)) mine.add(x)
                }
                runOnUiThread {
                    content.removeAllViews()
                    status.text = if (mine.isEmpty()) "No virtual sessions are currently available for your registered courses." else "${mine.size} virtual session${if (mine.size == 1) "" else "s"} available."
                    if (mine.isEmpty()) {
                        content.addView(card("No virtual sessions yet", "Your scheduled MTI online classes and conference sessions will appear here when they are published."))
                    } else {
                        mine.forEach { x ->
                            val type = if (x.optString("session_type").equals("conference", true)) "CONFERENCE / GROUP SESSION" else "LIVE CLASS"
                            val title = x.optString("title").ifBlank { "MTI Online Session" }
                            val course = listOf(x.optString("course_code"), x.optString("course_title")).filter { it.isNotBlank() }.joinToString(" — ").ifBlank { "Academic session" }
                            val schedule = buildString {
                                append(formatDateTime(x.optString("scheduled_start")))
                                if (x.optString("scheduled_end").isNotBlank()) { append(" – "); append(formatClock(x.optString("scheduled_end"))) }
                                if (x.optString("status").isNotBlank()) { append("\nStatus: "); append(x.optString("status")) }
                                if (x.optString("meeting_provider").isNotBlank()) { append("\nProvider: "); append(x.optString("meeting_provider")) }
                            }
                            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)); setBackgroundColor(white) }
                            box.addView(text(type, 11f, gold, true))
                            box.addView(text(title, 18f, ink, true))
                            box.addView(text(course, 13f, green, true))
                            box.addView(text(schedule, 13f, ink))
                            val description = x.optString("description")
                            if (description.isNotBlank()) box.addView(text(description, 13f, ink))
                            val url = x.optString("meeting_url").ifBlank { x.optString("meeting_link") }.ifBlank { x.optString("join_url") }.ifBlank { x.optString("meeting_room_url") }.ifBlank { x.optString("url") }
                            if (url.isNotBlank()) box.addView(button("Join Session") { openResource(url) })
                            else box.addView(text("Meeting link pending. Open the full classroom for the latest session information.", 12f, ink))
                            content.addView(box)
                        }
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread { status.text = ex.message ?: "Unable to load online sessions."; content.removeAllViews(); content.addView(card("Online classroom unavailable", "Please try again or open the full MTI Online Classroom.")) }
            }
        }
    }

    private fun showNoticeBoard(messageText: String? = null) {
        val r = root()
        header(r, "OFFICIAL COMMUNICATIONS", "Student Notice Board", "Stay informed about MTI academic, administrative and student announcements.")
        val status = text(messageText ?: "Loading MTI notices…", 14f, ink)
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val filter = EditText(this).apply {
            hint = "Search notices…"
            textSize = 14f
            setSingleLine(true)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(dp(20), dp(6), dp(20), dp(6)) }
        }
        val filterButton = button("Show Unread Only") { }
        var unreadOnly = false
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(status)
        r.addView(summary)
        r.addView(filter)
        r.addView(filterButton)
        r.addView(text("MTI ANNOUNCEMENTS", 12f, gold, true))
        r.addView(list)
        r.addView(button("Open Full MTI Notice Board") { openWebsite("/student-portal#notices") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))

        executor.execute {
            try {
                val raw = get("/rest/v1/portal_announcements?select=*&order=created_at.desc&limit=100")
                val notices = JSONArray(raw)
                runOnUiThread {
                    val seenKey = "notice_seen_${userId ?: "student"}"
                    val seen = loadSeenNotices(seenKey)
                    fun noticeId(x: JSONObject): String = x.optString("id")
                        .ifBlank { x.optString("announcement_id") }
                        .ifBlank { "${x.optString("title")}_${x.optString("created_at")}" }
                    fun isUnread(x: JSONObject) = !seen.contains(noticeId(x))
                    fun render() {
                        list.removeAllViews()
                        val q = filter.text.toString().trim().lowercase()
                        var shown = 0
                        for (i in 0 until notices.length()) {
                            val x = notices.getJSONObject(i)
                            val searchable = listOf(
                                x.optString("title"), x.optString("body"), x.optString("content"),
                                x.optString("message"), x.optString("category"), x.optString("notice_type")
                            ).joinToString(" ").lowercase()
                            if (q.isNotBlank() && !searchable.contains(q)) continue
                            if (unreadOnly && !isUnread(x)) continue
                            shown++
                            val id = noticeId(x)
                            val category = x.optString("category").ifBlank { x.optString("notice_type") }.ifBlank { "MTI NOTICE" }
                            val heading = x.optString("title").ifBlank { "MTI Notice" }
                            val body = x.optString("body").ifBlank { x.optString("content") }.ifBlank { x.optString("message") }.ifBlank { "No additional notice content." }
                            val date = x.optString("created_at").ifBlank { x.optString("published_at") }
                            val card = LinearLayout(this).apply {
                                orientation = LinearLayout.VERTICAL
                                setBackgroundColor(white)
                                setPadding(dp(14), dp(12), dp(14), dp(12))
                                elevation = dp(1).toFloat()
                                layoutParams = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { setMargins(dp(20), dp(5), dp(20), dp(5)) }
                            }
                            card.addView(text(category.uppercase(), 10.5f, gold, true))
                            card.addView(text(heading, 17f, green, true))
                            if (isUnread(x)) card.addView(text("NEW / UNREAD", 10.5f, gold, true))
                            card.addView(text(body, 13.5f, ink))
                            card.addView(text(formatNoticeDate(date), 11.5f, ink))
                            card.addView(button(if (isUnread(x)) "Mark as Read" else "Read") {
                                seen.add(id)
                                saveSeenNotices(seenKey, seen)
                                render()
                            })
                            list.addView(card)
                        }
                        summary.removeAllViews()
                        val unread = (0 until notices.length()).count { isUnread(notices.getJSONObject(it)) }
                        summary.addView(card("New Notices", unread.toString()))
                        summary.addView(card("Total Notices", notices.length().toString()))
                        status.text = if (shown == 0) "No notices match the current filter." else "$shown notice${if (shown == 1) "" else "s"} available."
                        filterButton.text = if (unreadOnly) "Show All Notices" else "Show Unread Only"
                    }
                    filter.setOnEditorActionListener { _, _, _ -> render(); true }
                    filter.addTextChangedListener(object : android.text.TextWatcher {
                        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render() }
                        override fun afterTextChanged(s: android.text.Editable?) {}
                    })
                    filterButton.setOnClickListener { unreadOnly = !unreadOnly; render() }
                    render()
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    status.text = ex.message ?: "Unable to load MTI notices."
                    summary.removeAllViews(); list.removeAllViews()
                    list.addView(card("Notice Board unavailable", "Please try again or open the full MTI Student Portal Notice Board."))
                }
            }
        }
    }

    private fun loadSeenNotices(key: String): MutableSet<String> {
        return try {
            val raw = prefs.getString(key, "[]") ?: "[]"
            val arr = JSONArray(raw)
            mutableSetOf<String>().apply { for (i in 0 until arr.length()) add(arr.optString(i)) }
        } catch (_: Exception) { mutableSetOf() }
    }

    private fun saveSeenNotices(key: String, seen: Set<String>) {
        val arr = JSONArray()
        seen.forEach { arr.put(it) }
        prefs.edit().putString(key, arr.toString()).apply()
    }

    private fun formatNoticeDate(value: String): String {
        if (value.isBlank()) return "Date not provided"
        val d = parseSessionDate(value) ?: return value
        return SimpleDateFormat("dd MMM yyyy · hh:mm a", Locale.US).format(d)
    }

    private fun showHostel(messageText: String? = null) {
        val r = root()
        header(r, "STUDENT SERVICES", "Hostel Accommodation", "Hostel accommodation is allocated through the MTI Chief of Staff’s Office.")
        val status = text(messageText ?: "Loading your hostel information…", 14f, ink)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(status)
        r.addView(content)
        r.addView(button("Go to Fees & Payments") { showFeesPayments() })
        r.addView(button("Open Full MTI Hostel Centre") { openWebsite("/student-portal#hostel") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val uid = userId?.takeIf { it.isNotBlank() } ?: throw Exception("Your authenticated student session is missing.")
                val hostelFee = 5000.0
                val payments = JSONArray(get("/rest/v1/student_payments?select=*&student_id=eq.${URLEncoder.encode(profile?.optString("id") ?: "", "UTF-8")}&order=created_at.desc&limit=300"))
                val allocations = JSONArray(get("/rest/v1/hostel_allocations?select=*&user_id=eq.${URLEncoder.encode(uid, "UTF-8")}&order=created_at.desc&limit=50"))
                var paid = false
                for (i in 0 until payments.length()) {
                    val x = payments.getJSONObject(i)
                    val descriptor = (x.optString("fee_type") + " " + x.optString("description")).lowercase()
                    val st = x.optString("status").lowercase()
                    if (descriptor.contains("hostel") && st in setOf("paid", "verified", "successful", "completed") && x.optDouble("amount", 0.0) >= hostelFee) { paid = true; break }
                }
                val allocation = if (allocations.length() > 0) allocations.getJSONObject(0) else null
                runOnUiThread {
                    content.removeAllViews()
                    status.text = if (allocation != null) "Your latest hostel allocation is shown below." else "Hostel allocation has not yet been recorded for your account."
                    content.addView(card("HOSTEL FEE", "₦5,000\nPay the hostel fee first, then print/save your official payment receipt."))
                    content.addView(card("ALLOCATION PROCEDURE", "1. Pay ₦5,000 through the MTI payment process.\n\n2. Open your official payment receipt from Fees & Payments and print or save it as PDF.\n\n3. Present the printed receipt at the MTI Chief of Staff’s Office for verification and hostel allocation.\n\n4. After the office records your allocation, your hostel and room details can appear in this app."))
                    content.addView(card("PAYMENT STATUS", if (paid) "PAID / VERIFIED\nAmount confirmed: ₦5,000" else "PAYMENT NOT CONFIRMED\n₦5,000 hostel fee is required before allocation."))
                    if (!paid) content.addView(card("IMPORTANT", "Hostel allocation is not completed through this Android screen. Pay the ₦5,000 hostel fee, obtain your official receipt, and take the printed receipt to the Chief of Staff’s Office."))
                    if (allocation != null) {
                        val hostel = allocation.optString("hostel_name").ifBlank { "—" }
                        val room = allocation.optString("room_no").ifBlank { "—" }
                        val session = allocation.optString("session").ifBlank { "—" }
                        val allocStatus = allocation.optString("status").ifBlank { "—" }
                        content.addView(card("MY ACCOMMODATION", "Hostel: $hostel\nRoom: $room\nSession: $session\nStatus: $allocStatus"))
                    } else {
                        content.addView(card("MY ACCOMMODATION", "No hostel allocation has been recorded yet. After payment, present your printed receipt at the Chief of Staff’s Office for allocation."))
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread {
                    status.text = ex.message ?: "Unable to load hostel information."
                    content.removeAllViews()
                    content.addView(card("Hostel information unavailable", "Please try again or open the full MTI Student Portal for the latest hostel information."))
                }
            }
        }
    }

    private fun parseSessionDate(value: String): Date? {
        if (value.isBlank()) return null
        val candidates = listOf("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss")
        for (pattern in candidates) {
            try { return SimpleDateFormat(pattern, Locale.US).parse(value) } catch (_: Exception) { }
        }
        return null
    }

    private fun formatDateTime(value: String): String {
        val d = parseSessionDate(value) ?: return if (value.isBlank()) "Schedule pending" else value
        return SimpleDateFormat("EEE, dd MMM yyyy · hh:mm a", Locale.US).format(d)
    }

    private fun formatClock(value: String): String {
        val d = parseSessionDate(value) ?: return value
        return SimpleDateFormat("hh:mm a", Locale.US).format(d)
    }

    private fun showAttendance(messageText: String? = null) {
        val r = root()
        header(r, "ATTENDANCE", "Attendance Centre", "Track attendance records officially entered by MTI academic staff.")
        val status = text(messageText ?: "Loading your attendance…", 14f, ink)
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(status); r.addView(text("SUMMARY", 12f, gold, true)); r.addView(summary); r.addView(text("MY ATTENDANCE RECORD", 12f, gold, true)); r.addView(content)
        r.addView(button("Open Full Attendance Centre") { openWebsite("/student-portal#attendance") })
        r.addView(button("Class Schedule") { showClassSchedule() })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
        executor.execute {
            try {
                val data = JSONArray(get("/rest/v1/student_attendance_v123?select=*&order=attendance_date.desc,created_at.desc&limit=500"))
                val rows = mutableListOf<JSONObject>(); for (i in 0 until data.length()) rows.add(data.getJSONObject(i))
                val present = rows.count { it.optString("status").equals("present", true) }
                val late = rows.count { it.optString("status").equals("late", true) }
                val absent = rows.count { it.optString("status").equals("absent", true) }
                val excused = rows.count { it.optString("status").equals("excused", true) }
                val rate = if (rows.isEmpty()) "—" else "${Math.round((present + late).toDouble() / rows.size * 100)}%"
                runOnUiThread {
                    summary.removeAllViews(); content.removeAllViews()
                    status.text = if (rows.isEmpty()) "No attendance records have been published for you yet." else "${rows.size} attendance record${if (rows.size == 1) "" else "s"} found."
                    summary.addView(card("Attendance Rate", rate)); summary.addView(card("Present / Late", "$present present · $late late")); summary.addView(card("Absent / Excused", "$absent absent · $excused excused"))
                    if (rows.isEmpty()) content.addView(card("No records yet", "Only attendance records officially entered by MTI staff appear here."))
                    else rows.forEach { x ->
                        val course = x.optString("course_code").ifBlank { x.optString("course_title") }.ifBlank { "Course" }
                        val details = "${formatDate(x.optString("attendance_date").ifBlank { x.optString("class_date") })}\n${x.optString("status").ifBlank { "Status unavailable" }} · ${x.optString("semester").ifBlank { "Semester —" }}\n${x.optString("note").ifBlank { "No note" }}"
                        content.addView(card(course, details))
                    }
                }
            } catch (ex: Exception) {
                runOnUiThread { status.text = ex.message ?: "Unable to load attendance."; summary.removeAllViews(); content.removeAllViews(); content.addView(card("Attendance unavailable", "Please try again or open the full MTI Student Portal.")) }
            }
        }
    }

    private fun normalizeSemester(value: String): String {
        val v = value.trim().lowercase()
        if (v.isBlank()) return ""
        return when {
            v.contains("first") || v.contains("1st") || v == "1" -> "1"
            v.contains("second") || v.contains("2nd") || v == "2" -> "2"
            else -> v.replace(Regex("\\s+"), " ")
        }
    }

    private fun formatTime(value: String): String {
        if (value.isBlank()) return "—"
        val parts = value.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: return value
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        val ap = if (h >= 12) "PM" else "AM"
        val hh = if (h % 12 == 0) 12 else h % 12
        return "$hh:${m.toString().padStart(2, '0')} $ap"
    }

    private fun formatDate(value: String): String {
        if (value.isBlank()) return "Date unavailable"
        return try {
            val parts = value.take(10).split("-")
            if (parts.size == 3) "${parts[2].padStart(2, '0')} ${parts[1]} ${parts[0]}" else value
        } catch (_: Exception) { value }
    }

    private fun showBiodataEditor(messageText: String? = null) {
        val p = profile ?: JSONObject()
        val r = root()
        header(r, "STUDENT PROFILE", "My Biodata", "Update your personal information. Institution-controlled academic identity remains protected.")
        r.addView(text("EDITABLE INFORMATION", 12f, gold, true))
        val first = field("First Name").apply { setText(p.optString("first_name")) }
        val middle = field("Middle Name").apply { setText(p.optString("middle_name")) }
        val last = field("Last Name").apply { setText(p.optString("last_name")) }
        val phone = field("Phone Number").apply { setText(p.optString("phone_number")); inputType = android.text.InputType.TYPE_CLASS_PHONE }
        val dob = field("Date of Birth (YYYY-MM-DD)").apply { setText(p.optString("date_of_birth")) }
        val gender = field("Gender").apply { setText(p.optString("gender")) }
        val address = field("Address")
        address.setText(p.optString("address"))
        address.minLines = 3
        address.gravity = Gravity.TOP
        val photoStatus = text(if (p.optString("photo_url").isNotBlank()) "Current profile photo is available." else "No profile photo uploaded.", 13f, ink)
        val status = text(messageText ?: "", 14f, ink)
        listOf(first, middle, last, phone, dob, gender, address).forEach { r.addView(it) }
        r.addView(photoStatus)
        r.addView(button("Choose Profile Photo") { chooseProfilePhoto(photoStatus) })
        r.addView(text("PROTECTED BY MTI", 12f, gold, true))
        r.addView(card("Student Number", p.optString("student_number").ifBlank { "Not available" }))
        r.addView(card("Programme", (p.optString("programme").ifBlank { p.optString("program") }).ifBlank { "Not available" }))
        r.addView(card("Level", p.optString("level").ifBlank { "Not available" }))
        r.addView(card("Section / Session", (p.optString("session").ifBlank { p.optString("section") }).ifBlank { "Not available" }))
        r.addView(text("These institutional fields cannot be edited from the student profile screen.", 13f, ink))
        r.addView(button("Save Biodata") {
            if (first.text.toString().trim().isBlank() || last.text.toString().trim().isBlank()) {
                status.text = "First Name and Last Name are required."
                return@button
            }
            status.text = "Saving your biodata…"
            executor.execute {
                try {
                    var photo = p.optString("photo_url").ifBlank { null }
                    val pendingUri = selectedPhotoUri
                    if (pendingUri != null) {
                        photo = uploadProfilePhoto(pendingUri)
                    }
                    val body = JSONObject()
                        .put("p_first_name", first.text.toString().trim())
                        .put("p_middle_name", middle.text.toString().trim().ifBlank { null })
                        .put("p_last_name", last.text.toString().trim())
                        .put("p_phone_number", phone.text.toString().trim().ifBlank { null })
                        .put("p_date_of_birth", dob.text.toString().trim().ifBlank { null })
                        .put("p_gender", gender.text.toString().trim().ifBlank { null })
                        .put("p_address", address.text.toString().trim().ifBlank { null })
                        .put("p_photo_url", photo)
                    val raw = postRaw("/rest/v1/rpc/mti_update_my_student_biodata_v111", body)
                    val updated = parseProfileResponse(raw, p)
                    profile = updated
                    selectedPhotoUri = null
                    runOnUiThread {
                        status.text = "✓ Biodata saved successfully."
                        showDashboard()
                    }
                } catch (ex: Exception) {
                    runOnUiThread { status.text = ex.message ?: "Unable to save your biodata." }
                }
            }
        })
        r.addView(button("Back to Dashboard") { showDashboard() })
        setContentView(scroll(r))
    }

    private var selectedPhotoUri: Uri? = null

    private fun chooseProfilePhoto(status: TextView) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
        }
        status.text = "Choose a JPG, PNG or WebP profile photo. Maximum 3 MB."
        startActivityForResult(intent, 2301)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2301 && resultCode == RESULT_OK) {
            selectedPhotoUri = data?.data
        } else if (requestCode == 2333 && resultCode == RESULT_OK) {
            val uri = data?.data
            val paymentId = pendingEvidencePaymentId
            pendingEvidencePaymentId = null
            if (uri != null && !paymentId.isNullOrBlank()) uploadPaymentEvidence(uri, paymentId)
        }
    }

    private fun uploadProfilePhoto(uri: Uri): String {
        val uid = userId ?: throw Exception("Your authenticated student session is missing.")
        val mime = contentResolver.getType(uri) ?: "image/jpeg"
        if (mime !in listOf("image/jpeg", "image/png", "image/webp")) throw Exception("Profile photo must be JPG, PNG or WebP.")
        val bytes = contentResolver.openInputStream(uri)?.use { input -> input.readBytes() } ?: throw Exception("Unable to read the selected profile photo.")
        if (bytes.size > 3 * 1024 * 1024) throw Exception("Profile photo must not exceed 3 MB.")
        val original = (uri.lastPathSegment ?: "profile.jpg").substringAfterLast('/').replace(Regex("[^a-zA-Z0-9._-]"), "_")
        val path = "$uid/${System.currentTimeMillis()}-$original"
        uploadBytes("/storage/v1/object/student-profile-photos/${URLEncoder.encode(path, "UTF-8").replace("+", "%20")}", bytes, mime)
        return "$supabaseUrl/storage/v1/object/public/student-profile-photos/$path"
    }

    private fun uploadBytes(path: String, bytes: ByteArray, mime: String) {
        val c = (URL(supabaseUrl + path).openConnection() as HttpURLConnection)
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = 15000
        headers().forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.setRequestProperty("x-upsert", "true")
        c.setRequestProperty("Content-Type", mime)
        c.doOutput = true
        c.outputStream.use { it.write(bytes) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val out = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        if (code !in 200..299) {
            val msg = try { JSONObject(out).optString("message") } catch (_: Exception) { "" }
            throw Exception(msg.ifBlank { "Profile photo upload failed ($code)." })
        }
    }

    private fun card(label:String,value:String):TextView=text("$label\n$value",14f,ink,false).apply{setPadding(dp(20),dp(12),dp(20),dp(12));setBackgroundColor(white);layoutParams=LinearLayout.LayoutParams(-1,dp(66)).apply{setMargins(dp(20),dp(4),dp(20),dp(4))}}

    private fun headers():Map<String,String> = mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: supabaseKey}","Content-Type" to "application/json","Accept" to "application/json")
    private fun post(path:String,body:JSONObject):JSONObject=network(path,"POST",body.toString()).let{JSONObject(it)}
    private fun postRaw(path:String,body:JSONObject):String=network(path,"POST",body.toString())
    private fun parseProfileResponse(raw:String, fallback:JSONObject):JSONObject {
        return try {
            val trimmed = raw.trim()
            when {
                trimmed.startsWith("[") -> JSONArray(trimmed).optJSONObject(0) ?: fallback
                trimmed.startsWith("{") -> {
                    val obj = JSONObject(trimmed)
                    if (obj.opt("data") is JSONArray) obj.optJSONArray("data")?.optJSONObject(0) ?: fallback else if (obj.opt("data") is JSONObject) obj.optJSONObject("data") ?: fallback else obj
                }
                else -> fallback
            }
        } catch (_: Exception) { fallback }
    }
    private fun get(path:String):String=network(path,"GET",null)
    private fun network(path:String,method:String,body:String?):String { val c=(URL(supabaseUrl+path).openConnection() as HttpURLConnection); c.requestMethod=method; c.connectTimeout=15000;c.readTimeout=15000;headers().forEach{(k,v)->c.setRequestProperty(k,v)}; if(body!=null){c.doOutput=true;c.outputStream.use{it.write(body.toByteArray(Charsets.UTF_8))}}; val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream; val out=stream?.bufferedReader()?.use{it.readText()} ?: "";c.disconnect();if(code !in 200..299){val msg=try{JSONObject(out).optString("message").ifBlank{JSONObject(out).optString("error_description")}}catch(_:Exception){""};throw Exception(msg.ifBlank{"MTI server request failed ($code)."})};return out}
    private fun openWebsite(path:String){startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}

    override fun onDestroy(){executor.shutdownNow();super.onDestroy()}
}
