# V288 — Reproducible Android Build Configuration

- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle distribution target: 8.9
- compileSdk / targetSdk: 35
- minSdk: 24
- applicationId: ng.org.mtiumuahia.app
- versionCode: 288
- versionName: 7.7.0

The official Gradle wrapper JAR is intentionally not fabricated or substituted. The package contains the wrapper scripts and distribution configuration, but an actual `gradle-wrapper.jar` must be supplied by a trusted Gradle installation/distribution before the wrapper can execute.
