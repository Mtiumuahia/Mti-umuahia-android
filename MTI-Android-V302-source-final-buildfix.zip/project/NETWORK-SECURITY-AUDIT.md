# MTI Android V291 — Network, Web & Secure External Content Audit

## Scope
Audited the V290 Android source before changes, focusing on network endpoints, URL handling, external intents, cleartext traffic, Supabase access, and public-site URL consistency.

## Findings and corrections
- Confirmed Android `INTERNET` permission is the only network permission declared.
- Confirmed `android:usesCleartextTraffic="false"` remains enabled.
- Tightened lecturer meeting/resource URL validation to HTTPS-only so it is consistent with the app's cleartext-disabled policy.
- Removed two stale hard-coded Netlify public-site references and routed them through the existing `mti_base_url` resource.
- Preserved the existing Supabase HTTPS endpoint, publishable-key model, Auth and RLS boundary.
- No service-role key, new backend endpoint, certificate bypass, custom trust manager, or insecure HTTP transport was introduced.
- External links continue to use Android's external intent boundary; no new embedded browser or unrestricted WebView was introduced.

## Backend
No database, Supabase schema, RLS, RPC, storage bucket, or authentication migration.
