# MTI Android V299 — Dependency, SDK & Supply-Chain Security Audit

## Baseline
Audited the actual V298 source before changing anything.

## Findings
- The app declares no third-party runtime libraries through `implementation`, `api`, `runtimeOnly`, or `kapt`.
- Android Gradle Plugin is pinned to `8.7.3`.
- Kotlin Android plugin is pinned to `2.0.21`.
- Compile SDK and target SDK are pinned to API 35; minimum SDK is API 24.
- Gradle wrapper distribution is pinned to Gradle 8.9 and uses the official HTTPS distribution URL.
- `settings.gradle.kts` uses `RepositoriesMode.FAIL_ON_PROJECT_REPOS`, preventing individual modules from silently adding repositories.
- Dependency repositories are limited to Google, Maven Central, and Gradle Plugin Portal for plugin resolution.
- No dynamic dependency versions (`+`), SNAPSHOT dependencies, custom Maven repositories, JitPack URLs, HTTP artifact URLs, or embedded third-party AAR/JAR files were found.
- The wrapper JAR is intentionally not bundled; the launcher fails closed when it is absent rather than downloading or executing an unknown bootstrap artifact.

## Security posture
No dependency, SDK, repository, authentication, Supabase, RLS, storage, or database architecture was changed. This release is an audit/documentation hardening version.

## Build limitation
An APK build was not claimed because `gradle/wrapper/gradle-wrapper.jar` is not bundled and no trusted Gradle executable is available in the environment.
