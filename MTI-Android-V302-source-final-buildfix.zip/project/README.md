# MTI Umuahia Android — V302

Release Candidate Integration & Full Pre-Build Audit.

- versionCode: 300
- versionName: 9.0.0
- package: ng.org.mtiumuahia.app
- compile/target SDK: 35
- min SDK: 24
- 36 Kotlin activities retained
- Existing Supabase/Auth/RLS architecture preserved
- No SQL migration required

This package is source-ready for a trusted Android/Gradle build environment. The bundled Gradle launcher intentionally fails closed because the official Gradle 8.9 wrapper JAR is not bundled.
