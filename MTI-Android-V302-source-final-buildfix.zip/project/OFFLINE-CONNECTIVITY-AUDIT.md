# MTI Android V297 — Offline / Connectivity & Error-Recovery Audit

## Scope
Audited V296 before changes, focusing on public live-data requests, WebView loading, network availability, and user recovery when connectivity is unavailable.

## Changes
- Added Android network-state permission for a lightweight connectivity preflight.
- Added `ConnectivityManager` / `NetworkCapabilities` availability detection in `MainActivity`.
- Added friendly offline states with explicit retry actions for live News and Events.
- Added retry behavior when live public content cannot be reached.
- Added WebView main-frame error feedback without exposing backend exception details.
- Preserved HTTPS-only transport, existing Supabase architecture, Auth/RLS boundaries, and existing portal flows.
- No offline cache/database was invented and no second backend was introduced.

## Validation
- 36 Kotlin source files retained.
- Manifest XML parsed successfully.
- No SQL migration required.
- APK build not claimed because a trusted Gradle wrapper JAR/installed Gradle runtime is unavailable in the source environment.
