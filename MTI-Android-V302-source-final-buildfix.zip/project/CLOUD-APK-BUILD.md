# MTI Umuahia — Cloud APK Build

This project can now build the debug APK on a GitHub-hosted Ubuntu runner without requiring a local computer, Android Studio, a system Gradle installation, or `gradle-wrapper.jar` in the repository.

## Toolchain

- Java 21 (Temurin)
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk 35
- targetSdk 35
- minSdk 24

## Why this works

The GitHub Actions workflow installs Gradle 8.9 directly on the hosted build machine. It therefore does not invoke the incomplete local Gradle Wrapper.

Build command:

```text
gradle --no-daemon --stacktrace assembleDebug
```

Expected artifact:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The workflow uploads that APK as a downloadable GitHub Actions artifact.

## Phone-only workflow

1. Create/sign in to a GitHub account.
2. Create a new repository.
3. Upload the contents of this project ZIP to the repository root.
4. Open **Actions**.
5. Select **Build MTI Android APK**.
6. Run the workflow with **Run workflow**.
7. When it finishes successfully, open the workflow run.
8. Download **MTI-Umuahia-debug-apk-v302**.
9. On the Android phone, open the downloaded APK and allow installation from that source if Android asks.

No Supabase service-role key, password, OpenAI key, or other secret is required by this build workflow.
