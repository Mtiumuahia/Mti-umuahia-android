package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.*
import android.content.res.ColorStateList

class ManagementControlsActivity : Activity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val ink=Color.rgb(23,53,44); private val gold=Color.rgb(184,149,74)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(Color.WHITE);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    override fun onCreate(b:Bundle?){super.onCreate(b);show()}
    private fun show(){
        val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(20))}
        val sc=ScrollView(this).apply{isFillViewport=true;addView(r)}
        r.addView(text("MTI · UMUAHIA",12f,gold,true));r.addView(text("Admission & SUG Controls",28f,ink,true))
        r.addView(text("Management control centre for two existing institutional workspaces. The Android app does not invent or replace the existing admission-control or SUG database architecture."))
        r.addView(text("ADMISSION PORTAL CONTROL",12f,gold,true));r.addView(text("Use the existing management workspace to open/close admission and manage the authoritative admission-cycle settings. No unverified settings table or RPC is created here."))
        r.addView(button("Open Admission Portal Control"){web("/management-dashboard#admission-control")})
        r.addView(text("SUG EXECUTIVE MANAGEMENT",12f,gold,true));r.addView(text("Use the existing SUG management workspace for executive records, including the established SUG executive data structure and upload workflow."))
        r.addView(button("Open SUG Executives Management"){web("/sug-executives-management")})
        r.addView(text("The controls above remain governed by the existing Supabase authentication, RLS policies and management authorization. This release deliberately avoids creating duplicate tables or permissions."))
        r.addView(button("Back"){finish()});setContentView(sc)
    }
    private fun web(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
