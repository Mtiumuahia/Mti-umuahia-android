package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementAcademicActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(2)
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"; private val supabaseKey="sb_publishable_oWY2vA2WyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken:String?=null; private val records=mutableListOf<JSONObject>(); private var query=""; private var activeOnly=true
    override fun onCreate(b:Bundle?){super.onCreate(b);accessToken=intent.getStringExtra("access_token");show()}
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(14),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun card(h:String,b:String,click:(()->Unit)?=null)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(11),dp(14),dp(11));addView(text(h,16f,green,true));addView(text(b,13f,ink));if(click!=null){setOnClickListener{click()};isClickable=true}}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun set(v:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(v)})}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Content-Type" to "application/json","Accept" to "application/json","Prefer" to "return=representation")
    private fun request(method:String,path:String,payload:String?=null):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod=method;c.connectTimeout=12000;c.readTimeout=18000;headers().forEach{(k,v)->c.setRequestProperty(k,v)};if(payload!=null){c.doOutput=true;c.outputStream.use{it.write(payload.toByteArray())}};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception("Authorised request failed (HTTP $code)");return body}
    private fun show(){
        val r=root();r.addView(label("MANAGEMENT · ACADEMICS"));r.addView(title("Academic Administration"));r.addView(text("Manage the existing MTI academic course catalogue. Changes use the existing academic_courses table and management RLS; no new academic architecture is introduced."))
        r.addView(button("Open Full Academic Administration"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/academic-administration")))})
        val search=EditText(this).apply{hint="Search course code, title, programme, level…";isSingleLine=true;setTextColor(ink)};r.addView(search,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,dp(4))})
        val toggle=Switch(this).apply{text="Show active courses only";isChecked=true;setTextColor(ink);setOnCheckedChangeListener{_,v->activeOnly=v;render()}};r.addView(toggle)
        val status=text("Loading academic catalogue…",13f);r.addView(status)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(list)
        val add=button("Add Academic Course"){showEditor(null)};r.addView(add)
        search.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){query=s?.toString()?.trim()?.lowercase() ?: "";render()};override fun afterTextChanged(e:Editable?) {}})
        set(r)
        executor.execute{try{val a=JSONArray(request("GET","/rest/v1/academic_courses?select=*&order=course_code.asc&limit=2000"));records.clear();for(i in 0 until a.length())records.add(a.getJSONObject(i));runOnUiThread{status.text="${records.size} course record${if(records.size==1)"" else "s"} loaded.";render()}}catch(x:Exception){runOnUiThread{status.text="Academic catalogue could not be loaded. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}";list.removeAllViews();list.addView(card("Catalogue unavailable","Open the full Academic Administration workspace for the complete management workflow."))}}}
    }
    private fun render(){val root=findViewById<ScrollView>(android.R.id.content)?.getChildAt(0) as? LinearLayout ?: return;val list=root.getChildAt(root.childCount-1) as? LinearLayout ?: return
        list.removeAllViews();val shown=records.filter{val active=it.optBoolean("active",true);val q=it.toString().lowercase().contains(query);(!activeOnly||active)&&q};if(shown.isEmpty()){list.addView(card("No matching courses","Try another search or include inactive courses."));return};shown.forEach{o->val code=o.optString("course_code").ifBlank{"Course"};val title=o.optString("course_title");val meta=listOf(o.optString("programme_name"),o.optString("level"),o.optString("semester"),"${o.optString("credit_load").ifBlank{"0"}} credits",if(o.optBoolean("active",true))"Active" else "Inactive").filter{it.isNotBlank()}.joinToString(" · ");list.addView(card(code,title+"\n"+meta){showEditor(o)})}
    }
    private fun showEditor(o:JSONObject?){val edit=o!=null;val r=root();r.addView(label(if(edit)"EDIT COURSE" else "NEW COURSE"));r.addView(title(if(edit)"Update Academic Course" else "Add Academic Course"));r.addView(text("This writes only to the existing academic_courses table and relies on the authenticated management RLS policy."))
        fun field(h:String,v:String)=EditText(this).apply{hint=h;setText(v);setTextColor(ink);isSingleLine=true}.also{r.addView(it,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(4),0,dp(4))})}
        val code=field("Course code",o?.optString("course_code")?:(""));val title=field("Course title",o?.optString("course_title")?:"");val desc=field("Description (optional)",o?.optString("description")?:"");val programme=field("Programme name (optional)",o?.optString("programme_name")?:"");val level=field("Level (optional)",o?.optString("level")?:"");val semester=field("Semester (optional)",o?.optString("semester")?:"");val credits=field("Credit load",o?.optString("credit_load")?:"3")
        val active=Switch(this).apply{text="Active course";isChecked=o?.optBoolean("active",true)?:true;setTextColor(ink)};r.addView(active)
        val msg=text("",13f,ink);r.addView(msg);r.addView(button(if(edit)"Save Changes" else "Create Course"){val c=code.text.toString().trim();val t=title.text.toString().trim();if(c.isBlank()||t.isBlank()){msg.text="Course code and title are required.";return@button};val payload=JSONObject().put("course_code",c).put("course_title",t).put("description",desc.text.toString().trim().ifBlank{JSONObject.NULL}).put("programme_name",programme.text.toString().trim().ifBlank{JSONObject.NULL}).put("level",level.text.toString().trim().ifBlank{JSONObject.NULL}).put("semester",semester.text.toString().trim().ifBlank{JSONObject.NULL}).put("credit_load",credits.text.toString().trim().toDoubleOrNull()?:3).put("active",active.isChecked);msg.text="Saving…";executor.execute{try{if(edit)request("PATCH","/rest/v1/academic_courses?id=eq.${o!!.optString("id")}",payload.toString()) else request("POST","/rest/v1/academic_courses",payload.toString());runOnUiThread{Toast.makeText(this,"Course saved.",Toast.LENGTH_SHORT).show();show();}}catch(x:Exception){runOnUiThread{msg.text="Could not save course. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}"}}}});r.addView(button("Cancel"){show()});set(r)}
}
