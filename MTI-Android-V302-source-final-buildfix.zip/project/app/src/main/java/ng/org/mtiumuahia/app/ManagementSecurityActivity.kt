package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ManagementSecurityActivity : Activity() {
    private val cream=Color.rgb(246,241,230); private val green=Color.rgb(11,61,46); private val ink=Color.rgb(23,53,44); private val gold=Color.rgb(184,149,74)
    override fun onCreate(b:Bundle?){super.onCreate(b);show()}
    private fun t(s:String,size:Float=14f,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(ink);setPadding(8,8,8,8);if(bold)setTypeface(null,1)}
    private fun btn(s:String,action:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setOnClickListener{action()}}
    private fun card(h:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE);setPadding(16,14,16,14);addView(t(h,16f,true));addView(t(b))}
    private fun show(){
        val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(16,14,16,20)}
        r.addView(t("MTI · UMUAHIA",12f,true));r.addView(t("Audit, Security & Activity Monitoring",27f,true))
        r.addView(t("Security and audit controls confirmed during the V268 architecture audit. This Android layer does not invent an audit-log table or bypass existing Supabase security policies."))
        r.addView(card("Authentication","Management access uses Supabase Auth email/password authentication. The management role is checked through the existing is_portal_role RPC before the management dashboard is opened."))
        r.addView(card("Authorisation","Existing RLS policies remain authoritative. The Android management screens use the authenticated user's access token and do not introduce a service-role credential or a second permission model."))
        r.addView(card("Activity records","The audited Android/backend source did not establish a dedicated institutional audit-log or security-event table/RPC. Therefore V268 does not create one or pretend that historical activity logs exist."))
        r.addView(card("Operational monitoring","Existing management modules remain available for admissions, academics, results, finance, hostel, attendance, virtual learning, materials, communications and student services."))
        r.addView(t("AUTHORITATIVE WORKSPACES",12f,true).apply{setTextColor(gold)})
        r.addView(btn("Open Management Command Centre"){web("/management-dashboard")})
        r.addView(btn("Open Admission Administration"){web("/admissions-administration")})
        r.addView(btn("Open Finance Dashboard"){web("/finance-dashboard")})
        r.addView(btn("Open Result Review"){web("/result-review")})
        r.addView(btn("Back"){finish()})
        setContentView(ScrollView(this).apply{addView(r)})
    }
    private fun web(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
