package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementResultReviewActivity : Activity() {
    private val executor=Executors.newFixedThreadPool(2)
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"; private val supabaseKey="sb_publishable_oWY2vA2WyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken:String?=null; private val results=mutableListOf<JSONObject>(); private val students=mutableListOf<JSONObject>(); private val courses=mutableListOf<JSONObject>(); private var query=""; private var statusFilter="All"
    override fun onCreate(b:Bundle?){super.onCreate(b);accessToken=intent.getStringExtra("access_token");show()}
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(14),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun card(h:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(11),dp(14),dp(11));addView(text(h,16f,green,true));addView(text(b,13f,ink))}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun set(v:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(v)})}
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";c.connectTimeout=12000;c.readTimeout=18000;c.setRequestProperty("apikey",supabaseKey);c.setRequestProperty("Authorization","Bearer ${accessToken ?: ""}");c.setRequestProperty("Accept","application/json");val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception("Authorised request failed (HTTP $code)");return body}
    private fun show(){
        val r=root();r.addView(label("MANAGEMENT · ACADEMICS"));r.addView(title("Result Review"));r.addView(text("Review existing MTI result records from the authorised management session. This native screen is intentionally read-only; publishing or altering results remains governed by the existing full management workflow and database permissions."))
        r.addView(button("Open Full Result Review Workspace"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/result-review")))})
        val search=EditText(this).apply{hint="Search student, registration number, course code or title…";isSingleLine=true;setTextColor(ink)};r.addView(search,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,dp(4))})
        val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("All","Draft","Published"));spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){statusFilter=spinner.selectedItem.toString();render()}};r.addView(spinner,LinearLayout.LayoutParams(-1,dp(52)))
        val summary=text("Loading result records…",13f);r.addView(summary);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(list)
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){query=s?.toString()?.trim()?.lowercase() ?: "";render()};override fun afterTextChanged(e:android.text.Editable?) {}})
        set(r)
        executor.execute{try{val rr=JSONArray(get("/rest/v1/student_results?select=*&order=created_at.desc&limit=5000"));val ss=JSONArray(get("/rest/v1/student_profiles?select=*&limit=5000"));val cc=JSONArray(get("/rest/v1/academic_courses?select=id,course_code,course_title&limit=2000"));results.clear();students.clear();courses.clear();for(i in 0 until rr.length())results.add(rr.getJSONObject(i));for(i in 0 until ss.length())students.add(ss.getJSONObject(i));for(i in 0 until cc.length())courses.add(cc.getJSONObject(i));runOnUiThread{summary.text="${results.size} result record${if(results.size==1)"" else "s"} · ${results.count{it.optString("status").lowercase()=="draft"}} draft · ${results.count{it.optString("status").lowercase()=="published"}} published";render()}}catch(x:Exception){runOnUiThread{summary.text="Result records could not be loaded. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}";list.removeAllViews();list.addView(card("Result review unavailable","Open the full Result Review workspace for the complete management workflow."))}}}
    }
    private fun studentName(o:JSONObject):String{val id=o.optString("student_id").ifBlank{o.optString("user_id")};val s=students.firstOrNull{it.optString("user_id")==id||it.optString("id")==id};return s?.optString("full_name")?.takeIf{it.isNotBlank()}?:listOf(s?.optString("first_name"),s?.optString("middle_name"),s?.optString("last_name")).filter{it?.isNotBlank()==true}.joinToString(" ").ifBlank{"Student $id"}}
    private fun courseLabel(o:JSONObject):String{val id=o.optString("course_id");val c=courses.firstOrNull{it.optString("id")==id};return c?.optString("course_code")?.takeIf{it.isNotBlank()}?:o.optString("course_code").ifBlank{"Course"} }
    private fun render(){val sv=findViewById<ScrollView>(android.R.id.content)?.getChildAt(0) as? LinearLayout ?:return;val list=sv.getChildAt(sv.childCount-1) as? LinearLayout ?:return;list.removeAllViews();val shown=results.filter{o->val st=o.optString("status").ifBlank{"published"}.lowercase();val statusOk=statusFilter=="All"||st==statusFilter.lowercase();val hay=(studentName(o)+" "+courseLabel(o)+" "+o.toString()).lowercase();statusOk&&(query.isBlank()||hay.contains(query))};if(shown.isEmpty()){list.addView(card("No matching results","Try another search or status filter."));return};shown.take(300).forEach{o->val student=studentName(o);val course=courseLabel(o);val title=o.optString("course_title").ifBlank{courses.firstOrNull{it.optString("id")==o.optString("course_id")}?.optString("course_title").orEmpty()};val score=o.optString("score").ifBlank{"—"};val grade=o.optString("grade").ifBlank{"—"};val st=o.optString("status").ifBlank{"published"};val meta=listOf("Score $score","Grade $grade",o.optString("semester"),o.optString("session"),st).filter{it.isNotBlank()}.joinToString(" · ");list.addView(card("$student · $course",(if(title.isBlank())"" else "$title\n")+meta))};if(shown.size>300)list.addView(card("Showing first 300 matches","Use search/filtering or the full Result Review workspace for larger result sets."))}
}
