package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.widget.*
import android.view.ViewGroup

class ManagementSystemInfoActivity : Activity() {
    private val green = 0xFF0B3D2E.toInt()
    private val cream = 0xFFF7F3EA.toInt()
    private fun label(t:String)=TextView(this).apply{text=t;setTextColor(green);textSize=12f;setTypeface(null,Typeface.BOLD);setPadding(0,18,0,8)}
    private fun info(t:String)=TextView(this).apply{text=t;setTextColor(green);textSize=14f;setPadding(0,0,0,10)}
    override fun onCreate(b:Bundle?){super.onCreate(b)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,24,28,28);setBackgroundColor(cream)}
        root.addView(TextView(this).apply{text="About & System Information";textSize=25f;setTextColor(green);setTypeface(null,Typeface.BOLD)})
        root.addView(info("MTI Umuahia Management App — native Android management layer."))
        root.addView(label("APP VERSION"));root.addView(info("Version 6.8.0  •  Build 279"))
        root.addView(label("ARCHITECTURE"));root.addView(info("The app reuses the existing MTI Supabase backend, authentication, role authorization, RLS policies, storage, RPCs and authoritative web workspaces. It does not create a second institutional backend."))
        root.addView(label("SECURITY MODEL"));root.addView(info("Management access is authenticated through the existing Supabase Auth flow and checked through the existing management-role authorization. No service-role credential is embedded in the Android app."))
        root.addView(label("DATA BOUNDARY"));root.addView(info("Native screens use only established MTI structures. Where the verified backend does not expose a safe native write path, the authoritative web workspace remains the operational destination."))
        root.addView(label("BACKEND CHANGES"));root.addView(info("V279 introduces no database tables, columns, RPCs, roles, policies or storage buckets."))
        val back=Button(this).apply{text="Back to Management Portal";isAllCaps=false;setOnClickListener{finish()}}
        root.addView(back,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(ScrollView(this).apply{addView(root)})
    }
}
