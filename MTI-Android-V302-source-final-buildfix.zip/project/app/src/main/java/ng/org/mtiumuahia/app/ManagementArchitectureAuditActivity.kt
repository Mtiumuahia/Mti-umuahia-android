package ng.org.mtiumuahia.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import android.content.Intent
import android.net.Uri
import android.app.Activity

class ManagementArchitectureAuditActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,32,28,28); setBackgroundColor(Color.rgb(247,243,233)) }
        root.addView(TextView(this).apply { text = "Architecture & Navigation Audit"; textSize = 24f; setTextColor(Color.rgb(20,61,45)); setTypeface(typeface, 1) })
        root.addView(TextView(this).apply { text = "V281 • Application-wide management architecture review"; textSize = 14f; setPadding(0,8,0,24) })
        val items = listOf(
            "Management modules remain separated into focused native workspaces.",
            "Supabase Auth, management role authorization and RLS remain authoritative.",
            "Existing web workspaces remain the source of truth for privileged operations not safely duplicated natively.",
            "No new database tables, RPCs, storage buckets or service-role credentials are introduced by V281.",
            "This screen documents architecture boundaries; it does not claim runtime penetration/security testing."
        )
        items.forEach { t -> root.addView(TextView(this).apply { text = "• $t"; textSize = 16f; setTextColor(Color.DKGRAY); setPadding(0,8,0,8) }) }
        val web = Button(this).apply { text = "Open Management Command Centre"; setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/management-dashboard"))) } }
        root.addView(web, LinearLayout.LayoutParams(-1,-2).apply { topMargin = 24 })
        val close = Button(this).apply { text = "Close"; setOnClickListener { finish() } }
        root.addView(close)
        setContentView(root)
    }
}
