package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementHostelActivity : Activity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"; private val supabaseKey="sb_publishable_oWY2vA2WyoQ4SnLYJHKVbhQ_2V-_TZal"
    private val executor=Executors.newFixedThreadPool(2); private var accessToken:String?=null
    private val rooms=mutableListOf<JSONObject>(); private val allocations=mutableListOf<JSONObject>()
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(16),dp(4),dp(6))}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun card(h:String,b:String,click:(()->Unit)?=null)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(11),dp(14),dp(11));addView(text(h,16f,green,true));addView(text(b,13f,ink));if(click!=null){setOnClickListener{click()};isClickable=true}}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun renderRoot(v:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(v)})}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Content-Type" to "application/json","Accept" to "application/json","Prefer" to "return=representation")
    private fun request(method:String,path:String,payload:String?=null):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod=method;c.connectTimeout=12000;c.readTimeout=18000;headers().forEach{(k,v)->c.setRequestProperty(k,v)};if(payload!=null){c.doOutput=true;c.outputStream.use{it.write(payload.toByteArray())}};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception("Authorised request failed (HTTP $code)");return body}
    override fun onCreate(b:Bundle?){super.onCreate(b);accessToken=intent.getStringExtra("access_token");show()}
    private fun show(){
        val r=root();r.addView(label("MANAGEMENT · STUDENT SERVICES"));r.addView(title("Hostel Administration"));r.addView(text("Manage the existing MTI hostel rooms and student allocation records. The Android workspace uses the existing hostel_rooms and hostel_allocations tables and their management RLS policies; no parallel hostel database is created."))
        r.addView(card("Institutional workflow","Hostel fee: ₦5,000. After payment, the student prints the receipt and reports to the MTI Chief of Staff office for allocation."))
        r.addView(button("Open Full Hostel / Student Services Workspace"){startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/hostel-centre")))})
        val status=text("Loading hostel records…",13f);r.addView(status);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(list)
        r.addView(button("Add Hostel Room"){showRoomEditor(null)});r.addView(button("Refresh"){show()});r.addView(button("Back"){finish()});renderRoot(r)
        executor.execute{try{val ra=JSONArray(request("GET","/rest/v1/hostel_rooms?select=*&order=hostel_name.asc,room_no.asc&limit=1000"));rooms.clear();for(i in 0 until ra.length())rooms.add(ra.getJSONObject(i));val aa=JSONArray(request("GET","/rest/v1/hostel_allocations?select=*&order=created_at.desc&limit=1000"));allocations.clear();for(i in 0 until aa.length())allocations.add(aa.getJSONObject(i));runOnUiThread{status.text="${rooms.size} room records · ${allocations.size} allocation records";render(list)}}catch(x:Exception){runOnUiThread{status.text="Hostel records could not be loaded. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}";list.addView(card("Hostel workspace unavailable","Use the full Hostel / Student Services workspace for the complete management workflow."))}}}
    }
    private fun render(list:LinearLayout){list.removeAllViews();list.addView(label("ROOM INVENTORY"));if(rooms.isEmpty())list.addView(card("No rooms configured","Use Add Hostel Room to create the first room."));rooms.forEach{o->val name=o.optString("hostel_name");val no=o.optString("room_no");val cap=o.optInt("capacity",1);val occ=o.optInt("occupied",0);val st=o.optString("status");list.addView(card("$name · Room $no","Capacity $cap · Occupied $occ · $st"){showRoomEditor(o)})};list.addView(label("ALLOCATIONS"));if(allocations.isEmpty())list.addView(card("No allocation records","Student allocation records will appear here when available."));allocations.take(100).forEach{o->val status=o.optString("status");val student=o.optString("user_id");val room=o.optString("room_no").ifBlank{"Unassigned"};val hostel=o.optString("hostel_name");val session=o.optString("session");list.addView(card("$status · $room","Student: $student\n${if(hostel.isBlank())"" else "$hostel · "}$session"){showAllocationEditor(o)})}}
    private fun showRoomEditor(o: JSONObject?) {
        val r = root()
        val edit = o != null
        r.addView(label(if (edit) "EDIT ROOM" else "NEW ROOM"))
        r.addView(title(if (edit) "Update Hostel Room" else "Add Hostel Room"))

        fun field(hintText: String, value: String): EditText {
            val e = EditText(this)
            e.hint = hintText
            e.setText(value)
            e.setTextColor(ink)
            e.isSingleLine = true
            r.addView(e, LinearLayout.LayoutParams(-1, dp(54)).apply {
                setMargins(0, dp(4), 0, dp(4))
            })
            return e
        }

        val hostel = field("Hostel name", o?.optString("hostel_name") ?: "")
        val room = field("Room number", o?.optString("room_no") ?: "")
        val cap = field("Capacity", o?.optString("capacity") ?: "1")
        val occ = field("Occupied", o?.optString("occupied") ?: "0")
        val status = field("Status (available/full/maintenance)", o?.optString("status") ?: "available")
        val msg = text("")
        r.addView(msg)

        r.addView(button(if (edit) "Save Changes" else "Create Room") {
            if (hostel.text.toString().trim().isBlank() || room.text.toString().trim().isBlank()) {
                msg.text = "Hostel name and room number are required."
                return@button
            }
            val payload = JSONObject()
                .put("hostel_name", hostel.text.toString().trim())
                .put("room_no", room.text.toString().trim())
                .put("capacity", cap.text.toString().toIntOrNull() ?: 1)
                .put("occupied", occ.text.toString().toIntOrNull() ?: 0)
                .put("status", status.text.toString().trim().ifBlank { "available" })
            msg.text = "Saving…"
            executor.execute {
                try {
                    if (edit) {
                        request("PATCH", "/rest/v1/hostel_rooms?id=eq.${o!!.optString("id")}", payload.toString())
                    } else {
                        request("POST", "/rest/v1/hostel_rooms", payload.toString())
                    }
                    runOnUiThread {
                        Toast.makeText(this, "Room saved.", Toast.LENGTH_SHORT).show()
                        show()
                    }
                } catch (x: Exception) {
                    runOnUiThread {
                        msg.text = "Could not save room. Request failed. Please use the authoritative MTI workspace if the problem persists."
                    }
                }
            }
        })
        r.addView(button("Cancel") { show() })
        renderRoot(r)
    }

    private fun showAllocationEditor(o: JSONObject) {
        val r = root()
        r.addView(label("ALLOCATION"))
        r.addView(title("Update Student Allocation"))
        r.addView(text("Student account: ${o.optString("user_id")}\nCurrent room: ${o.optString("room_no").ifBlank { "Unassigned" }}\nSession: ${o.optString("session")}"))

        val status = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@ManagementHostelActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("pending", "approved", "rejected")
            )
            setSelection(arrayOf("pending", "approved", "rejected").indexOf(o.optString("status")).coerceAtLeast(0))
        }
        r.addView(status, LinearLayout.LayoutParams(-1, dp(52)))

        val room = EditText(this).apply {
            hint = "Room number"
            setText(o.optString("room_no"))
            setTextColor(ink)
            isSingleLine = true
        }
        r.addView(room, LinearLayout.LayoutParams(-1, dp(54)))

        val hostel = EditText(this).apply {
            hint = "Hostel name"
            setText(o.optString("hostel_name"))
            setTextColor(ink)
            isSingleLine = true
        }
        r.addView(hostel, LinearLayout.LayoutParams(-1, dp(54)))

        val msg = text("")
        r.addView(msg)
        r.addView(button("Save Allocation") {
            val payload = JSONObject()
                .put("status", status.selectedItem.toString())
                .put("room_no", room.text.toString().trim().ifBlank { JSONObject.NULL })
                .put("hostel_name", hostel.text.toString().trim().ifBlank { JSONObject.NULL })
            executor.execute {
                try {
                    request("PATCH", "/rest/v1/hostel_allocations?id=eq.${o.optString("id")}", payload.toString())
                    runOnUiThread {
                        Toast.makeText(this, "Allocation updated.", Toast.LENGTH_SHORT).show()
                        show()
                    }
                } catch (x: Exception) {
                    runOnUiThread {
                        msg.text = "Could not update allocation. Request failed. Please use the authoritative MTI workspace if the problem persists."
                    }
                }
            }
        })
        r.addView(button("Cancel") { show() })
        renderRoot(r)
    }

}
