package ng.org.mtiumuahia.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.content.res.ColorStateList
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var baseUrl: String
    private var activeWebView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newFixedThreadPool(2)
    private val cream = Color.rgb(246, 241, 230)
    private val green = Color.rgb(11, 61, 46)
    private val darkGreen = Color.rgb(6, 40, 30)
    private val gold = Color.rgb(184, 149, 74)
    private val ink = Color.rgb(23, 53, 44)
    private val white = Color.WHITE
    private val muted = Color.rgb(92, 103, 98)
    private val supabaseUrl = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabasePublishableKey = "sb_publishable_oWY2vA2WyoQ4SnLYJHKVbhQ_2V-_TZal"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        baseUrl = getString(R.string.mti_base_url).trimEnd('/')
        findViewById<Button>(R.id.navHome).setOnClickListener { showHome() }
        findViewById<Button>(R.id.navExplore).setOnClickListener { showExplore() }
        findViewById<Button>(R.id.navPortal).setOnClickListener { showPortal() }
        findViewById<Button>(R.id.navAI).setOnClickListener { openWeb("/#ai-assistant") }
        showHome()
    }

    override fun onDestroy(){
        handler.removeCallbacksAndMessages(null)
        activeWebView?.apply { stopLoading(); destroy() }
        activeWebView=null
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun offlineMessage(action: String = "Please check your internet connection and try again."): String =
        "MTI is temporarily offline. $action"

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun title(text: String, size: Float = 26f): TextView = TextView(this).apply { this.text=text; textSize=size; setTextColor(ink); typeface=Typeface.create("sans",Typeface.BOLD); setPadding(dp(20),dp(14),dp(20),dp(6)) }
    private fun body(text: String, color: Int = ink): TextView = TextView(this).apply { this.text=text; textSize=15f; setTextColor(color); setPadding(dp(20),dp(8),dp(20),dp(10)); setLineSpacing(0f,1.12f) }
    private fun sectionLabel(text: String): TextView = TextView(this).apply { this.text=text.uppercase(); textSize=12f; letterSpacing=.12f; setTextColor(gold); typeface=Typeface.DEFAULT_BOLD; setPadding(dp(20),dp(18),dp(20),dp(4)) }
    private fun action(text: String,onClick:()->Unit): Button = Button(this).apply { this.text=text; textSize=14f; isAllCaps=false; setOnClickListener{onClick()}; setTextColor(white); backgroundTintList=ColorStateList.valueOf(green); minHeight=dp(50); setPadding(dp(18),0,dp(18),0); layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(dp(20),dp(5),dp(20),dp(5))} }
    private fun dashboardCard(label:String,description:String,onClick:()->Unit):LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);setPadding(dp(14),dp(12),dp(14),dp(10));isClickable=true;isFocusable=true;setOnClickListener{onClick()};elevation=dp(2).toFloat();addView(TextView(this@MainActivity).apply{text=label;textSize=16f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD});addView(TextView(this@MainActivity).apply{text=description;textSize=12.5f;setTextColor(ink);setPadding(0,dp(5),0,0)})}
    private fun row(vararg cards:View):LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(20),dp(5),dp(20),dp(5));cards.forEach{addView(it,LinearLayout.LayoutParams(0,dp(105),1f).apply{marginEnd=dp(6)})}}
    private fun scrollRoot():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream)}

    private fun showHome(){
        activeWebView=null; content.removeAllViews(); val scroll=ScrollView(this).apply{isFillViewport=true}; val root=scrollRoot()
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(green);setPadding(dp(18),dp(20),dp(18),dp(24))}
        hero.addView(ImageView(this).apply{setImageResource(R.drawable.mti_logo);adjustViewBounds=true;contentDescription="MTI Umuahia logo";layoutParams=LinearLayout.LayoutParams(-1,dp(128)).apply{bottomMargin=dp(8)}})
        hero.addView(TextView(this).apply{text="MTI · UMUAHIA";textSize=13f;letterSpacing=.12f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(dp(4),0,dp(4),dp(5))})
        hero.addView(TextView(this).apply{text="Rooted in faith.\nGrowing in truth.";textSize=29f;setTextColor(white);typeface=Typeface.create("sans",Typeface.BOLD);setPadding(dp(4),0,dp(4),dp(8))})
        hero.addView(TextView(this).apply{text="Methodist Theological Institute, Umuahia";textSize=15f;setTextColor(white);setPadding(dp(4),0,dp(4),0)})
        root.addView(hero)
        root.addView(sectionLabel("MTI mobile dashboard")); root.addView(body("A focused mobile gateway to MTI Umuahia. Browse public institutional information, live public updates, admissions and events, or enter the existing secure portals.")); root.addView(action("Open MTI Website"){openWeb("/")})
        root.addView(sectionLabel("Discover MTI")); root.addView(row(dashboardCard("About MTI","History, identity and institutional information."){openWeb("/#about")},dashboardCard("Leadership","Rector, registrar and institutional leadership."){showLeadership()})); root.addView(row(dashboardCard("Programmes","Explore MTI academic pathways and programme tracks."){showProgrammes()},dashboardCard("Admissions","Admission status, entry modes and application guidance."){showAdmissions()})); root.addView(row(dashboardCard("News","Institutional news and announcements."){showPublicFeed("news")},dashboardCard("Events","Upcoming and recent MTI events."){showPublicFeed("events")})); root.addView(row(dashboardCard("Gallery","Photos and institutional moments."){showGallery()},dashboardCard("SUG","Student Union Government information."){showSUG()}))
        root.addView(sectionLabel("Latest public updates"))
        val liveBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(4),dp(20),dp(8))}
        liveBox.addView(body("Loading approved public News and Events…"))
        root.addView(liveBox)
        root.addView(sectionLabel("Quick access")); root.addView(action("Student / Lecturer / Applicant Portals"){showPortal()}); root.addView(action("MTI AI Assistant"){openWeb("/#ai-assistant")}); root.addView(action("Visit & Contact MTI"){showVisitContact()}); root.addView(body("The app reuses the existing MTI website and Supabase architecture. No second authentication or database system is created."))
        scroll.addView(root); content.addView(scroll); loadLiveUpdates(liveBox)
    }

    private fun showExplore(){activeWebView=null;content.removeAllViews();val scroll=ScrollView(this);val root=scrollRoot();root.addView(title("Explore MTI",28f));root.addView(body("Move directly to public sections of the MTI Umuahia website, with live updates available on the home dashboard."));root.addView(action("About MTI"){openWeb("/#about")});root.addView(action("Leadership"){showLeadership()});root.addView(action("Governance & Policies"){showGovernance()} );root.addView(action("Programmes"){showProgrammes()});root.addView(action("Admissions"){showAdmissions()});root.addView(action("News"){showPublicFeed("news")});root.addView(action("Events"){showPublicFeed("events")});root.addView(action("Gallery"){showGallery()});root.addView(action("SUG"){showSUG()});root.addView(action("Visit / Contact"){showVisitContact()});root.addView(action("Full Website"){openWeb("/")});scroll.addView(root);content.addView(scroll)}
    private fun showLeadership(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("Leadership",28f))
        root.addView(body("Meet the people entrusted with the academic, spiritual and administrative life of Methodist Theological Institute, Umuahia. Published leadership profiles are loaded from the existing public MTI content system when available."))
        root.addView(sectionLabel("Serving the Institute"))
        root.addView(body("MTI is served through recognised leadership and structures supporting theological education, spiritual formation, academic development and the wider mission of the Church."))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(body("Loading current leadership profiles…")); root.addView(box)
        root.addView(sectionLabel("Governance"))
        root.addView(body("Academic, spiritual and administrative life is strengthened by clear expectations, accountable leadership and respect for the Methodist Church and the wider academic community."))
        root.addView(action("View Governance & Policies"){showGovernance()})
        root.addView(action("Open Full MTI Leadership Page"){openWeb("/#leadership")})
        scroll.addView(root); content.addView(scroll)
        executor.execute{
            val leaders=fetchLeadership()
            handler.post{
                box.removeAllViews()
                if(leaders.isEmpty()){
                    leadershipCard(box,"Very Rev. Kingsley Raphael Nwaike Ph.D.","Rector","Current leadership profile details are published by MTI through its official leadership page.",null)
                    leadershipCard(box,"Very Rev. Washington Okpara","Registrar","Current leadership profile details are published by MTI through its official leadership page.",null)
                    box.addView(body("Live leadership profiles were not available from the public content endpoint at this time. The official MTI page remains the current reference."))
                } else leaders.forEach{leadershipCard(box,it.name,it.role,it.bio,it.photoUrl)}
            }
        }
    }

    private fun leadershipCard(root:LinearLayout,name:String,role:String?,bio:String?,photoUrl:String?){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);setPadding(dp(16),dp(14),dp(16),dp(14));elevation=dp(1).toFloat();layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(5),dp(20),dp(5))}}
        card.addView(TextView(this).apply{text=name;textSize=18f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD})
        role?.takeIf{it.isNotBlank()}?.let{card.addView(TextView(this).apply{text=it;textSize=14f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(5),0,0)})}
        bio?.takeIf{it.isNotBlank()}?.let{card.addView(TextView(this).apply{text=it;textSize=13.5f;setTextColor(ink);setPadding(0,dp(7),0,0);setLineSpacing(0f,1.12f)})}
        if(!photoUrl.isNullOrBlank()) card.addView(TextView(this).apply{text="Photo available on the official MTI leadership page.";textSize=12f;setTextColor(ink);setPadding(0,dp(6),0,0)})
        root.addView(card)
    }

    private fun fetchLeadership():List<LeaderItem>{
        return try{
            val select=URLEncoder.encode("*","UTF-8")
            val url=URL("$supabaseUrl/rest/v1/leadership?select=$select&order=sort_order.asc&limit=20")
            val c=url.openConnection() as HttpURLConnection
            c.requestMethod="GET";c.connectTimeout=10000;c.readTimeout=10000
            c.setRequestProperty("apikey",supabasePublishableKey);c.setRequestProperty("Authorization","Bearer $supabasePublishableKey");c.setRequestProperty("Accept","application/json")
            if(c.responseCode !in 200..299){c.disconnect();return emptyList()}
            val text=c.inputStream.bufferedReader().use{it.readText()};c.disconnect();val arr=JSONArray(text);val out=mutableListOf<LeaderItem>()
            for(i in 0 until arr.length()){
                val o=arr.optJSONObject(i)?:continue
                val name=first(o,"name","full_name","title")?:continue
                val role=first(o,"role","position","office")
                val bio=first(o,"bio","biography","description")
                val photo=first(o,"photo_url","image_url","photo")
                out.add(LeaderItem(name,role,bio,photo))
            }
            out
        }catch(_:Exception){emptyList()}
    }

    private fun showGovernance(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("Governance & Policies",28f))
        root.addView(body("Explore the principles, policies and institutional standards that help MTI Umuahia serve students, staff, the Church and the wider community with integrity."))
        governanceCard(root,"01 · GOVERNANCE","Leadership & oversight","The Institute is served through recognised leadership and appropriate structures for academic, spiritual and administrative oversight.")
        governanceCard(root,"02 · ACADEMIC","Academic standards","Students and staff are expected to uphold academic honesty, responsible scholarship, respectful conduct and the standards attached to their programmes.")
        governanceCard(root,"03 · COMMUNITY","Conduct & care","MTI seeks a community marked by Christian character, mutual respect, safety, service and responsible use of Institute resources.")
        root.addView(sectionLabel("Official documents"))
        root.addView(body("Programme regulations, student handbooks, current fees, admission requirements and other formal policies should be obtained or confirmed directly with MTI. The app does not replace official institutional documents."))
        root.addView(action("Open MTI Governance Page"){openWeb("/#governance")})
        root.addView(action("Open MTI Leadership Page"){openWeb("/#leadership")})
        scroll.addView(root); content.addView(scroll)
    }

    private fun governanceCard(root:LinearLayout,label:String,name:String,description:String){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);setPadding(dp(16),dp(14),dp(16),dp(14));elevation=dp(1).toFloat();layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(5),dp(20),dp(5))}}
        card.addView(TextView(this).apply{text=label;textSize=11f;letterSpacing=.1f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD})
        card.addView(TextView(this).apply{text=name;textSize=17f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(5),0,0)})
        card.addView(TextView(this).apply{text=description;textSize=13.5f;setTextColor(ink);setPadding(0,dp(7),0,0);setLineSpacing(0f,1.12f)})
        root.addView(card)
    }

    private fun showProgrammes(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("Programmes",28f))
        root.addView(body("Explore the academic and ministerial pathways published by MTI Umuahia. The detailed curriculum and current programme information remain on the official MTI website."))
        root.addView(sectionLabel("Affiliation note"))
        root.addView(body("Following approval by the Nigerian Universities Commission (NUC) for Wesley University Ondo to run B.A. Theology, MTI Umuahia moved its affiliation to Wesley University Ondo by directive of the Church."))

        root.addView(sectionLabel("Undergraduate"))
        programmeCard(root,"Bachelor-level theological formation", "The undergraduate programme is structured across four levels, with theological, biblical, ministry, language, ethics, history and Christian-life studies. The published curriculum includes subjects such as Christian Theology, New Testament, Christian Ethics, Greek, Hebrew, Church and Society, Christian Leadership and a final-year project.")

        root.addView(sectionLabel("Postgraduate"))
        programmeCard(root,"Postgraduate Diploma in Ministry (PGDM)", "A postgraduate ministerial formation pathway. MTI's published information describes PGDM as one of the postgraduate routes for ministerial preparation.")
        programmeCard(root,"Master of Divinity (M.Div.)", "A postgraduate ministry and theological formation pathway. The published MTI programme page identifies M.Div. alongside PGDM and describes full-time study for graduates entering ministry.")

        root.addView(sectionLabel("Advanced theological study"))
        programmeCard(root,"Master of Theology (M.Th.)", "Offered through Wesley University Ondo for holders of a basic university or seminary degree such as a B.A. in Religious Studies or Theology, or equivalent. Published tracks include Biblical Studies (Old Testament), Biblical Studies (New Testament) and Wesleyan Studies.")
        programmeCard(root,"Doctor of Ministry (D.Min.)", "Designed for people currently engaged in ministry, both lay and ordained, with emphasis on theological reflection on ministry praxis, spiritual growth and ministry competence. Published tracks include Social Development and other ministry-focused areas.")

        root.addView(sectionLabel("Distance / E-Learning"))
        programmeCard(root,"Conversion Programmes", "For holders of NCE, HND and B.Th. who wish to upgrade to bachelor's degrees in relevant fields.")
        programmeCard(root,"Postgraduate Diploma in Education (PGDE)", "A professional teaching qualification pathway described on the MTI programmes page.")
        programmeCard(root,"Professional Postgraduate Programmes", "Advanced career-oriented pathways in areas including Education, Theology, Management and development sectors.")
        programmeCard(root,"College of Social & Management Sciences", "Published areas include Accounting, Economics, Public Administration, International Relations & Diplomacy, Hospitality Management & Tourism, Mass Communication, Sociology, Political Science, Office Management and Entrepreneurship.")
        programmeCard(root,"College of Education", "Published areas include Early Childhood Education, Library and Information Science, Social Studies Education, Geography & Environmental Education and Christian Religious Education.")
        programmeCard(root,"College of Arts", "Published information includes B.A. in Theology, Bachelor and Masters in Theology (M.Th.) and Doctoral Degree in Theology (D.Min.).")

        root.addView(sectionLabel("Executive & certificate"))
        programmeCard(root,"Executive Diploma in Theology (E.D.Th.)", "Designed for lay and ordained Christians seeking sound knowledge of the Gospel and theology. Published contacts include Homiletics, Christology, Ecclesiology, Discipleship & Evangelism, Introduction to Theology, New Testament, Christian Leadership and Church Administration.")
        programmeCard(root,"Certificate programmes", "Published certificate opportunities include Church Leadership, Youth Ministry, Entrepreneurship, Women Ministry and Children's Training.")

        root.addView(sectionLabel("Programme details"))
        root.addView(body("Programme regulations, current requirements, fees, course structures and availability can change. Use the official MTI Programmes page as the current public reference."))
        root.addView(action("Open Full MTI Programmes Page"){openWeb("/#programmes")})
        scroll.addView(root); content.addView(scroll)
    }

    private fun programmeCard(root:LinearLayout,name:String,description:String){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);setPadding(dp(16),dp(14),dp(16),dp(14));elevation=dp(1).toFloat();layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(5),dp(20),dp(5))}}
        card.addView(TextView(this).apply{text=name;textSize=17f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD})
        card.addView(TextView(this).apply{text=description;textSize=13.5f;setTextColor(ink);setPadding(0,dp(7),0,0);setLineSpacing(0f,1.12f)})
        root.addView(card)
    }

    private fun showAdmissions(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("Admissions",28f))
        root.addView(body("Explore the MTI Umuahia admission process, entry modes and the steps applicants should expect before admission is granted."))
        root.addView(sectionLabel("Admission status"))
        root.addView(body("Admission availability is controlled by MTI. Check the live MTI Admissions page for the current admission status before starting an application."))
        root.addView(action("Check Current Admission Status"){openWeb("/#admissions")})
        root.addView(sectionLabel("Entry modes"))
        val modes=listOf("O Level","Degree Holder","Master's / Postgraduate","Doctoral","Distance / E-Learning","Executive","Other")
        modes.forEach{m->root.addView(bullet(m))}
        root.addView(sectionLabel("What happens after application"))
        listOf(
            "Submit the online MTI admission application when admission is open.",
            "Do not create a Student Portal password immediately after submitting the application.",
            "Applicants later attend the MTI Selection Conference process as instructed by the Institute.",
            "The selection process includes an examination, submission/verification of required documents and details, interview, and medical/physical checks.",
            "Admission is determined through the Institute's management process and the relevant Methodist Church Nigeria conference process.",
            "If admitted, MTI sends the applicant an admission notification containing an MTI registration number and a one-time activation token.",
            "The admitted student then uses the registration number and activation token to activate the Student Portal account and set a password."
        ).forEachIndexed{index,text->root.addView(numbered(index+1,text))}
        root.addView(sectionLabel("Apply / continue"))
        root.addView(action("Open MTI Admissions Page"){openWeb("/#admissions")})
        root.addView(body("The Android app does not create a separate admissions database or applicant account system. The existing MTI website and Supabase backend remain the source of truth."))
        scroll.addView(root); content.addView(scroll)
    }

    private fun bullet(text:String):TextView=TextView(this).apply{
        this.text="•  $text"; textSize=14f; setTextColor(ink); setPadding(dp(24),dp(5),dp(20),dp(5)); setLineSpacing(0f,1.1f)
    }
    private fun numbered(number:Int,text:String):TextView=TextView(this).apply{
        this.text="$number.  $text"; textSize=14f; setTextColor(ink); setPadding(dp(24),dp(6),dp(20),dp(6)); setLineSpacing(0f,1.1f)
    }

    private fun showGallery(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("Gallery",28f))
        root.addView(body("Explore photographs and media from life, worship, learning, events and community at MTI. The app reads the existing public gallery records; no second media library is created."))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(body("Loading gallery…")); root.addView(box)
        root.addView(action("Open Full MTI Gallery"){openWeb("/gallery")})
        scroll.addView(root); content.addView(scroll)
        executor.execute{
            val items=fetchGallery(40)
            handler.post{box.removeAllViews(); if(items.isEmpty()){box.addView(body("No public gallery media is available right now. Open the MTI Gallery for the current collection."))} else items.forEach{addGalleryCard(box,it)}}
        }
    }

    private fun addGalleryCard(box:LinearLayout,item:GalleryItem){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(12),dp(12),dp(12),dp(12));layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(6),dp(20),dp(6))}}
        val media=ImageView(this).apply{adjustViewBounds=true;setBackgroundColor(Color.rgb(232,228,218));contentDescription=item.title?:"MTI Gallery";layoutParams=LinearLayout.LayoutParams(-1,dp(190))}
        card.addView(media)
        val name=item.title?.takeIf{it.isNotBlank()}?:"MTI Gallery media"
        card.addView(TextView(this).apply{text=name;textSize=16f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(10),0,dp(2))})
        item.category?.takeIf{it.isNotBlank()}?.let{card.addView(body("Category: $it"))}
        item.createdAt?.takeIf{it.isNotBlank()}?.let{card.addView(body("Date: $it"))}
        if(item.mediaType=="video") card.addView(action("Watch / Open Video"){openExternal(item.url)}) else card.addView(action("View Full Image"){openExternal(item.url)})
        box.addView(card)
        executor.execute{val bmp=downloadBitmap(item.url);handler.post{if(bmp!=null)media.setImageBitmap(bmp)}}
    }

    private fun fetchGallery(limit:Int):List<GalleryItem>{
        return try{
            val url=URL("$supabaseUrl/rest/v1/gallery_photos?select=id,image_url,title,media_type,created_at,category&order=created_at.desc&limit=$limit")
            val c=url.openConnection() as HttpURLConnection;c.requestMethod="GET";c.connectTimeout=10000;c.readTimeout=10000
            c.setRequestProperty("apikey",supabasePublishableKey);c.setRequestProperty("Authorization","Bearer $supabasePublishableKey");c.setRequestProperty("Accept","application/json")
            if(c.responseCode !in 200..299)return emptyList();val arr=JSONArray(c.inputStream.bufferedReader().use{it.readText()});c.disconnect();val out=mutableListOf<GalleryItem>()
            for(i in 0 until arr.length()){val o=arr.optJSONObject(i)?:continue;val u=o.optString("image_url").trim();if(u.isBlank())continue;out.add(GalleryItem(u,first(o,"title"),first(o,"media_type"),first(o,"created_at"),first(o,"category")))};out
        }catch(_:Exception){emptyList()}
    }

    private fun showSUG(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("SUG Executive Council",28f))
        root.addView(body("The official Students’ Union Government directory of Methodist Theological Institute, Umuahia. Meet the student leaders serving the MTI community."))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};box.addView(body("Loading SUG directory…"));root.addView(box)
        root.addView(action("Open Full SUG Directory"){openWeb("/sug-executives")})
        scroll.addView(root);content.addView(scroll)
        executor.execute{val items=fetchSUG(50);handler.post{box.removeAllViews();if(items.isEmpty())box.addView(body("SUG executive profiles will be published here. Open the full directory for the current official listing.")) else items.forEach{addSUGCard(box,it)}}}
    }

    private fun addSUGCard(box:LinearLayout,item:SUGItem){
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(12),dp(12),dp(12),dp(12));layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(6),dp(20),dp(6))}}
        val photo=ImageView(this).apply{adjustViewBounds=true;setBackgroundColor(Color.rgb(232,228,218));contentDescription=item.name;layoutParams=LinearLayout.LayoutParams(-1,dp(210))};card.addView(photo)
        card.addView(TextView(this).apply{text=item.office;textSize=12f;letterSpacing=.08f;setTextColor(gold);typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(10),0,dp(2))})
        card.addView(TextView(this).apply{text=item.name;textSize=18f;setTextColor(green);typeface=Typeface.DEFAULT_BOLD})
        card.addView(body(item.bio?.takeIf{it.isNotBlank()}?:"Official biography not yet published."))
        box.addView(card)
        executor.execute{val bmp=downloadBitmap(item.photoUrl);handler.post{if(bmp!=null)photo.setImageBitmap(bmp)else photo.setImageResource(R.drawable.mti_logo)}}
    }

    private fun fetchSUG(limit:Int):List<SUGItem>{
        return try{
            val url=URL("$supabaseUrl/rest/v1/sug_executives_v142?select=id,full_name,office,biography,photo_url,display_order&active=eq.true&order=display_order.asc,full_name.asc&limit=$limit")
            val c=url.openConnection() as HttpURLConnection;c.requestMethod="GET";c.connectTimeout=10000;c.readTimeout=10000
            c.setRequestProperty("apikey",supabasePublishableKey);c.setRequestProperty("Authorization","Bearer $supabasePublishableKey");c.setRequestProperty("Accept","application/json")
            if(c.responseCode !in 200..299)return emptyList();val arr=JSONArray(c.inputStream.bufferedReader().use{it.readText()});c.disconnect();val out=mutableListOf<SUGItem>()
            for(i in 0 until arr.length()){val o=arr.optJSONObject(i)?:continue;val name=first(o,"full_name")?:continue;val office=first(o,"office")?:continue;out.add(SUGItem(name,office,first(o,"biography"),first(o,"photo_url")?:""))};out
        }catch(_:Exception){emptyList()}
    }

    private fun downloadBitmap(rawUrl:String):android.graphics.Bitmap?{return try{val c=URL(rawUrl).openConnection() as HttpURLConnection;c.connectTimeout=8000;c.readTimeout=8000;c.doInput=true;c.connect();val b=android.graphics.BitmapFactory.decodeStream(c.inputStream);c.disconnect();b}catch(_:Exception){null}}
    private fun openExternal(rawUrl:String){if(rawUrl.isBlank())return;startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(rawUrl)))}
    private data class GalleryItem(val url:String,val title:String?,val mediaType:String?,val createdAt:String?,val category:String?)
    private data class SUGItem(val name:String,val office:String,val bio:String?,val photoUrl:String)

    private fun showVisitContact(){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("Visit & Contact MTI",28f))
        root.addView(body("Connect with Methodist Theological Institute, Umuahia for admissions, academic information, visiting arrangements and institutional enquiries."))
        root.addView(sectionLabel("VISIT THE INSTITUTE"))
        root.addView(infoCard("MTI Umuahia","Methodist Theological Institute, Mission Hill, Umuahia, Abia State, Nigeria.","For official directions and visiting arrangements, please contact the Institute."))
        root.addView(sectionLabel("GET STARTED"))
        root.addView(action("Admissions"){showAdmissions()})
        root.addView(action("Academic Programmes"){showProgrammes()})
        root.addView(action("Latest News"){showPublicFeed("news")})
        root.addView(action("Upcoming Events"){showPublicFeed("events")})
        root.addView(sectionLabel("OFFICIAL WEBSITE"))
        root.addView(body("The public website remains the authoritative place for current contact channels and official Institute updates."))
        root.addView(action("Open Full Contact Page"){openWeb("/contact")})
        root.addView(action("Open Full MTI Website"){openWeb("/")})
        scroll.addView(root); content.addView(scroll)
    }

    private fun infoCard(heading:String,text:String,note:String):View{
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);setPadding(dp(4),dp(8),dp(4),dp(8));elevation=dp(2).toFloat()}
        box.addView(sectionLabel(heading))
        box.addView(title(heading,20f))
        box.addView(body(text))
        box.addView(body(note, muted))
        box.layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(8),dp(20),dp(12))}
        return box
    }

    private fun showPortal(){
        activeWebView=null; content.removeAllViews(); val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(title("MTI Portals",28f)); root.addView(body("Choose the secure workspace that matches your MTI role. Existing Supabase authentication and permissions remain the source of truth."))
        root.addView(sectionLabel("ACADEMIC PORTALS"))
        root.addView(action("Student Portal"){startActivity(Intent(this, StudentPortalActivity::class.java))})
        root.addView(action("Lecturer Portal"){startActivity(Intent(this, LecturerPortalActivity::class.java))})
        root.addView(sectionLabel("OTHER ACCESS")); root.addView(action("Applicant Portal"){openWeb("/applicant-portal")}); root.addView(action("Management Portal"){startActivity(Intent(this, ManagementPortalActivity::class.java))}); root.addView(action("Back to Home"){showHome()})
        scroll.addView(root); content.addView(scroll)
    }

    private fun loadLiveUpdates(container:LinearLayout){
        if(!isNetworkAvailable()){
            container.removeAllViews()
            container.addView(body(offlineMessage("Live News and Events require an internet connection.")))
            container.addView(action("Retry live updates"){loadLiveUpdates(container)})
            return
        }
        executor.execute{
            val news=fetchPublicTable("news",6)
            val events=fetchPublicTable("events",6)
            handler.post{container.removeAllViews(); if(news.isEmpty()&&events.isEmpty()){container.addView(body("Live updates could not be reached right now."));container.addView(action("Retry live updates"){loadLiveUpdates(container)});return@post}; if(news.isNotEmpty()){container.addView(sectionLabel("News"));news.forEach{container.addView(updateCard(it,"news"))}}; if(events.isNotEmpty()){container.addView(sectionLabel("Events"));events.forEach{container.addView(updateCard(it,"events"))}}}
        }
    }

    private fun fetchPublicTable(table:String,limit:Int):List<PublicItem>{
        return try{
            val select=URLEncoder.encode("*","UTF-8")
            val url=URL("$supabaseUrl/rest/v1/$table?select=$select&limit=$limit")
            val c=url.openConnection() as HttpURLConnection
            c.requestMethod="GET";c.connectTimeout=10000;c.readTimeout=10000
            c.setRequestProperty("apikey",supabasePublishableKey);c.setRequestProperty("Authorization","Bearer $supabasePublishableKey");c.setRequestProperty("Accept","application/json")
            if(c.responseCode !in 200..299)return emptyList()
            val text=c.inputStream.bufferedReader().use{it.readText()};c.disconnect();val arr=JSONArray(text);val out=mutableListOf<PublicItem>()
            for(i in 0 until arr.length()){val o=arr.optJSONObject(i)?:continue;val title=first(o,"title","name","headline","event_title")?:continue;val desc=first(o,"excerpt","summary","description","content","body");val date=first(o,"published_at","event_date","date","starts_at","created_at");out.add(PublicItem(title,desc,date))}
            out
        }catch(_:Exception){emptyList()}
    }
    private fun first(o:org.json.JSONObject,vararg keys:String):String?{for(k in keys){if(o.has(k)&&!o.isNull(k)){val v=o.optString(k).trim();if(v.isNotEmpty()&&v!="null")return v}};return null}
    private fun showPublicFeed(type:String){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        val label=if(type=="news")"News" else "Events"
        root.addView(title(label,28f))
        root.addView(body("Live approved public content from the existing MTI website backend."))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(body("Loading $label…")); root.addView(box)
        root.addView(action("Open MTI $label page"){openWeb(if(type=="news")"/#news" else "/#events")})
        scroll.addView(root); content.addView(scroll)
        if(!isNetworkAvailable()){
            box.removeAllViews()
            box.addView(body(offlineMessage("Live $label content requires an internet connection.")))
            box.addView(action("Retry $label"){showPublicFeed(type)})
            return
        }
        executor.execute{
            val items=fetchPublicTable(type,30)
            handler.post{box.removeAllViews(); if(items.isEmpty()){box.addView(body("The live $label service could not be reached right now."));box.addView(action("Retry $label"){showPublicFeed(type)})} else items.forEach{box.addView(updateCard(it,type))}}
        }
    }

    private fun showPublicDetail(item:PublicItem,type:String){
        activeWebView=null; content.removeAllViews()
        val scroll=ScrollView(this); val root=scrollRoot()
        root.addView(sectionLabel(if(type=="news")"News" else "Event"))
        root.addView(title(item.title,26f))
        item.date?.takeIf{it.isNotBlank()}?.let{root.addView(body("Date / Published: $it", ink))}
        item.description?.takeIf{it.isNotBlank()}?.let{root.addView(body(it, ink))}
        root.addView(action("Open full MTI section"){openWeb(if(type=="news")"/#news" else "/#events")})
        root.addView(action("Back to ${if(type=="news")"News" else "Events"}"){showPublicFeed(type)})
        scroll.addView(root); content.addView(scroll)
    }

    private fun updateCard(item:PublicItem,type:String):TextView=TextView(this).apply{setBackgroundColor(white);setTextColor(ink);textSize=14f;setPadding(dp(16),dp(12),dp(16),dp(12));elevation=dp(1).toFloat();text=(if(type=="news")"NEWS" else "EVENT")+"\n"+item.title+if(item.date!=null)"\n"+item.date else "";setOnClickListener{showPublicDetail(item, type)};layoutParams=LinearLayout.LayoutParams(-1,LinearLayout.LayoutParams.WRAP_CONTENT).apply{setMargins(dp(20),dp(4),dp(20),dp(4))}}
    private data class PublicItem(val title:String,val description:String?,val date:String?)
    private data class LeaderItem(val name:String,val role:String?,val bio:String?,val photoUrl:String?)

    private fun openExternalUrl(url:String){runCatching{val uri=Uri.parse(url);if(uri.scheme=="https"||uri.scheme=="http"||uri.scheme=="mailto"||uri.scheme=="tel")startActivity(Intent(Intent.ACTION_VIEW,uri))}}
    @SuppressLint("SetJavaScriptEnabled") private fun openWeb(path:String){
        content.removeAllViews()
        val web=WebView(this)
        activeWebView=web
        WebView.setWebContentsDebuggingEnabled(false)
        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        web.settings.loadsImagesAutomatically=true
        web.settings.allowFileAccess=false
        web.settings.allowContentAccess=false
        web.settings.allowFileAccessFromFileURLs=false
        web.settings.allowUniversalAccessFromFileURLs=false
        web.settings.mixedContentMode=android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.settings.mediaPlaybackRequiresUserGesture=true
        if(android.os.Build.VERSION.SDK_INT>=26) web.settings.safeBrowsingEnabled=true
        web.settings.setSupportZoom(false)
        web.webViewClient=object:WebViewClient(){
            override fun onReceivedError(view:WebView,request:WebResourceRequest,error:android.webkit.WebResourceError){
                if(request.isForMainFrame){handler.post{Toast.makeText(this@MainActivity,offlineMessage("The MTI website could not be reached. Check your connection and try again."),Toast.LENGTH_LONG).show()}}
            }
            override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean{
                val uri=request.url
                val url=uri.toString()
                val baseUri=runCatching{Uri.parse(baseUrl)}.getOrNull()
                val sameMtiHost=uri.scheme=="https" && baseUri?.scheme=="https" && uri.host.equals(baseUri.host,true)
                if(sameMtiHost){return false}
                if(uri.scheme=="https"||uri.scheme=="http"||uri.scheme=="mailto"||uri.scheme=="tel"){openExternalUrl(url);return true}
                return true
            }
        }
        val target=if(path.startsWith("http://")||path.startsWith("https://"))path else baseUrl+path
        val targetUri=runCatching{Uri.parse(target)}.getOrNull()
        if(targetUri?.scheme!="https" || !targetUri.host.equals(runCatching{Uri.parse(baseUrl)}.getOrNull()?.host,true)){
            Toast.makeText(this,"MTI blocked an unsafe web destination.",Toast.LENGTH_LONG).show()
            showHome()
            return
        }
        web.loadUrl(target)
        content.addView(web,FrameLayout.LayoutParams(-1,-1))
    }
    @Deprecated("Deprecated in Java") override fun onBackPressed(){val web=activeWebView;if(web!=null&&web.canGoBack())web.goBack()else showHome()}
}
