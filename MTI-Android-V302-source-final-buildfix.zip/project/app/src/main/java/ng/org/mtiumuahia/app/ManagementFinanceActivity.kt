package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.View
import android.widget.*

class ManagementFinanceActivity : Activity() {
    private val green = Color.rgb(11,61,46)
    private val cream = Color.rgb(246,241,230)
    private val gold = Color.rgb(184,149,74)
    private val ink = Color.rgb(23,53,44)
    private val white = Color.WHITE
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=android.content.res.ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);show()}
    private fun show(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(20))}
        root.addView(text("MTI · UMUAHIA",12f,gold,true));root.addView(text("Finance & Payment Administration",28f,ink,true))
        root.addView(text("Management finance workspace using the existing MTI payment, invoice, receipt and payment-evidence architecture. This Android screen does not create a parallel finance database or payment gateway."))
        root.addView(text("EXISTING FINANCE RECORDS",12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(18),dp(4),dp(6))})
        root.addView(text("• Student payments\n• Fee invoices\n• Payment receipts\n• Payment evidence / review records\n• Existing finance and management role controls"))
        root.addView(text("PAYMENT EVIDENCE SECURITY",12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(18),dp(4),dp(6))})
        root.addView(text("Existing RLS permits authorised finance/management/admin users to review payment evidence. The app does not expose service-role credentials or bypass Supabase policies."))
        root.addView(button("Open Finance / Payment Workspace"){open("/finance-dashboard")})
        root.addView(button("Open Payment Administration"){open("/payment-administration")})
        root.addView(button("Open Management Command Centre"){open("/management-dashboard")})
        root.addView(button("Back"){finish()})
        setContentView(ScrollView(this).apply{isFillViewport=true;addView(root)})
    }
    private fun open(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
