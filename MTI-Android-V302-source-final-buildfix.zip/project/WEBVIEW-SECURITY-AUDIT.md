# MTI Android V298 — WebView Privacy, JavaScript & Browser-Surface Security Audit

Baseline: V297. Workflow: audit → understand → reuse → improve → validate → package.

## Audited
- Existing MainActivity WebView was the only native WebView surface.
- JavaScript remains enabled because the existing MTI website and AI/public portal surfaces require it.
- File and content access were already disabled.
- No JavaScript interface (`addJavascriptInterface`) is used.
- Existing external navigation and MTI base URL handling were reviewed.

## V298 hardening
- Disabled WebView contents debugging in release/runtime code.
- Disabled file-URL access from file URLs and universal file-URL access.
- Explicitly blocked mixed HTTP content inside the HTTPS MTI WebView.
- Enabled Android Safe Browsing where supported (API 26+).
- Required user gesture for media playback.
- Replaced vulnerable string-prefix host matching with HTTPS + exact host comparison for in-app MTI navigation.
- Unsafe/non-HTTPS initial WebView destinations are rejected.
- JavaScript remains enabled only for the existing MTI web surface; no bridge/API is exposed to JavaScript.
- External http/https/mailto/tel links remain outside the WebView through the system handler.

## Preserved
- Existing Supabase/Auth/RLS architecture.
- Existing native portal boundaries.
- No service-role credentials.
- No new database tables, RPCs, storage buckets, permissions or dependencies.

## Validation
- No SQL migration required.
- Android source/resource structure retained from V297.
- ZIP integrity verified after packaging.
- APK build is not claimed because the trusted Gradle wrapper JAR/installed Gradle runtime remains unavailable.
