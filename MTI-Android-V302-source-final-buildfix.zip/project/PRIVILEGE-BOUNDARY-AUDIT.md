# MTI Android V293 — Portal Authorization & Privilege-Boundary Audit

## Scope
Audited V292 before changes, focusing on Student, Lecturer and Management authentication, role checks, exported Activity boundaries, bearer-token propagation, and Supabase RLS reliance.

## Findings
- Management sign-in already authenticates through Supabase Auth and checks the existing `is_portal_role` RPC with `required_role=management` before opening the management dashboard.
- Student and Lecturer access is constrained by authenticated profile records and the existing Supabase RLS policies; the app does not create or grant portal roles.
- Internal management child Activities are explicitly `android:exported="false"`, preventing external Android components from directly launching them.
- Child management screens receive the already-authenticated bearer token only through explicit internal navigation from the Management Portal.
- The public publishable Supabase key remains a client-side public key; no service-role credential is introduced.

## V293 hardening
If a Management role check fails after authentication, V293 now clears the in-memory identity/session state and performs a best-effort Supabase logout before returning the authorization error. This prevents an unauthorised account's newly issued session from remaining active in the management Activity state.

## Architecture preserved
No new roles, privilege tables, service-role access, bypass RPCs, or database policies were introduced. Supabase Auth + `is_portal_role` + RLS remain authoritative.

## SQL
No SQL migration required.
