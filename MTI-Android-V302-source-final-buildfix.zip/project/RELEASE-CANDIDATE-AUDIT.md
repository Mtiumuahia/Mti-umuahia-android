# V300 Release Candidate Integration & Full Pre-Build Audit

## Baseline
Audited the actual V299 source before changes. No website, Supabase, database, storage, Auth, RLS, or portal architecture was rebuilt.

## Source inventory
- 36 Kotlin source files
- AndroidManifest.xml
- 5 main XML/resource files plus the MTI logo asset
- Gradle Kotlin DSL project
- Gradle wrapper properties targeting Gradle 8.9
- No declared third-party runtime dependencies in the project Gradle files

## Integration checks
- applicationId: `ng.org.mtiumuahia.app`
- compileSdk: 35
- targetSdk: 35
- minSdk: 24
- versionCode: 300
- versionName: 8.8.0
- MainActivity is the only exported launcher activity.
- Portal/management activities remain non-exported.
- cleartext traffic remains disabled.
- Internet and network-state permissions are the only declared permissions.
- main XML resources parse successfully.
- No stale V299 build metadata remains in source configuration.

## Build gate
A real debug build was attempted with `./gradlew :app:assembleDebug`. It correctly stopped because `gradle/wrapper/gradle-wrapper.jar` is not bundled. No APK is therefore claimed.

## Backend
No SQL migration required. Existing Supabase Auth, publishable client access, RLS, storage, RPCs, and website architecture remain unchanged.

## Release status
**Source release candidate prepared; APK build pending a trusted Gradle 8.9 environment or the official wrapper JAR.**
