# MTI Android V296 — Lifecycle, Memory & Configuration-Change Audit

Baseline: V295. This pass audits Activity lifecycle ownership, executor cleanup, Handler callbacks, WebView disposal, and obvious configuration-change retention risks without introducing a second architecture.

## Changes
- Added `onDestroy()` cleanup to native Activities that own background executors and previously did not shut them down.
- MainActivity now removes pending Handler callbacks, stops/destroys the active WebView, clears its reference, and shuts down its executor during destruction.
- Existing Student Portal, Communications and Notifications cleanup was preserved.
- No `android:configChanges` workaround was introduced; Android remains responsible for normal configuration recreation.
- No backend, authentication, database, RLS, or storage changes.

## Validation
- Source copied from V295 before edits.
- Executor-owning Activities audited for lifecycle cleanup.
- MainActivity WebView/Handler lifecycle explicitly covered.
- Build metadata: versionCode 296 / versionName 8.4.0.
- APK build is not claimed because a trusted Gradle wrapper JAR/installed Gradle runtime is still unavailable.
- No SQL migration required.
