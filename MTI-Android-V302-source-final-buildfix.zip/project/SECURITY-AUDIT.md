# V287 Security Audit

- Management, student, and lecturer internal activities are explicitly `exported=false`.
- Only `MainActivity` is exported and carries the launcher intent filter.
- Android backup is disabled with `android:allowBackup="false"`.
- Cleartext HTTP is disabled with `android:usesCleartextTraffic="false"`.
- Existing Supabase Auth, access-token handling, and RLS architecture are preserved.
- No service-role credential, new privileged role, or permission bypass was introduced.
- No SQL migration required.

## Scope
This is a manifest/application-layer hardening pass. It does not replace server-side authorization; Supabase Auth and RLS remain authoritative.
