# V292 — Authentication, Token & Session Security Audit

## Scope
Audited the actual V291 Android source before changes, focusing on Supabase Auth credentials, bearer-token lifetime, local persistence, logout behavior, and portal-session boundaries.

## Findings and corrections
- Student Portal previously persisted access/refresh tokens in ordinary SharedPreferences. V292 removes that persistence.
- Student Portal now requires a fresh sign-in after app-process restart and clears the legacy local session values on startup.
- Student, Lecturer and Management portals now discard their in-memory bearer token before returning to the sign-in surface.
- Student, Lecturer and Management sign-out additionally make a best-effort POST to the existing Supabase Auth `/auth/v1/logout` endpoint.
- No password, refresh token, access token, or service-role credential is written to logs or a new database table.
- Existing Supabase Auth, `is_portal_role`, and RLS remain authoritative.
- Internal management activities continue to be non-exported; access tokens are passed only between those in-process activity boundaries and are not persisted.

## Deliberately not changed
- No new authentication provider.
- No custom token system.
- No service-role key.
- No database/RLS/role changes.
- No SQL migration.

## Validation
- Source search confirms no `access_token`/`refresh_token` persistence calls remain in app Java/Kotlin source.
- Existing logout endpoint usage is limited to authenticated portal sign-out.
- Android Manifest remains under the V291 security boundary.
