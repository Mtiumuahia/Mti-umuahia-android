# MTI Android V294 — Data Privacy & Sensitive-Data Exposure Audit

## Baseline
Audited the actual V293 source before changes.

## Changes
- Added Android `FLAG_SECURE` to the authenticated Student, Lecturer and Management root portals to reduce accidental screenshots/screen capture of sensitive portal data.
- Prevented raw HTTP/backend response bodies from being converted into exceptions.
- Management error surfaces now use generic operational messages instead of displaying backend response payloads.
- No passwords, access tokens, refresh tokens or service-role credentials were added to logs or persistent storage.
- Existing Supabase Auth, RLS, role authorization and backend remain authoritative.

## Validation
- 36 Kotlin source files retained.
- No SQL/backend migration required.
- APK build not claimed: trusted Gradle wrapper JAR/installed Gradle executable remains unavailable.
