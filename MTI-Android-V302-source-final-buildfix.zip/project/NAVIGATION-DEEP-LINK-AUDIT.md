# MTI Android V290 — Navigation, Back-Stack & Deep-Link Audit

Audited V289 navigation entry points, MainActivity WebView routing, Android manifest activity boundaries, internal activity launches, and external URL handling before changes.

## Changes
- Preserved the existing native Activity architecture and website/Supabase integration.
- Hardened MainActivity WebView URL handling so only MTI same-origin pages remain inside the WebView.
- HTTP/HTTPS external destinations open outside the app rather than silently replacing the app navigation context.
- `mailto:` and `tel:` links are explicitly supported by the WebView navigation bridge.
- MainActivity WebView loading accepts established internal paths or explicit HTTP(S) URLs.
- Existing native Activity back-stack behavior is preserved: Back returns to the immediately preceding native screen.
- Existing WebView Back behavior is preserved: WebView history is traversed first; otherwise Back returns to the native MTI home surface.
- No deep-link intent filter was added for privileged portal routes, preventing external applications from directly launching protected management Activities.

## Security boundary
No new exported Activities, roles, service keys, authentication flow, database objects, or RLS policies were introduced.

## Version
- versionCode: 290
- versionName: 7.9.0

## Backend
No SQL migration required.
