# MTI Android V302 — Configuration Consistency Audit

## Scope
Audited V300 before changing anything. The review focused on duplicated Supabase project configuration and consistency of the established publishable key reference.

## Finding corrected
V300 contained a different Supabase publishable-key literal from the value established in earlier validated MTI Android versions. Because the same literal was duplicated across native activities, this could cause authenticated/public Supabase requests to fail consistently if the differing value is invalid for the project.

V302 normalizes that literal across the affected source files and the existing `strings.xml` resource. No new credential, role, service key, or backend object was introduced.

## Preserved
- Existing Supabase project URL
- Existing Supabase Auth
- Existing `is_portal_role` authorization boundary
- Existing RLS policies
- Existing RPCs, tables, storage buckets and web workspaces
- No service-role key
- No new database migration

## Build status
The source remains build-ready in configuration, but the repository environment still lacks the official Gradle wrapper JAR and no system Gradle executable is installed. Therefore no APK is claimed from this environment.
