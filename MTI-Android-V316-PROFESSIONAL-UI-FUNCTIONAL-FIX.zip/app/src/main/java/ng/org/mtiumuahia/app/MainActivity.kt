package ng.org.mtiumuahia.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.*

class MainActivity : Activity() {
    private data class ExploreItem(val icon: String, val title: String, val description: String, val destination: String)
    private val cream = Color.rgb(247, 244, 237)
    private val green = Color.rgb(11, 61, 46)
    private val deep = Color.rgb(5, 37, 28)
    private val gold = Color.rgb(190, 157, 82)
    private val ink = Color.rgb(25, 45, 39)
    private val muted = Color.rgb(91, 105, 99)
    private val white = Color.WHITE
    private lateinit var content: FrameLayout

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        findViewById<TextView>(R.id.navHome).setOnClickListener { home() }
        findViewById<TextView>(R.id.navCommunity).setOnClickListener { community() }
        findViewById<TextView>(R.id.navAcademics).setOnClickListener { academics() }
        findViewById<TextView>(R.id.navExplore).setOnClickListener { explore() }
        findViewById<TextView>(R.id.navProfile).setOnClickListener { profile() }
        findViewById<TextView>(R.id.aiFab).setOnClickListener { startActivity(Intent(this, AIAssistantActivity::class.java)) }
        home()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(s: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setLineSpacing(0f, 1.16f)
    }
    private fun pill(s: String) = tv(s.uppercase(), 10f, gold, true).apply { letterSpacing = .16f }
    private fun scroll(v: View) = ScrollView(this).apply { isFillViewport = true; addView(v) }
    private fun bg(color: Int, r: Float = 18f) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r.toInt()).toFloat() }
    private fun primary(s: String, click: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; gravity = Gravity.CENTER; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        background = bg(green, 16f); setPadding(dp(18), dp(14), dp(18), dp(14)); isClickable = true
        setOnClickListener { press(this); click() }
    }
    private fun ghost(s: String, click: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; gravity = Gravity.CENTER; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(1), Color.rgb(190,210,201)); cornerRadius = dp(16).toFloat() }
        setPadding(dp(18), dp(14), dp(18), dp(14)); isClickable = true
        setOnClickListener { press(this); click() }
    }
    private fun card(title: String, desc: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = bg(white, 20f)
        elevation = dp(3).toFloat(); isClickable = true; isFocusable = true
        setOnClickListener { press(this); click() }
        addView(tv(title, 18f, green, true))
        addView(tv(desc, 13f, muted).apply { setPadding(0, dp(7), 0, 0) })
        addView(tv("→", 21f, gold, true).apply { gravity = Gravity.END; setPadding(0, dp(8), 0, 0) })
    }
    private fun featureCard(title: String, desc: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(16)); background = bg(white, 22f)
        elevation = dp(4).toFloat(); isClickable = true; isFocusable = true
        addView(tv(title, 20f, green, true)); addView(tv(desc, 14f, muted).apply { setPadding(0, dp(8), 0, 0) })
        addView(tv("Open  →", 13f, gold, true).apply { setPadding(0, dp(18), 0, 0) })
        setOnClickListener { press(this); click() }
    }
    private fun row(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginEnd = dp(7) })
        addView(b, LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginStart = dp(7) })
    }
    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(cream); setPadding(dp(18), dp(14), dp(18), dp(30))
    }
    private fun press(v: View) {
        if (android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) return
        v.animate().scaleX(.975f).scaleY(.975f).setDuration(70).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
    }
    private fun animateIn(container: ViewGroup) {
        if (android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) return
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i); child.alpha = 0f; child.translationY = dp(12).toFloat()
            child.animate().alpha(1f).translationY(0f).setStartDelay((i * 45L).coerceAtMost(450L)).setDuration(330).setInterpolator(DecelerateInterpolator()).start()
        }
    }
    private fun header(label: String, title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; addView(pill(label)); addView(tv(title, 30f, ink, true).apply { setPadding(0, dp(5), 0, dp(6)) }); addView(tv(subtitle, 14f, muted).apply { setPadding(0, 0, 0, dp(18)) })
    }

    private fun home() {
        content.removeAllViews(); val p = page()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.mti_logo); contentDescription = "MTI Umuahia"; scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(54), dp(54)))
        top.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tv("MTI · UMUAHIA", 12f, gold, true)); addView(tv("Methodist Theological Institute", 14f, green, true)) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        p.addView(top)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(deep, green)).apply { cornerRadius = dp(26).toFloat() }
            addView(pill("Faith · Formation · Scholarship"))
            addView(tv("Rooted in faith.\nGrowing in truth.", 31f, white, true).apply { setPadding(0, dp(12), 0, dp(6)) })
            addView(tv("A theological community preparing people for faithful Christian ministry and service.", 14f, Color.rgb(229,238,232)))
            addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; addView(primary("Explore MTI") { explore() }, LinearLayout.LayoutParams(0, dp(50), 1f)); addView(ghost("Admissions") { openContent("admissions") }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(8) }) }.apply { setPadding(0, dp(18), 0, 0) })
        }
        p.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(18), 0, 0) })
        p.addView(tv("Featured at MTI", 21f, ink, true).apply { setPadding(2, dp(25), 2, dp(10)) })
        p.addView(featureCard("What's happening at MTI", "News, events and moments from the Institute.") { openContent("news") }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(4), 0, dp(8)) })
        p.addView(row(featureCard("Campus Life", "Worship, learning, formation and daily life at MTI.") { openContent("campus") }, featureCard("MTI Community", "Connect with the MTI family.") { community() }), LinearLayout.LayoutParams(-1, dp(128)))
        p.addView(tv("Your MTI", 21f, ink, true).apply { setPadding(2, dp(26), 2, dp(10)) })
        p.addView(row(card("Student Portal", "Courses, results and services.") { startActivity(Intent(this, StudentPortalActivity::class.java)) }, card("Lecturer Portal", "Teaching, results and materials.") { startActivity(Intent(this, LecturerPortalActivity::class.java)) }))
        p.addView(tv("Explore MTI", 21f, ink, true).apply { setPadding(2, dp(26), 2, dp(10)) })
        p.addView(row(card("Programmes", "Study pathways at MTI.") { openContent("programmes") }, card("Leadership", "Meet MTI's leadership.") { openContent("leadership") }))
        content.addView(scroll(p)); animateIn(p)
    }

    private fun community() {
        startActivity(Intent(this, CommunityActivity::class.java))
    }

    private fun academics() {
        content.removeAllViews(); val p = page(); p.addView(header("ACADEMICS", "Your academic life.", "Access the native MTI academic workspaces."))
        p.addView(featureCard("Student Portal", "Registration, results, fees, materials, schedule and services.") { startActivity(Intent(this, StudentPortalActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(4), 0, dp(8)) })
        p.addView(featureCard("Lecturer Portal", "Courses, gradebook, attendance, materials and virtual classes.") { startActivity(Intent(this, LecturerPortalActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(4), 0, dp(8)) })
        p.addView(card("Online Classroom", "Continue to the existing native classroom workspace.") { startActivity(Intent(this, StudentPortalActivity::class.java)) })
        content.addView(scroll(p)); animateIn(p)
    }

    private fun sectionLabel(s: String) = tv(s.uppercase(), 10f, gold, true).apply { letterSpacing = .18f }

    private fun iconBadge(symbol: String, dark: Boolean = false) = TextView(this).apply {
        text = symbol; gravity = Gravity.CENTER; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (dark) white else green)
        background = GradientDrawable().apply {
            setColor(if (dark) Color.argb(48, 255, 255, 255) else Color.rgb(239, 235, 224))
            cornerRadius = dp(15).toFloat()
            if (!dark) setStroke(dp(1), Color.rgb(224, 214, 190))
        }
    }

    private fun exploreCard(symbol: String, title: String, desc: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(17))
        isClickable = true
        isFocusable = true
        background = GradientDrawable().apply {
            setColor(white)
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.rgb(231, 227, 218))
        }
        elevation = dp(2).toFloat()
        addView(iconBadge(symbol), LinearLayout.LayoutParams(dp(46), dp(46)))
        addView(tv(title, 18f, green, true).apply { setPadding(0, dp(14), 0, dp(6)) })
        addView(tv(desc, 13.5f, muted).apply { setLineSpacing(0f, 1.2f) })
        setOnClickListener { press(this); click() }
    }

    private fun explore() {
        content.removeAllViews(); val p = page()
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(deep, green)).apply { cornerRadius = dp(27).toFloat() }
            addView(sectionLabel("DISCOVER MTI"))
            addView(tv("Find what matters.", 29f, white, true).apply { setPadding(0, dp(9), 0, dp(7)) })
            addView(tv("People, programmes, stories, admissions and the wider life of the Institute — organised into clear destinations.", 14f, Color.rgb(224, 236, 229)))
        }
        p.addView(hero)
        p.addView(tv("Institution", 21f, ink, true).apply { setPadding(dp(2), dp(24), dp(2), dp(5)) })
        p.addView(tv("Start with the section that matches what you need.", 13f, muted).apply { setPadding(dp(2), 0, dp(2), dp(12)) })

        val items = listOf(
            ExploreItem("⌂", "About MTI", "Identity, mission, formation and institutional story.", "about"),
            ExploreItem("✦", "Leadership", "Meet the current leadership published by MTI.", "leadership"),
            ExploreItem("⌘", "Governance", "Institutional oversight and standards.", "governance"),
            ExploreItem("▣", "Programmes", "Academic pathways, levels and areas of study.", "programmes"),
            ExploreItem("✓", "Admissions", "Application journey, selection and next steps.", "admissions"),
            ExploreItem("●", "News", "Published stories and institutional updates.", "news"),
            ExploreItem("◷", "Events", "Institute activities, ceremonies and events.", "events"),
            ExploreItem("▧", "Gallery", "Photographs and visual moments from MTI.", "gallery"),
            ExploreItem("◎", "SUG", "The official Student Union Government directory.", "sug"),
            ExploreItem("⌖", "Campus Life", "Worship, study, formation, fellowship and service.", "campus")
        )
        items.chunked(2).forEach { pair ->
            val a = pair[0]
            val ca = exploreCard(a.icon, a.title, a.description) { openContent(a.destination) }
            if (pair.size == 2) {
                val b = pair[1]
                val cb = exploreCard(b.icon, b.title, b.description) { openContent(b.destination) }
                p.addView(row(ca, cb), LinearLayout.LayoutParams(-1, dp(184)).apply { setMargins(0, dp(4), 0, dp(8)) })
            } else {
                p.addView(ca, LinearLayout.LayoutParams(-1, dp(184)).apply { setMargins(0, dp(4), 0, dp(8)) })
            }
        }
        p.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { setColor(Color.rgb(239, 235, 224)); cornerRadius = dp(18).toFloat() }
            addView(iconBadge("⌖"), LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(tv("Visit MTI", 15f, green, true))
                addView(tv("Mission Hill, Umuahia, Abia State", 12f, muted).apply { setPadding(0, dp(3), 0, 0) })
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
            setOnClickListener { press(this); openContent("contact") }
        })
        content.addView(scroll(p)); animateIn(p)
    }

    private fun profile() {
        content.removeAllViews(); val p = page()
        p.addView(header("MY MTI", "Your MTI space.", "Access your authenticated academic services and account controls."))
        p.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(deep, green)).apply { cornerRadius = dp(23).toFloat() }
            addView(sectionLabel("DIGITAL CAMPUS"))
            addView(tv("Everything important,\nin one place.", 23f, white, true).apply { setPadding(0, dp(7), 0, dp(5)) })
            addView(tv("Your portal remains the authoritative home for student and staff services.", 13f, Color.rgb(224,236,229)))
        })
        p.addView(tv("Account services", 20f, ink, true).apply { setPadding(dp(2), dp(24), dp(2), dp(8)) })
        p.addView(featureCard("Student Portal", "Registration, results, fees, materials, schedule and services.") { startActivity(Intent(this, StudentPortalActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(3), 0, dp(8)) })
        p.addView(card("Notifications", "View institutional and account notices from the authenticated MTI workspace.") { startActivity(Intent(this, StudentPortalActivity::class.java)) }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(8)) })
        p.addView(card("Privacy & security", "Manage your account protection, sign-in and privacy from the MTI account services.") { toast("Your MTI account protection is managed securely.") })
        content.addView(scroll(p)); animateIn(p)
    }

    private fun openContent(type: String) { startActivity(Intent(this, PublicContentActivity::class.java).putExtra("type", type)) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
