(function(){'use strict';
 var path=location.pathname.replace(/\/$/,'');
 var excluded=['/student-portal','/lecturer-portal','/applicant-portal','/management-dashboard','/academic-administration','/admissions-administration','/student-onboarding','/student-registry','/course-registration','/teaching-load-management','/online-classroom','/online-learning','/apply-now'];
 if(excluded.indexOf(path)>-1)return;
 function init(){
  document.documentElement.classList.add('mti-v198-public');
  var headers=document.querySelectorAll('header'); if(!headers.length)return;
  headers.forEach(function(header){
   var nav=header.querySelector('nav'); if(!nav)return;
   // The current MTI home renderer already provides its own integrated hamburger.
   // Keep V198 for older/public renderers, but never add a duplicate button.
   if(header.querySelector('.hamb'))return;
   nav.classList.add('mti-v198-nav-panel');
   if(header.querySelector('.mti-v198-menu'))return;
   var btn=document.createElement('button'); btn.type='button'; btn.className='mti-v198-menu'; btn.setAttribute('aria-expanded','false'); btn.setAttribute('aria-label','Open navigation'); btn.innerHTML='<span aria-hidden="true">☰</span>';
   var anchor=header.querySelector('a[href="/"]')||header.firstElementChild;
   if(anchor&&anchor.parentNode===header) anchor.insertAdjacentElement('afterend',btn); else header.appendChild(btn);
   function close(){nav.classList.remove('mti-v198-open');btn.setAttribute('aria-expanded','false');btn.setAttribute('aria-label','Open navigation')}
   btn.addEventListener('click',function(){var open=nav.classList.toggle('mti-v198-open');btn.setAttribute('aria-expanded',String(open));btn.setAttribute('aria-label',open?'Close navigation':'Open navigation')});
   nav.addEventListener('click',function(e){if(e.target.closest('a'))close()});
   document.addEventListener('keydown',function(e){if(e.key==='Escape')close()});
   window.addEventListener('resize',function(){if(window.innerWidth>860)close()},{passive:true});
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
