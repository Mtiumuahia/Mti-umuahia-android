MTI Website V219 — Welcome Notice, Mobile Navigation & Admission Entry Mode

Changes in V219:
1. Homepage welcome notice is now browser-local and time-gated. It appears once when the notice window is first encountered, then remains suppressed for 30 minutes in that browser/device. Refreshing the page during those 30 minutes does not show it again. After 30 minutes, it can appear again.
2. Fixed the duplicate public mobile navigation buttons. The existing MTI home renderer's integrated navigation button is retained; the older V198 enhancer now skips headers that already have the integrated button, while remaining available for public renderers that need it.
3. Admissions application field is now labelled “Entry Mode” instead of “Entry Level”. The visible choices no longer use 100/200/300/400 Level. Current choices are O Level, Degree Holder, Master's / Postgraduate, Doctoral, Distance / E-Learning, Executive, and Other.
4. The existing database/RPC compatibility is preserved by continuing to submit the selected entry mode through the existing application `p_level` field. No database migration is required.

No SQL migration required.

Deployment: upload the ZIP to Netlify as the latest site version. Keep the existing Supabase configuration and OPENAI_API_KEY environment variable in Netlify Functions scope.
