MTI Website V218 — Christian & Nigerian Church AI Expansion

Purpose:
- Expands the MTI AI Assistant beyond MTI-specific questions.
- Supports broad Christian, Bible, theology, ministry, church history and Christian-life questions.
- Supports educational discussion of Methodist Church Nigeria and other Nigerian Christian traditions and denominations.
- Encourages fair explanation of denominational differences and avoids presenting one church tradition as universally authoritative.
- Time-sensitive church facts (current leaders, programmes, appointments, events, policies, addresses, etc.) must be treated cautiously and should be confirmed from an official/public source when needed.
- Retains MTI-specific live public-content retrieval and private-data boundaries.
- Retains plain-text response formatting and removal of asterisks/Markdown emphasis.

Database:
No SQL migration required.

Deployment:
Upload this ZIP to the active Netlify MTI site and keep OPENAI_API_KEY configured in Netlify Functions environment variables.
