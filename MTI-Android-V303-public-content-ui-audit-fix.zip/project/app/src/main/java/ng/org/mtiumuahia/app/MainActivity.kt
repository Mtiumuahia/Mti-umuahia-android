package ng.org.mtiumuahia.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var content: FrameLayout
    private lateinit var baseUrl: String
    private var activeWebView: WebView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val cream = Color.rgb(246, 241, 230)
    private val green = Color.rgb(11, 61, 46)
    private val darkGreen = Color.rgb(6, 40, 30)
    private val gold = Color.rgb(184, 149, 74)
    private val ink = Color.rgb(23, 53, 44)
    private val muted = Color.rgb(92, 103, 98)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        baseUrl = getString(R.string.mti_base_url).trimEnd('/')
        findViewById<Button>(R.id.navHome).setOnClickListener { showHome() }
        findViewById<Button>(R.id.navExplore).setOnClickListener { showExplore() }
        findViewById<Button>(R.id.navPortal).setOnClickListener { showPortal() }
        findViewById<Button>(R.id.navAI).setOnClickListener { openWeb("/#ai-assistant") }
        showHome()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        activeWebView?.apply { stopLoading(); destroy() }
        activeWebView = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun root(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(cream)
    }
    private fun scroll(view: View): ScrollView = ScrollView(this).apply {
        isFillViewport = true
        addView(view)
    }
    private fun text(value: String, size: Float = 15f, color: Int = ink, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setLineSpacing(0f, 1.14f)
    }
    private fun title(value: String, size: Float = 28f): TextView = text(value, size, ink, true).apply {
        setPadding(dp(20), dp(18), dp(20), dp(6))
    }
    private fun label(value: String): TextView = text(value.uppercase(), 11f, gold, true).apply {
        letterSpacing = .14f
        setPadding(dp(20), dp(18), dp(20), dp(4))
    }
    private fun body(value: String, color: Int = ink): TextView = text(value, 14.5f, color, false).apply {
        setPadding(dp(20), dp(7), dp(20), dp(10))
    }
    private fun button(value: String, onClick: () -> Unit): Button = Button(this).apply {
        text = value
        isAllCaps = false
        textSize = 14f
        setTextColor(white)
        backgroundTintList = ColorStateList.valueOf(green)
        minHeight = dp(50)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply {
            setMargins(dp(20), dp(5), dp(20), dp(5))
        }
    }
    private fun card(title: String, subtitle: String, icon: String, onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.START
        setBackgroundColor(white)
        setPadding(dp(15), dp(14), dp(15), dp(14))
        elevation = dp(2).toFloat()
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        addView(text(icon, 24f, gold, false))
        addView(text(title, 16f, green, true).apply { setPadding(0, dp(7), 0, 0) })
        addView(text(subtitle, 12.5f, muted, false).apply { setPadding(0, dp(4), 0, 0) })
    }
    private fun grid(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        views.toList().chunked(2).forEach { pair ->
            val row = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(16), dp(5), dp(16), dp(5))
            }
            pair.forEach { item ->
                row.addView(item, LinearLayout.LayoutParams(0, dp(142), 1f).apply { marginEnd = dp(5) })
            }
            if (pair.size == 1) row.addView(View(this@MainActivity), LinearLayout.LayoutParams(0, dp(142), 1f))
            addView(row)
        }
    }

    private fun showHome() {
        activeWebView = null
        content.removeAllViews()
        val r = root()
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(green)
            setPadding(dp(20), dp(20), dp(20), dp(24))
        }
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.mti_logo)
            adjustViewBounds = true
            contentDescription = "MTI Umuahia logo"
            layoutParams = LinearLayout.LayoutParams(-1, dp(105))
        })
        hero.addView(text("MTI · UMUAHIA", 11f, gold, true).apply { letterSpacing = .16f; setPadding(0, dp(10), 0, dp(4)) })
        hero.addView(text("Rooted in faith.\nGrowing in truth.", 30f, white, true))
        hero.addView(text("Methodist Theological Institute, Umuahia", 14.5f, white, false).apply { setPadding(0, dp(8), 0, 0) })
        hero.addView(button("Explore the official MTI website") { openWeb("/") })
        r.addView(hero)

        r.addView(label("DISCOVER MTI"))
        r.addView(grid(
            card("About MTI", "History, identity and institutional information.", "01") { openWeb("/#about") },
            card("Leadership", "Rector, Registrar and institutional leadership.", "02") { openWeb("/#leadership") },
            card("Programmes", "Academic pathways and programme information.", "03") { openWeb("/#programmes") },
            card("Admissions", "Current status, entry modes and application process.", "04") { openWeb("/#admissions") },
            card("News", "Official institutional news and announcements.", "05") { openWeb("/#news") },
            card("Events", "Upcoming and recent MTI events.", "06") { openWeb("/#events") },
            card("Gallery", "Photos, media and institutional moments.", "07") { openWeb("/gallery") },
            card("SUG", "Student Union Government directory.", "08") { openWeb("/sug-executives") }
        ))

        r.addView(label("SECURE PORTALS"))
        r.addView(button("Student Portal") { startActivity(Intent(this, StudentPortalActivity::class.java)) })
        r.addView(button("Lecturer Portal") { startActivity(Intent(this, LecturerPortalActivity::class.java)) })
        r.addView(button("Applicant Portal") { openWeb("/applicant-portal") })
        r.addView(button("Management Portal") { startActivity(Intent(this, ManagementPortalActivity::class.java)) })

        r.addView(label("ASSISTANCE"))
        r.addView(button("Ask the MTI AI Assistant") { openWeb("/#ai-assistant") })
        r.addView(button("Visit & Contact MTI") { openWeb("/contact") })
        r.addView(body("Public information is displayed through the existing MTI website, while secure academic and management workspaces continue to use the established Supabase authentication and RLS architecture.", muted))
        content.addView(scroll(r))
    }

    private fun showExplore() {
        activeWebView = null
        content.removeAllViews()
        val r = root()
        r.addView(title("Explore MTI"))
        r.addView(body("The official MTI website is the authoritative public content source. Opening a section here keeps the app synchronized with the same News, Events, Gallery, Admissions and institutional content used on the website."))
        r.addView(grid(
            card("About", "Institutional story and identity.", "01") { openWeb("/#about") },
            card("Governance", "Leadership and institutional structures.", "02") { openWeb("/#governance") },
            card("Programmes", "Current academic pathways.", "03") { openWeb("/#programmes") },
            card("Admissions", "Admission process and status.", "04") { openWeb("/#admissions") },
            card("News", "Latest institutional updates.", "05") { openWeb("/#news") },
            card("Events", "MTI events and activities.", "06") { openWeb("/#events") },
            card("Gallery", "Official photo and media collection.", "07") { openWeb("/gallery") },
            card("SUG", "Student leadership directory.", "08") { openWeb("/sug-executives") }
        ))
        r.addView(button("Open Complete MTI Website") { openWeb("/") })
        content.addView(scroll(r))
    }

    private fun showPortal() {
        activeWebView = null
        content.removeAllViews()
        val r = root()
        r.addView(title("MTI Portals"))
        r.addView(body("Choose the secure workspace that matches your role. The app does not create a second database or permission system."))
        r.addView(label("ACADEMIC"))
        r.addView(button("Student Portal") { startActivity(Intent(this, StudentPortalActivity::class.java)) })
        r.addView(button("Lecturer Portal") { startActivity(Intent(this, LecturerPortalActivity::class.java)) })
        r.addView(label("ADMISSIONS"))
        r.addView(button("Applicant Portal") { openWeb("/applicant-portal") })
        r.addView(label("INSTITUTIONAL MANAGEMENT"))
        r.addView(button("Management Portal") { startActivity(Intent(this, ManagementPortalActivity::class.java)) })
        r.addView(body("Management access remains protected by the existing Supabase authentication and management role checks.", muted))
        content.addView(scroll(r))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openWeb(path: String) {
        if (!isNetworkAvailable()) {
            showWebError("No internet connection", "Connect to the internet and try again.", path)
            return
        }
        content.removeAllViews()
        val wrapper = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cream) }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(darkGreen)
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
        val back = Button(this).apply {
            text = "‹  Back"
            isAllCaps = false
            setTextColor(white)
            backgroundTintList = ColorStateList.valueOf(darkGreen)
            setOnClickListener { if (activeWebView?.canGoBack() == true) activeWebView?.goBack() else showHome() }
        }
        val refresh = Button(this).apply {
            text = "Refresh"
            isAllCaps = false
            setTextColor(white)
            backgroundTintList = ColorStateList.valueOf(darkGreen)
            setOnClickListener { activeWebView?.reload() }
        }
        bar.addView(back, LinearLayout.LayoutParams(0, dp(50), 1f))
        bar.addView(refresh, LinearLayout.LayoutParams(0, dp(50), 1f))
        wrapper.addView(bar)

        val web = WebView(this)
        activeWebView = web
        WebView.setWebContentsDebuggingEnabled(false)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.allowFileAccessFromFileURLs = false
        web.settings.allowUniversalAccessFromFileURLs = false
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.settings.mediaPlaybackRequiresUserGesture = true
        if (android.os.Build.VERSION.SDK_INT >= 26) web.settings.safeBrowsingEnabled = true
        web.settings.setSupportZoom(false)

        var mainFrameFailed = false
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                handler.removeCallbacksAndMessages(null)
                mainFrameFailed = false
            }
            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    mainFrameFailed = true
                    showWebError("MTI page could not be loaded", "The official MTI website did not respond. You can retry without leaving the app.", path)
                }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val baseUri = Uri.parse(baseUrl)
                val sameHost = uri.scheme == "https" && uri.host.equals(baseUri.host, true)
                if (sameHost) return false
                val scheme = uri.scheme.orEmpty().lowercase()
                if (scheme == "http" || scheme == "https" || scheme == "mailto" || scheme == "tel") {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    return true
                }
                return true
            }
        }
        val target = if (path.startsWith("http://") || path.startsWith("https://")) path else baseUrl + path
        val uri = runCatching { Uri.parse(target) }.getOrNull()
        if (uri?.scheme != "https" || !uri.host.equals(Uri.parse(baseUrl).host, true)) {
            showWebError("Unsafe destination blocked", "The requested MTI destination is not allowed.", "/")
            return
        }
        wrapper.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        content.addView(wrapper)
        web.loadUrl(target)
        handler.postDelayed({
            if (activeWebView === web && !web.progress.toString().equals("100") && mainFrameFailed) {
                showWebError("MTI page could not be loaded", "Please check your connection and retry.", path)
            }
        }, 18000)
    }

    private fun showWebError(heading: String, message: String, retryPath: String) {
        activeWebView?.stopLoading()
        activeWebView = null
        content.removeAllViews()
        val r = root()
        r.gravity = Gravity.CENTER_HORIZONTAL
        r.addView(text("MTI · UMUAHIA", 12f, gold, true).apply { gravity = Gravity.CENTER; setPadding(20, dp(50), 20, dp(8)) })
        r.addView(title(heading, 25f).apply { gravity = Gravity.CENTER })
        r.addView(body(message, muted).apply { gravity = Gravity.CENTER })
        r.addView(button("Retry") { openWeb(retryPath) })
        r.addView(button("Return Home") { showHome() })
        content.addView(scroll(r))
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    override fun onBackPressed() {
        val web = activeWebView
        if (web != null && web.canGoBack()) web.goBack() else showHome()
    }
}
