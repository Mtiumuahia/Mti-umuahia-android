MTI Website V153 — Admission Submission & Student Activation Workflow

NEW WORKFLOW
1. Applicant opens Apply Now.
2. Applicant fills the admission form.
3. Applicant submits the application.
4. NO Auth account is created.
5. NO password is requested.
6. NO Student Portal access is created.
7. Applicant receives the application number on screen and should keep it.
8. MTI Admissions reviews the application.
9. If MTI admits the applicant, the existing V137 admission workflow generates:
   - MTI Registration Number
   - one-time MTI Activation Token/Code
10. MTI sends the admission notification using the existing V137 notification workflow.
11. The admitted student visits /student-activation.
12. Student enters Registration Number + Activation Code + admission email + new password.
13. Existing activate-student-v137 Edge Function verifies the admission and creates the Student Portal account.
14. The activation token becomes permanently unusable after activation.

DATABASE
Run MTI-V153-SQL.sql in Supabase AFTER the existing V137 migration.
No duplicate application table is created.
The migration makes applications.user_id nullable where that column exists and adds one public SECURITY DEFINER submission RPC.

IMPORTANT
V153 intentionally does not create applicant Auth accounts at application time.
The existing Applicant Portal remains available for legacy accounts, but the new Apply Now workflow does not create those accounts.
