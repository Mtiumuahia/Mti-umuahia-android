MTI V210 — CUSTOMER CARE CHATBOT

Purpose:
Adds a professional floating MTI Customer Care assistant to the public website.

Features:
- Floating Customer Care button.
- Responsive chat panel.
- MTI logo and institutional styling.
- Quick-help topics for admissions, application status, Student Portal, programmes, Visit MTI, hostel and technical support.
- Simple keyword-based answers; no AI/API/backend dependency.
- Admissions, Visit MTI and technical-support actions.
- Technical support email remains inside a mailto action and is not displayed as text.
- Excludes portal/admin routes to preserve portal UI isolation.
- Escape-to-close, focus states, aria labels and reduced-motion support.

Database:
No SQL migration required.
