MTI UMUAHIA — V208
Homepage Hero Editorial Alignment & Mobile Readability

Changes:
- Replaced the homepage hero eyebrow "METHODIST CHURCH NIGERIA · UMUAHIA" with the requested concise institutional label "MTI · UMUAHIA".
- Reworked hero title markup into controlled title lines so words cannot break mid-word on narrow screens.
- Restored strict left alignment for eyebrow, title, body copy and CTA area.
- Improved mobile hero typography, spacing and content width for a mature, editorial presentation.
- Kept the MTI logo/mark positioned below the text on mobile without forcing the hero into a scattered layout.
- Preserved existing footer wording and institutional content.
- Preserved reduced-motion support.

Database:
No SQL migration required.

Testing:
- node --check passed for the modified homepage renderer.
- CSS brace-balance check passed for the modified stylesheet.
- Static verification confirmed the old hero eyebrow is removed and the new label is present.
