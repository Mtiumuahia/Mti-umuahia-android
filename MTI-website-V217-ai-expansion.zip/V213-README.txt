MTI WEBSITE V213 — LIVE APPROVED-CONTENT AI ASSISTANT

What changed
- Upgraded the V212 AI assistant so the server retrieves current approved public MTI content from the existing Supabase project before calling OpenAI.
- Live retrieval covers published News, Events, published Programme records, Leadership, Gallery metadata, and the existing V154 Admissions portal-status RPC.
- No new Supabase table, bucket, policy, or SQL migration was created.
- Private applications, student records, payments, results, credentials, and management records are not queried by the AI retrieval layer.
- The OpenAI API key remains server-side in Netlify Functions.
- The public Supabase publishable key is used only for public content retrieval; no Supabase service-role key is exposed or required.

OpenAI / Netlify setup
1. Open the MTI site in Netlify.
2. Go to Site configuration → Environment variables.
3. Add:
   Key: OPENAI_API_KEY
   Value: your OpenAI API key
   Scope: Functions (if your Netlify plan/UI provides scope selection).
4. Optional:
   Key: MTI_AI_MODEL
   Value: gpt-5.6-luna
5. Optional if the Supabase project ever changes:
   MTI_SUPABASE_URL = the public Supabase project URL
   MTI_SUPABASE_ANON_KEY = the public/publishable Supabase key
   The V213 code already has the current project values as fallbacks.
6. Save the variables and create a new deploy. Netlify applies changed environment variables to Functions after a new deploy.

SECURITY
- NEVER paste OPENAI_API_KEY into ChatGPT, index.html, frontend JavaScript, CSS, SQL, GitHub, or a public repository.
- Do not use NEXT_PUBLIC_, VITE_, PUBLIC_, or another browser-exposed variable for the OpenAI secret.
- The browser only calls /.netlify/functions/mti-assistant.

Testing
- Run node --check against all JS/JS-module files.
- Validate CSS structure.
- Validate local asset references.
- Verify ZIP integrity with unzip -t.
- A live OpenAI response cannot be authenticated/tested until the owner adds OPENAI_API_KEY to Netlify.

SQL
NO SQL MIGRATION REQUIRED FOR V213.
