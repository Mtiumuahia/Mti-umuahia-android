BEGIN;

CREATE OR REPLACE FUNCTION public.mti_lookup_application_status_v157(
  p_application_ref text,
  p_email text
)
RETURNS TABLE (
  id uuid,
  application_no text,
  application_number text,
  full_name text,
  email text,
  programme text,
  status text,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path = public
AS $function$
DECLARE
  v_ref text := trim(coalesce(p_application_ref, ''));
  v_email text := lower(trim(coalesce(p_email, '')));
BEGIN
  IF v_ref = '' OR v_email = '' THEN
    RAISE EXCEPTION 'Application number and email address are required.';
  END IF;

  RETURN QUERY
  SELECT
    a.id,
    a.application_no::text,
    a.application_number::text,
    a.full_name::text,
    a.email::text,
    a.programme::text,
    coalesce(a.status, 'submitted')::text,
    a.created_at
  FROM public.applications a
  WHERE lower(trim(coalesce(a.email, ''))) = v_email
    AND (
      lower(trim(coalesce(a.application_no, ''))) = lower(v_ref)
      OR lower(trim(coalesce(a.application_number, ''))) = lower(v_ref)
    )
  LIMIT 1;
END;
$function$;

REVOKE ALL ON FUNCTION public.mti_lookup_application_status_v157(text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mti_lookup_application_status_v157(text,text) TO anon, authenticated;

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';
COMMIT;
