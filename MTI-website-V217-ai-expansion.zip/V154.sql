BEGIN;

CREATE TABLE IF NOT EXISTS public.mti_admission_portal_control_v154 (
  id boolean PRIMARY KEY DEFAULT true CHECK (id = true),
  is_open boolean NOT NULL DEFAULT false,
  application_opened_at timestamptz,
  application_closed_at timestamptz,
  selection_conference_date date,
  selection_conference_venue text,
  selection_notice text,
  required_documents text,
  updated_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.mti_admission_portal_control_v154 ENABLE ROW LEVEL SECURITY;

INSERT INTO public.mti_admission_portal_control_v154 (id,is_open,selection_notice,required_documents)
VALUES (
  true,
  false,
  'After online applications are submitted, eligible applicants will be notified about the MTI Selection Conference. The conference includes written examination, document verification, interview and medical examination before admission decisions are made.',
  'Applicants should bring the original and photocopies of the documents specified in the official MTI Selection Conference notice.'
)
ON CONFLICT (id) DO NOTHING;

CREATE OR REPLACE FUNCTION public.mti_get_admission_portal_status_v154()
RETURNS TABLE (
  is_open boolean,
  application_opened_at timestamptz,
  application_closed_at timestamptz,
  selection_conference_date date,
  selection_conference_venue text,
  selection_notice text,
  required_documents text
)
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path=public
AS $function$
  SELECT is_open, application_opened_at, application_closed_at,
         selection_conference_date, selection_conference_venue,
         selection_notice, required_documents
  FROM public.mti_admission_portal_control_v154
  WHERE id=true;
$function$;

REVOKE ALL ON FUNCTION public.mti_get_admission_portal_status_v154() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mti_get_admission_portal_status_v154() TO anon, authenticated;

CREATE OR REPLACE FUNCTION public.mti_set_admission_portal_v154(
  p_open boolean,
  p_selection_date date DEFAULT NULL,
  p_selection_venue text DEFAULT NULL,
  p_selection_notice text DEFAULT NULL,
  p_required_documents text DEFAULT NULL
)
RETURNS public.mti_admission_portal_control_v154
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path=public
AS $function$
DECLARE v_row public.mti_admission_portal_control_v154;
BEGIN
  IF NOT (public.has_portal_role('management') OR public.has_portal_role('admin')) THEN
    RAISE EXCEPTION 'Management access is required.';
  END IF;

  INSERT INTO public.mti_admission_portal_control_v154(
    id,is_open,application_opened_at,application_closed_at,
    selection_conference_date,selection_conference_venue,
    selection_notice,required_documents,updated_by,updated_at
  ) VALUES (
    true,p_open,
    CASE WHEN p_open THEN now() ELSE NULL END,
    CASE WHEN NOT p_open THEN now() ELSE NULL END,
    p_selection_date,trim(NULLIF(p_selection_venue,'')),
    trim(NULLIF(p_selection_notice,'')),trim(NULLIF(p_required_documents,'')),
    auth.uid(),now()
  )
  ON CONFLICT(id) DO UPDATE SET
    is_open=EXCLUDED.is_open,
    application_opened_at=CASE WHEN EXCLUDED.is_open THEN now() ELSE mti_admission_portal_control_v154.application_opened_at END,
    application_closed_at=CASE WHEN NOT EXCLUDED.is_open THEN now() ELSE mti_admission_portal_control_v154.application_closed_at END,
    selection_conference_date=EXCLUDED.selection_conference_date,
    selection_conference_venue=EXCLUDED.selection_conference_venue,
    selection_notice=COALESCE(EXCLUDED.selection_notice,mti_admission_portal_control_v154.selection_notice),
    required_documents=COALESCE(EXCLUDED.required_documents,mti_admission_portal_control_v154.required_documents),
    updated_by=auth.uid(),updated_at=now()
  RETURNING * INTO v_row;
  RETURN v_row;
END;
$function$;

REVOKE ALL ON FUNCTION public.mti_set_admission_portal_v154(boolean,date,text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mti_set_admission_portal_v154(boolean,date,text,text,text) TO authenticated;

-- Add the hard server-side gate to the public submission RPC.
-- The portal cannot be bypassed merely by calling the REST RPC while closed.
CREATE OR REPLACE FUNCTION public.mti_submit_public_application_v153(
  p_full_name text,p_email text,p_phone text,p_programme text,
  p_level text DEFAULT NULL,p_section text DEFAULT NULL,p_statement text DEFAULT NULL
)
RETURNS TABLE (id uuid, application_no text, application_number text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path=public
AS $function$
DECLARE
  v_open boolean;
  v_id uuid;
  v_app_no text;
  v_app_number text;
  v_name text:=trim(coalesce(p_full_name,''));
  v_email text:=lower(trim(coalesce(p_email,'')));
  v_phone text:=trim(coalesce(p_phone,''));
  v_programme text:=trim(coalesce(p_programme,''));
  v_level text:=NULLIF(trim(coalesce(p_level,'')),'');
  v_section text:=NULLIF(trim(coalesce(p_section,'')),'');
  v_statement text:=NULLIF(trim(coalesce(p_statement,'')),'');
  cols text[]:=ARRAY['id']; vals text[]:=ARRAY['gen_random_uuid()'];
  c text; exists_col boolean; nullable_col text; default_col text; generated text;
BEGIN
  SELECT is_open INTO v_open FROM public.mti_admission_portal_control_v154 WHERE id=true;
  IF coalesce(v_open,false)=false THEN RAISE EXCEPTION 'Admission is not ongoing now. Please check later.'; END IF;
  IF length(v_name)<3 THEN RAISE EXCEPTION 'Full name is required.'; END IF;
  IF v_email !~* '^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$' THEN RAISE EXCEPTION 'Please provide a valid email address.'; END IF;
  IF length(v_phone)<7 THEN RAISE EXCEPTION 'A valid phone number is required.'; END IF;
  IF v_programme='' THEN RAISE EXCEPTION 'Please select a programme.'; END IF;

  IF EXISTS (SELECT 1 FROM public.applications a WHERE lower(coalesce(a.email,''))=v_email AND a.created_at>now()-interval '10 minutes') THEN
    RAISE EXCEPTION 'An application using this email address was submitted recently. Please wait or contact MTI Admissions.';
  END IF;

  FOREACH c IN ARRAY ARRAY['full_name','email','phone','programme','level','section','statement','status','user_id'] LOOP
    SELECT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name=c) INTO exists_col;
    IF NOT exists_col THEN CONTINUE; END IF;
    SELECT is_nullable,column_default INTO nullable_col,default_col FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name=c;
    IF c='full_name' THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_name));
    ELSIF c='email' THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_email));
    ELSIF c='phone' THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_phone));
    ELSIF c='programme' THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_programme));
    ELSIF c='level' AND v_level IS NOT NULL THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_level));
    ELSIF c='section' AND v_section IS NOT NULL THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_section));
    ELSIF c='statement' AND v_statement IS NOT NULL THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_nullable(v_statement));
    ELSIF c='status' THEN cols:=array_append(cols,c);vals:=array_append(vals,quote_literal('submitted'));
    ELSIF c='user_id' AND nullable_col='YES' THEN cols:=array_append(cols,c);vals:=array_append(vals,'NULL');
    END IF;
  END LOOP;

  SELECT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name='application_no') INTO exists_col;
  IF exists_col THEN
    SELECT column_default INTO default_col FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name='application_no';
    IF default_col IS NULL THEN
      generated:='MTI/APP/'||to_char(now(),'YYYY')||'/'||upper(substr(encode(gen_random_bytes(6),'hex'),1,8));
      cols:=array_append(cols,'application_no');vals:=array_append(vals,quote_literal(generated));
    END IF;
  ELSE
    SELECT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name='application_number') INTO exists_col;
    IF exists_col THEN
      SELECT column_default INTO default_col FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name='application_number';
      IF default_col IS NULL THEN
        generated:='MTI/APP/'||to_char(now(),'YYYY')||'/'||upper(substr(encode(gen_random_bytes(6),'hex'),1,8));
        cols:=array_append(cols,'application_number');vals:=array_append(vals,quote_literal(generated));
      END IF;
    END IF;
  END IF;

  FOREACH c IN ARRAY ARRAY['created_at','updated_at'] LOOP
    SELECT EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name=c) INTO exists_col;
    IF exists_col THEN SELECT column_default INTO default_col FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name=c; IF default_col IS NULL THEN cols:=array_append(cols,c);vals:=array_append(vals,'now()'); END IF; END IF;
  END LOOP;

  EXECUTE 'INSERT INTO public.applications ('||array_to_string(cols,',')||') VALUES ('||array_to_string(vals,',')||') RETURNING id' INTO v_id;
  IF EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name='application_no') THEN EXECUTE 'SELECT application_no::text FROM public.applications WHERE id=$1' INTO v_app_no USING v_id; END IF;
  IF EXISTS(SELECT 1 FROM information_schema.columns WHERE table_schema='public' AND table_name='applications' AND column_name='application_number') THEN EXECUTE 'SELECT application_number::text FROM public.applications WHERE id=$1' INTO v_app_number USING v_id; END IF;
  RETURN QUERY SELECT v_id,v_app_no,v_app_number;
END;
$function$;

REVOKE ALL ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text) TO anon,authenticated;
NOTIFY pgrst,'reload schema';
NOTIFY pgrst,'reload config';
COMMIT;
