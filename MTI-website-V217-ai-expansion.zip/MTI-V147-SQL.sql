BEGIN;

-- ============================================================
-- MTI V147 — Secure Examination Number Registry
-- Reuses student_profiles.exam_number created by V146.
-- No new student/result table is created.
-- ============================================================

CREATE OR REPLACE FUNCTION public.mti_admin_set_student_exam_number_v147(
  p_student_id uuid,
  p_exam_number text
)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_is_staff boolean;
  v_exam_number text;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required.';
  END IF;

  v_is_staff :=
    public.has_portal_role('management')
    OR public.has_portal_role('admin');

  IF NOT v_is_staff THEN
    RAISE EXCEPTION 'Management access required.';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.student_profiles
    WHERE id = p_student_id
  ) THEN
    RAISE EXCEPTION 'Student record not found.';
  END IF;

  v_exam_number := NULLIF(btrim(COALESCE(p_exam_number, '')), '');

  IF v_exam_number IS NOT NULL
     AND length(v_exam_number) > 60 THEN
    RAISE EXCEPTION 'Examination number must not exceed 60 characters.';
  END IF;

  IF v_exam_number IS NOT NULL
     AND EXISTS (
       SELECT 1
       FROM public.student_profiles sp
       WHERE lower(btrim(COALESCE(sp.exam_number, ''))) =
             lower(v_exam_number)
         AND sp.id <> p_student_id
     ) THEN
    RAISE EXCEPTION
      'That examination number is already assigned to another student.';
  END IF;

  UPDATE public.student_profiles
  SET
    exam_number = v_exam_number,
    updated_at = now()
  WHERE id = p_student_id;

  RETURN v_exam_number;
END;
$function$;

REVOKE ALL
ON FUNCTION public.mti_admin_set_student_exam_number_v147(uuid,text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.mti_admin_set_student_exam_number_v147(uuid,text)
TO authenticated;

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
