BEGIN;

CREATE TABLE IF NOT EXISTS public.selection_conference_assessments_v160 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL REFERENCES public.applications(id) ON DELETE CASCADE,
  written_exam_status text NOT NULL DEFAULT 'pending' CHECK (written_exam_status IN ('pending','completed','not_completed')),
  document_verification_status text NOT NULL DEFAULT 'pending' CHECK (document_verification_status IN ('pending','completed','not_completed')),
  interview_status text NOT NULL DEFAULT 'pending' CHECK (interview_status IN ('pending','completed','not_completed')),
  medical_status text NOT NULL DEFAULT 'pending' CHECK (medical_status IN ('pending','completed','not_completed')),
  notes text,
  assessed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  assessed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(application_id)
);

CREATE INDEX IF NOT EXISTS selection_conference_assessments_v160_application_idx
ON public.selection_conference_assessments_v160(application_id);

ALTER TABLE public.selection_conference_assessments_v160 ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS v160_management_select ON public.selection_conference_assessments_v160;
CREATE POLICY v160_management_select
ON public.selection_conference_assessments_v160
FOR SELECT TO authenticated
USING (public.has_portal_role('management') OR public.has_portal_role('admin'));

DROP POLICY IF EXISTS v160_management_insert ON public.selection_conference_assessments_v160;
CREATE POLICY v160_management_insert
ON public.selection_conference_assessments_v160
FOR INSERT TO authenticated
WITH CHECK (public.has_portal_role('management') OR public.has_portal_role('admin'));

DROP POLICY IF EXISTS v160_management_update ON public.selection_conference_assessments_v160;
CREATE POLICY v160_management_update
ON public.selection_conference_assessments_v160
FOR UPDATE TO authenticated
USING (public.has_portal_role('management') OR public.has_portal_role('admin'))
WITH CHECK (public.has_portal_role('management') OR public.has_portal_role('admin'));

CREATE OR REPLACE FUNCTION public.mti_update_selection_assessment_v160(
  p_application_id uuid,
  p_written_exam_status text,
  p_document_verification_status text,
  p_interview_status text,
  p_medical_status text,
  p_notes text DEFAULT NULL
)
RETURNS public.selection_conference_assessments_v160
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_row public.selection_conference_assessments_v160;
BEGIN
  IF NOT (public.has_portal_role('management') OR public.has_portal_role('admin')) THEN
    RAISE EXCEPTION 'Management access is required.';
  END IF;

  IF NOT EXISTS (SELECT 1 FROM public.applications AS a WHERE a.id = p_application_id) THEN
    RAISE EXCEPTION 'Application not found.';
  END IF;

  IF p_written_exam_status NOT IN ('pending','completed','not_completed')
     OR p_document_verification_status NOT IN ('pending','completed','not_completed')
     OR p_interview_status NOT IN ('pending','completed','not_completed')
     OR p_medical_status NOT IN ('pending','completed','not_completed') THEN
    RAISE EXCEPTION 'Invalid assessment status.';
  END IF;

  INSERT INTO public.selection_conference_assessments_v160 (
    application_id, written_exam_status, document_verification_status,
    interview_status, medical_status, notes, assessed_by, assessed_at, updated_at
  ) VALUES (
    p_application_id, p_written_exam_status, p_document_verification_status,
    p_interview_status, p_medical_status, NULLIF(trim(p_notes), ''), auth.uid(), now(), now()
  )
  ON CONFLICT (application_id) DO UPDATE SET
    written_exam_status = EXCLUDED.written_exam_status,
    document_verification_status = EXCLUDED.document_verification_status,
    interview_status = EXCLUDED.interview_status,
    medical_status = EXCLUDED.medical_status,
    notes = EXCLUDED.notes,
    assessed_by = auth.uid(),
    assessed_at = now(),
    updated_at = now()
  RETURNING * INTO v_row;

  RETURN v_row;
END;
$function$;

REVOKE ALL ON FUNCTION public.mti_update_selection_assessment_v160(uuid,text,text,text,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mti_update_selection_assessment_v160(uuid,text,text,text,text,text) TO authenticated;

CREATE OR REPLACE FUNCTION public.mti_finalize_admission_decision_v160(
  p_application_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_assessment public.selection_conference_assessments_v160;
  v_result jsonb;
BEGIN
  IF NOT (public.has_portal_role('management') OR public.has_portal_role('admin')) THEN
    RAISE EXCEPTION 'Management access is required.';
  END IF;

  SELECT * INTO v_assessment
  FROM public.selection_conference_assessments_v160 AS s
  WHERE s.application_id = p_application_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Selection Conference assessment has not been completed.';
  END IF;

  IF v_assessment.written_exam_status <> 'completed'
     OR v_assessment.document_verification_status <> 'completed'
     OR v_assessment.interview_status <> 'completed'
     OR v_assessment.medical_status <> 'completed' THEN
    RAISE EXCEPTION 'All four Selection Conference stages must be marked completed before admission.';
  END IF;

  SELECT to_jsonb(x) INTO v_result
  FROM public.mti_admit_applicant_v137(p_application_id) AS x;

  RETURN v_result;
END;
$function$;

REVOKE ALL ON FUNCTION public.mti_finalize_admission_decision_v160(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.mti_finalize_admission_decision_v160(uuid) TO authenticated;

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
