MTI V207 — Full Audit, Conflict Cleanup & Security Hardening

Audit scope:
- Full frontend file inventory and route/reference audit.
- 68 JavaScript syntax checks.
- CSS brace-balance checks across all 91 CSS files.
- Local asset-reference audit.
- Duplicate-ID audit of index.html.
- Route/script conflict inspection.
- Supabase/SQL migration inspection.
- Public/portal CSS and script isolation inspection.

Confirmed fixes:
1. V194 public-footer motion was incorrectly adding the public-shell class to portal/admin routes. It is now public-route scoped.
2. V130 global public animation/card rules are now scoped to the public shell, preventing public CSS from styling portal cards/hero elements.
3. V204 communication and unused V205 communication implementations are no longer active. V207 provides one public-only implementation with the required Facebook and technical-complaint actions.
4. /visit no longer loads public-v191-institutional-polish.js twice.
5. Transcript Records and Academic Clearance now use the authenticated Supabase access token instead of sending the public anon key as a Bearer token, and they require an authenticated session before rendering.
6. The CMS now verifies an existing management/admin portal role before exposing content-management controls.
7. V180 news-media storage write policies are hardened in V207-SQL so authenticated users without management/admin roles cannot upload, update or delete news media.

Database:
V207 requires the supplied SQL migration because it changes existing storage-object policies. No new application table, bucket, RPC or schema is introduced.

Important limitation:
The supplied project does not contain the complete historical database schema/migrations or privileged Supabase credentials, so live production table/RLS state outside the supplied SQL cannot be independently verified from this ZIP. No schema was guessed or recreated.
