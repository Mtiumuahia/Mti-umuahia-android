MTI V206 — Admissions Blank-Page & Apply-Now Contrast Repair

Purpose:
1. Restore the public /admissions page by loading the existing React public-site renderer (index-mti-home-v14.js) on the /admissions and /programmes routes. The previous route branch loaded only enhancement scripts, so #root remained empty.
2. Repair the /apply-now hero heading/button contrast. The V182 selectors were incorrectly scoped under #root, but the standalone application shell is mounted directly under <body>. V206 uses a narrowly scoped selector for #mti-apply-v154 instead.

Database:
No SQL migration required.

Existing architecture preserved. No tables, RPCs, buckets, policies, routes, or legacy migration files were removed.
