/* MTI V209 — public route QA guard.
   Adds a stable public marker and removes any legacy footer Contact/Gallery links
   that may be emitted by an older cached renderer. */
(function(){
  'use strict';
  var publicRoutes=['/','/about','/leadership','/governance','/research','/library','/alumni','/campus','/support','/programmes','/admissions','/student-life','/news','/events','/gallery','/contact','/visit','/faq','/ministry'];
  var path=location.pathname.replace(/\/$/,'')||'/';
  if(publicRoutes.indexOf(path)===-1)return;
  document.documentElement.classList.add('mti-v209-public');
  function cleanFooter(){
    document.querySelectorAll('footer a').forEach(function(a){
      var label=(a.textContent||'').trim().toLowerCase();
      if(label==='contact'||label==='gallery')a.remove();
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',cleanFooter);else cleanFooter();
  if(window.MutationObserver&&document.body)new MutationObserver(cleanFooter).observe(document.body,{childList:true,subtree:true});
})();
