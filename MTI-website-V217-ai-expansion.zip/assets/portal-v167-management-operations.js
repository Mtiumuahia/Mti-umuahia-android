(function(){
'use strict';
if(location.pathname.replace(/\/$/,'')!=='/management-dashboard')return;
function add(){
 const root=document.querySelector('#mti-v79');
 const content=root&&root.querySelector('#v77-content');
 if(!content||content.dataset.v167==='1')return;
 content.dataset.v167='1';
 const top=document.createElement('div');
 top.className='v167-ops-strip';
 top.innerHTML='<button class="v167-op" data-go167="admission-control"><small>ADMISSIONS</small><b>Admission Control</b><span>Open or close applications and manage Selection Conference details.</span></button><button class="v167-op" data-go167="applications"><small>REVIEW</small><b>Application Review</b><span>Inspect submissions and move applicants through the process.</span></button><button class="v167-op" data-go167="academics"><small>ACADEMICS</small><b>Academic Centre</b><span>Courses, teaching loads and result approval.</span></button><button class="v167-op" data-go167="accounts"><small>STAFF</small><b>Staff Accounts</b><span>Create authorised lecturer accounts and review access.</span></button>';
 content.prepend(top);
 top.querySelectorAll('[data-go167]').forEach(b=>b.onclick=()=>{
   const old=content.querySelector('[data-page="'+b.dataset.go167+'"]');
   if(old) old.click();
 });
 const pageText=(content.querySelector('.v67-head')||{}).textContent||'';
 if(/ADMISSIONS/i.test(pageText)&&!content.querySelector('.v167-route-note')){
   const note=document.createElement('div');note.className='v167-route-note';
   note.innerHTML='<div><strong>Admissions Office</strong><span>Selection assessment and protected admission decisions are managed in the dedicated Admissions Office.</span></div><a class="v67-btn alt" href="/admissions-administration">Open Admissions Office →</a>';
   content.insertBefore(note,content.firstElementChild?.nextSibling||null);
 }
}
const obs=new MutationObserver(add);obs.observe(document.body,{childList:true,subtree:true});setTimeout(add,300);setTimeout(add,1200);
})();
