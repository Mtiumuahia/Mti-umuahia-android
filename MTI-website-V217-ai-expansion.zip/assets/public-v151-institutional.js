/* MTI V151 — Institutional page interaction and navigation polish */
(function(){
  'use strict';
  var routes=['/about','/leadership','/governance','/visit'];
  var path=location.pathname.replace(/\/$/,'')||'/';
  if(routes.indexOf(path)===-1)return;
  function apply(){
    document.documentElement.classList.add('mti-v151-institutional');
    document.title=(path==='/about'?'About MTI':path==='/leadership'?'Leadership | MTI':path==='/governance'?'Governance & Policies | MTI':'Visit MTI')+' | Methodist Theological Institute, Umuahia';
    var groups=document.querySelectorAll('nav .nav-group');
    groups.forEach(function(group){
      var active=false;
      group.querySelectorAll('.nav-dropdown a').forEach(function(a){
        var u=new URL(a.href,location.origin), ap=u.pathname.replace(/\/$/,'')||'/';
        if(ap===path){active=true;a.classList.add('mti-v151-active-link');}
      });
      if(active){
        group.classList.add('mti-v151-active-group');
        var trigger=group.querySelector('.nav-trigger');
        if(trigger)trigger.classList.add('mti-v151-active-trigger');
      }
    });
    var targets=[];
    document.querySelectorAll('.content > *, .section > *, .visit-v23 > section').forEach(function(el){
      if(el.classList.contains('hero'))return;
      el.classList.add('mti-v151-reveal');
      targets.push(el);
    });
    targets.forEach(function(el,i){el.classList.add('mti-v151-delay-'+((i%3)+1));});
    if('IntersectionObserver' in window){
      var io=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target);}})},{threshold:.08,rootMargin:'0px 0px -30px'});
      targets.forEach(function(el){io.observe(el);});
    }else targets.forEach(function(el){el.classList.add('is-visible');});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply);else apply();
})();
