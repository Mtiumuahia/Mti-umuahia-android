/* MTI V147 — Lecturer whole-class result sheet, production hardening */
(function(){
  'use strict';
  if(location.pathname.replace(/\/$/,'')!=='/lecturer-result-entry') return;

  const U='https://vjpwllvssblgpwckbiff.supabase.co';
  const K='sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal';
  const KEY='sb-vjpwllvssblgpwckbiff-auth-token';
  const root=document.getElementById('root');
  if(!root) return;

  let token=null,user=null,assignments=[],courses=[],sessions=[],selected=null,roster=[],results=[];

  const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const grade=s=>{
    const n=Number(s);
    if(!Number.isFinite(n)) return ['',''];
    if(n>=70) return ['A',5];
    if(n>=60) return ['B',4];
    if(n>=50) return ['C',3];
    if(n>=45) return ['D',2];
    if(n>=40) return ['E',1];
    return ['F',0];
  };
  const headers=()=>({apikey:K,Authorization:'Bearer '+token,Accept:'application/json','Content-Type':'application/json'});

  async function api(path,opt={}){
    const r=await fetch(U+path,Object.assign({headers:headers()},opt));
    let d=null;
    try{d=await r.json()}catch(_){ }
    if(!r.ok) throw Error(d?.message||d?.hint||d?.details||d?.error_description||'Request failed');
    return d;
  }

  function saved(){
    try{return JSON.parse(localStorage.getItem(KEY)||'null')}catch(_){return null}
  }

  function sameSemester(a,b){
    const x=String(a||'').trim().toLowerCase();
    const y=String(b||'').trim().toLowerCase();
    if(!x||!y) return true;
    if(x===y) return true;
    const first=['first semester','1st semester','first','1'];
    const second=['second semester','2nd semester','second','2'];
    return (first.includes(x)&&first.includes(y))||(second.includes(x)&&second.includes(y));
  }

  function layout(){
    root.innerHTML=`
      <main class="mti147-results">
        <header class="m147-top">
          <div class="m147-brand">
            <img src="/assets/mti-logo.png" alt="MTI">
            <div><b>Methodist Theological Institute, Umuahia</b><small>LECTURER · WHOLE-CLASS RESULT ENTRY</small></div>
          </div>
          <a href="/lecturer-portal#results">← Lecturer Portal</a>
        </header>
        <div class="m147-wrap">
          <div class="m147-head">
            <div>
              <span class="m147-kicker">ACADEMIC RESULTS OFFICE</span>
              <h1>Whole-Class Result Entry</h1>
              <p>One secure class sheet for every student registered for the selected course. Enter scores, review grades and submit the class together for Academic Management approval.</p>
            </div>
            <div class="m147-window">Signed in as <strong id="m147-user">—</strong></div>
          </div>

          <section class="m147-card">
            <div class="m147-card-head">
              <div><span class="m147-step">STEP 01</span><h2>Select Teaching Class</h2><p>Only your active assignments and open result-entry windows are available.</p></div>
            </div>
            <div class="m147-form">
              <label>Academic session & semester<select id="m147-session"><option value="">Select open result window</option></select></label>
              <label>Course<select id="m147-course"><option value="">Select assigned course</option></select></label>
              <button class="m147-btn" id="m147-load">Load Class List</button>
            </div>
            <div class="m147-note"><b>Class sheet rule:</b> every registered student appears in one table. Student name, MTI registration number and examination number are read-only. Scores and remarks are entered by the lecturer.</div>
          </section>

          <section id="m147-board"></section>
          <div class="m147-foot">MTI result workflow · Lecturer enters draft → Academic Management reviews → Approved result is published to the student.</div>
        </div>
      </main>`;
  }

  async function init(){
    layout();
    const s=saved();
    if(!s?.access_token||!s?.user?.id){
      root.innerHTML='<div class="m147-empty"><div><h2>Lecturer sign-in required</h2><p>Open the MTI Lecturer Portal and sign in before opening Result Entry.</p><a href="/lecturer-portal">Open Lecturer Portal</a></div></div>';
      return;
    }
    token=s.access_token;
    user=s.user;
    document.getElementById('m147-user').textContent=user.email||'Lecturer';
    try{
      const [a,c,sess]=await Promise.all([
        api('/rest/v1/lecturer_courses?select=id,course_id,academic_session,semester,assignment_status,credit_load&lecturer_id=eq.'+encodeURIComponent(user.id)+'&assignment_status=eq.active&limit=500'),
        api('/rest/v1/academic_courses?select=id,course_code,course_title,credit_load,active,programme_name,level,semester&active=eq.true&order=course_code.asc&limit=3000'),
        api('/rest/v1/academic_sessions_v89?select=id,session_name,semester,status,result_entry_open&status=eq.active&order=session_name.desc&limit=100')
      ]);
      assignments=a||[];courses=c||[];sessions=sess||[];
      populateSessions();
    }catch(e){message(e.message,true)}
  }

  function course(id){return courses.find(x=>String(x.id)===String(id))||{}}

  function populateSessions(){
    const ss=document.getElementById('m147-session');
    const open=sessions.filter(x=>x.result_entry_open);
    ss.innerHTML='<option value="">Select open result window</option>'+open.map((x,i)=>`<option value="${esc(x.session_name)}" data-semester="${esc(x.semester)}" ${i===0?'selected':''}>${esc(x.session_name)} — ${esc(x.semester)}</option>`).join('');
    ss.onchange=syncCourses;
    syncCourses();
  }

  function syncCourses(){
    const ss=document.getElementById('m147-session');
    const so=ss?.selectedOptions?.[0];
    const session=so?.value||'';
    const semester=so?.dataset?.semester||'';
    const eligible=assignments.filter(a=>
      (!session || !a.academic_session || String(a.academic_session).toLowerCase()===session.toLowerCase()) &&
      (!semester || sameSemester(a.semester,semester))
    );
    const cs=document.getElementById('m147-course');
    cs.innerHTML='<option value="">Select assigned course</option>'+eligible.map(a=>{
      const c=course(a.course_id);
      return `<option value="${esc(a.course_id)}">${esc(c.course_code||'Course')} — ${esc(c.course_title||'')}</option>`;
    }).join('');
  }

  function message(text,error){
    const board=document.getElementById('m147-board');
    if(board) board.innerHTML=`<section class="m147-card"><div class="m147-message show ${error?'error':'success'}">${esc(text)}</div></section>`;
  }

  async function loadClass(){
    const cid=document.getElementById('m147-course').value;
    const so=document.getElementById('m147-session').selectedOptions[0];
    if(!cid||!so?.value){message('Select an academic session and an assigned course.',true);return}
    const semester=so.dataset.semester||'';
    const assignment=assignments.find(a=>String(a.course_id)===String(cid));
    if(assignment?.academic_session && assignment.academic_session.toLowerCase()!==so.value.toLowerCase()){
      message('This teaching assignment belongs to a different academic session.',true);
      return;
    }
    selected={cid,session:so.value,semester};
    const board=document.getElementById('m147-board');
    board.innerHTML='<section class="m147-card"><div class="m147-loading"><span></span><b>Loading the registered class list…</b><small>Checking course registration and existing draft results.</small></div></section>';
    try{
      const rosterPromise=api('/rest/v1/rpc/mti_get_lecturer_result_roster_v146',{method:'POST',body:JSON.stringify({p_course_id:cid,p_academic_session:selected.session,p_semester:selected.semester})});
      const resultPromise=api('/rest/v1/student_results?select=id,student_id,score,grade,grade_points,remark,status,created_at,semester,course_id,entered_by&course_id=eq.'+encodeURIComponent(cid)+'&semester=eq.'+encodeURIComponent(semester)+'&order=created_at.desc&limit=5000').catch(()=>[]);
      const [rr,res]=await Promise.all([rosterPromise,resultPromise]);
      roster=rr||[];
      results=res||[];
      render();
    }catch(e){message(e.message,true)}
  }

  function latest(id){return results.find(r=>String(r.student_id)===String(id))||null}

  function render(){
    const c=course(selected.cid);
    const open=sessions.some(s=>String(s.session_name)===String(selected.session)&&sameSemester(s.semester,selected.semester)&&s.result_entry_open);
    if(!open){message('The selected result-entry window is no longer open. Refresh the session list.',true);return}
    const board=document.getElementById('m147-board');
    board.innerHTML=`
      <section class="m147-card m147-sheet">
        <div class="m147-card-head m147-sheet-head">
          <div><span class="m147-kicker">${esc(c.course_code||'COURSE')}</span><h2>${esc(c.course_title||'Selected Course')}</h2><p>${esc(selected.session)} · ${esc(selected.semester)} · ${roster.length} registered student${roster.length===1?'':'s'}</p></div>
          <div class="m147-head-actions"><button class="m147-btn secondary" id="m147-print">Print Sheet</button><button class="m147-btn secondary" id="m147-reload">Reload</button><button class="m147-save" id="m147-save">Save Entire Class</button></div>
        </div>
        <div class="m147-toolbar">
          <div class="m147-toolbar-left"><span class="m147-stat">Students <b>${roster.length}</b></span><span class="m147-stat">Entered <b id="m147-entered">0</b></span><span class="m147-stat">Remaining <b id="m147-remaining">${roster.length}</b></span><span class="m147-stat">Average <b id="m147-average">—</b></span></div>
          <label class="m147-search">Search class <input id="m147-search" type="search" placeholder="Name, registration no. or exam no."></label>
        </div>
        <div class="m147-table-wrap"><table class="m147-table"><thead><tr><th>#</th><th>Student Name</th><th>MTI Reg. No.</th><th>Exam No.</th><th>Score / 100</th><th>Grade</th><th>GP</th><th>Status</th><th>Remark</th></tr></thead><tbody>${roster.map((s,i)=>row(s,i)).join('')||'<tr><td colspan="9" class="m147-empty-row">No students are registered for this course in the selected academic period.</td></tr>'}</tbody></table></div>
        <div class="m147-below"><span>Use <b>Tab</b> to move through score fields quickly.</span><span>Published results remain locked.</span></div>
        <div id="m147-msg" class="m147-message"></div>
      </section>`;

    board.querySelectorAll('.m147-input[data-score]').forEach(inp=>inp.addEventListener('input',()=>updateRow(inp)));
    board.querySelectorAll('.m147-remark').forEach(inp=>inp.addEventListener('input',()=>{if(inp.value.length>250)inp.value=inp.value.slice(0,250)}));
    document.getElementById('m147-save').onclick=saveAll;
    document.getElementById('m147-reload').onclick=loadClass;
    document.getElementById('m147-print').onclick=()=>window.print();
    document.getElementById('m147-search').oninput=filterRows;
    summary();
  }

  function row(s,i){
    const r=latest(s.student_id);
    const published=String(r?.status||'').toLowerCase()==='published';
    const val=r?.score??'';
    const g=val===''?'':grade(val);
    const name=[s.first_name,s.middle_name,s.last_name].filter(Boolean).join(' ')||'Unnamed Student';
    return `<tr data-student="${esc(s.student_id)}" data-published="${published?'1':'0'}" data-search="${esc((name+' '+(s.student_number||'')+' '+(s.exam_number||'')).toLowerCase())}">
      <td class="m147-num">${i+1}</td>
      <td class="m147-student"><strong>${esc(name)}</strong><small>${esc(s.programme||'')}${s.level?' · '+esc(s.level):''}</small></td>
      <td class="m147-reg">${esc(s.student_number||'—')}</td>
      <td class="m147-exam">${esc(s.exam_number||'Not assigned')}</td>
      <td><input class="m147-input" data-score type="number" min="0" max="100" step="0.01" value="${esc(val)}" ${published?'disabled':''} placeholder="0–100" aria-label="Score for ${esc(name)}"></td>
      <td class="m147-grade">${esc(r?.grade||g[0]||'—')}</td>
      <td class="m147-gp">${esc(r?.grade_points??(g[1]??'—'))}</td>
      <td><span class="m147-status ${published?'published':(String(r?.status||'').toLowerCase()==='rejected'?'rejected':'')}">${published?'Published':esc(r?.status||'Not entered')}</span></td>
      <td><input class="m147-remark" maxlength="250" value="${esc(r?.remark||'')}" placeholder="Optional" ${published?'disabled':''} aria-label="Remark for ${esc(name)}"></td>
    </tr>`;
  }

  function updateRow(inp){
    const tr=inp.closest('tr');
    const value=inp.value.trim();
    const [g,gp]=grade(value);
    tr.querySelector('.m147-grade').textContent=g||'—';
    tr.querySelector('.m147-gp').textContent=g?gp:'—';
    if(tr.dataset.published!=='1'){
      const status=tr.querySelector('.m147-status');
      status.textContent=value===''?'Not entered':'Ready';
      status.className='m147-status '+(value===''?'':'ready');
    }
    summary();
  }

  function filterRows(){
    const q=String(document.getElementById('m147-search')?.value||'').trim().toLowerCase();
    document.querySelectorAll('.m147-table tbody tr[data-student]').forEach(tr=>{
      tr.hidden=!!q && !String(tr.dataset.search||'').includes(q);
    });
  }

  function summary(){
    const rows=[...document.querySelectorAll('.m147-table tbody tr[data-student]')];
    const vals=rows.map(r=>Number(r.querySelector('[data-score]')?.value)).filter(Number.isFinite);
    const entered=rows.filter(r=>String(r.querySelector('[data-score]')?.value||'')!=='').length;
    const remaining=Math.max(0,rows.length-entered);
    const e=document.getElementById('m147-entered'),rem=document.getElementById('m147-remaining'),avg=document.getElementById('m147-average');
    if(e)e.textContent=entered;
    if(rem)rem.textContent=remaining;
    if(avg)avg.textContent=vals.length?(vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(1):'—';
  }

  async function saveAll(){
    const msg=document.getElementById('m147-msg');
    const btn=document.getElementById('m147-save');
    if(!btn)return;
    const rows=[...document.querySelectorAll('.m147-table tbody tr[data-student]')];
    const payload=rows.map(tr=>{
      const input=tr.querySelector('[data-score]');
      const score=String(input?.value??'').trim();
      const [g,gp]=grade(score);
      return {student_id:tr.dataset.student,score:score===''?null:Number(score),grade:g||null,grade_points:g?gp:null,remark:tr.querySelector('.m147-remark')?.value.trim()||null,published:tr.dataset.published==='1'};
    }).filter(x=>!x.published);

    if(!payload.length){msg.className='m147-message show error';msg.textContent='There are no editable draft rows. Published results are locked.';return}
    const invalid=payload.filter(x=>x.score===null||!Number.isFinite(x.score)||x.score<0||x.score>100);
    if(invalid.length){msg.className='m147-message show error';msg.textContent=`${invalid.length} editable student${invalid.length===1?' is':'s are'} still missing a valid score. Enter every score from 0 to 100 before saving the class.`;return}

    btn.disabled=true;btn.textContent='Saving entire class…';msg.className='m147-message';msg.textContent='';
    try{
      const count=await api('/rest/v1/rpc/mti_bulk_save_student_results_v91',{method:'POST',body:JSON.stringify({p_course_id:selected.cid,p_semester:selected.semester,p_section:null,p_rows:payload.map(x=>({student_id:x.student_id,score:x.score,grade:x.grade,grade_points:x.grade_points,remark:x.remark}))})});
      msg.className='m147-message show success';
      msg.textContent=`✓ ${Number(count)||payload.length} draft result${Number(count)===1?'':'s'} saved together. They remain pending Academic Management approval.`;
      await loadClass();
    }catch(e){
      msg.className='m147-message show error';
      msg.textContent='Unable to save the class results: '+e.message;
    }finally{
      btn.disabled=false;
      btn.textContent='Save Entire Class';
    }
  }

  document.addEventListener('keydown',e=>{
    if(e.key==='Escape' && location.pathname.includes('lecturer-result-entry')){
      const s=document.getElementById('m147-search');
      if(s&&document.activeElement===s){s.value='';filterRows();s.blur();}
    }
  });

  document.getElementById('root');
  init();
})();
