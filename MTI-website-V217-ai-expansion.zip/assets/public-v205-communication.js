(function(){'use strict';
  function isPublic(){
    var p=location.pathname.replace(/\/$/,'')||'/';
    return !/^\/(student|lecturer|management|admin|portal|student-portal|lecturer-portal|online-class|application-status|student-activation|certificate-verification|transcript-verification|official-transcript|graduation-clearance|graduation-certificates|graduation-register|student-results|lecturer-result-entry|academic-session-control|exam-number-registry|academic-timetable)(\/|$)/i.test(p);
  }
  function init(){
    if(!isPublic() || document.querySelector('.mti-v205-help')) return;
    var wrap=document.createElement('div');
    wrap.className='mti-v205-help';
    wrap.setAttribute('aria-label','MTI quick communication actions');
    wrap.innerHTML='<a class="primary" href="https://www.facebook.com/profile.php?id=61550301347674" target="_blank" rel="noopener noreferrer">Visit our Facebook page</a><a class="secondary" href="mailto:godslovedigitalconcerpts@gmail.com?subject=MTI%20Technical%20Complaint">Technical complaints</a>';
    document.body.appendChild(wrap);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
