/* MTI V185 — Leadership interactions */
(function(){'use strict';
  function init(){
    if((location.pathname.replace(/\/$/,'')||'/')!=='/leadership')return;
    document.documentElement.classList.add('mti-v185-leadership');
    document.querySelectorAll('.leader-card').forEach(function(card){
      var bio=card.querySelector('.leader-bio');
      if(!bio || card.querySelector('.mti-v211-leader-toggle'))return;
      var text=(bio.textContent||'').trim();
      if(text.length<260)return;
      var btn=document.createElement('button');
      btn.type='button';btn.className='mti-v185-leader-toggle';btn.textContent='Read profile';
      btn.setAttribute('aria-expanded','false');
      btn.addEventListener('click',function(){
        var open=card.classList.toggle('is-expanded');
        btn.setAttribute('aria-expanded',open?'true':'false');
        btn.textContent=open?'Hide profile':'Read profile';
      });
      bio.parentNode.appendChild(btn);
    });
    var cards=[].slice.call(document.querySelectorAll('.leader-card'));
    if('IntersectionObserver' in window){
      cards.forEach(function(c,i){c.style.transitionDelay=(Math.min(i,5)*55)+'ms'});
      var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('mti-v185-visible');io.unobserve(e.target)}})},{threshold:.08,rootMargin:'0px 0px -25px'});
      cards.forEach(function(c){c.classList.add('mti-v185-reveal');io.observe(c)});
    }else cards.forEach(function(c){c.classList.add('mti-v185-visible')});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
