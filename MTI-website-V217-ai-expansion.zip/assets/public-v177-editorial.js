/* MTI V177 — Public Editorial Experience */
(function(){
  const path=()=>location.pathname.replace(/\/$/,'')||'/';
  const root=()=>document.getElementById('root');
  let lastPath='';
  function decorate(){
    const r=root(); if(!r)return;
    const p=path();
    const publicRoutes=['/','/about','/governance','/visit','/leadership','/programmes','/admissions','/news','/events','/gallery','/sug-executives','/faq','/contact','/research','/library','/alumni','/campus','/student-life','/support'];
    if(publicRoutes.indexOf(p)===-1)return;
    if(p!==lastPath){lastPath=p;document.documentElement.classList.remove('mti-v177-news','mti-v177-events','mti-v177-gallery','mti-v177-leadership','mti-v177-home');document.documentElement.classList.add('mti-v177-public');if(p==='/')document.documentElement.classList.add('mti-v177-home');if(p==='/news')document.documentElement.classList.add('mti-v177-news');if(p==='/events')document.documentElement.classList.add('mti-v177-events');if(p==='/gallery')document.documentElement.classList.add('mti-v177-gallery');if(p==='/leadership')document.documentElement.classList.add('mti-v177-leadership');}
    if(p==='/news')newsTools(r);
    if(p==='/events')eventTools(r);
    if(p==='/gallery')galleryTools(r);
    if(p==='/leadership')leadershipTools(r);
  }
  function tools(r){
    let el=r.querySelector('.mti-v177-tools');
    if(!el){el=document.createElement('div');el.className='mti-v177-tools';}
    return el;
  }
  function newsTools(r){
    const grid=r.querySelector('.grid3'); if(!grid)return;
    let t=r.querySelector('.mti-v177-tools');
    if(!t){t=document.createElement('div');t.className='mti-v177-tools';t.innerHTML='<input type="search" placeholder="Search news and announcements…" aria-label="Search news"> <span class="mti-v177-count"></span>';grid.parentNode.insertBefore(t,grid);}
    const input=t.querySelector('input'),count=t.querySelector('.mti-v177-count');
    if(input.dataset.bound)return; input.dataset.bound='1';
    const filter=()=>{const q=input.value.trim().toLowerCase();let n=0;grid.querySelectorAll('article').forEach(a=>{const ok=!q||a.textContent.toLowerCase().includes(q);a.style.display=ok?'':'none';if(ok)n++});if(count)count.textContent=n+' published item'+(n===1?'':'s')};
    input.addEventListener('input',filter);filter();
  }
  function eventTools(r){
    const list=r.querySelector('.events'); if(!list)return;
    let t=r.querySelector('.mti-v177-tools');
    if(!t){t=document.createElement('div');t.className='mti-v177-tools';t.innerHTML='<input type="search" placeholder="Search events, locations or activities…" aria-label="Search events"> <span class="mti-v177-count"></span>';list.parentNode.insertBefore(t,list);}
    const input=t.querySelector('input'),count=t.querySelector('.mti-v177-count');
    if(input.dataset.bound)return;input.dataset.bound='1';
    const filter=()=>{const q=input.value.trim().toLowerCase();let n=0;list.querySelectorAll('article').forEach(a=>{const ok=!q||a.textContent.toLowerCase().includes(q);a.style.display=ok?'':'none';if(ok)n++;let arrow=a.querySelector('.mti-v177-event-arrow');if(!arrow){arrow=document.createElement('span');arrow.className='mti-v177-event-arrow';arrow.textContent='›';a.appendChild(arrow)}});if(count)count.textContent=n+' event'+(n===1?'':'s')};
    input.addEventListener('input',filter);filter();
  }
  function galleryTools(r){
    const grid=r.querySelector('.gallery'); if(!grid)return;
    grid.querySelectorAll('.gallery-card').forEach((card,i)=>{card.style.setProperty('--mti-gallery-order',i)});
  }
  function leadershipTools(r){
    const grid=r.querySelector('.leadership-grid'); if(!grid)return;
    grid.querySelectorAll('.leader-card').forEach((card,i)=>{card.style.setProperty('--mti-leader-order',i)});
  }
  function start(){decorate();const obs=new MutationObserver(()=>{if(window.__mtiV177Busy)return;window.__mtiV177Busy=true;requestAnimationFrame(()=>{decorate();window.__mtiV177Busy=false})});obs.observe(root()||document.body,{childList:true,subtree:true});window.addEventListener('popstate',()=>setTimeout(decorate,30));}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
