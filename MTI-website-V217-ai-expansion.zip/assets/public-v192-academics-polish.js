/* MTI V192 — Programmes & Admissions motion */
(function(){'use strict';
function reveal(){
 var nodes=document.querySelectorAll('main section,main article,.v150-card,.programme-card,.admission-card,.programme-item');
 nodes.forEach(function(n,i){if(!n.classList.contains('mti192-reveal')){n.classList.add('mti192-reveal');n.style.animationDelay=Math.min(i*.055,.45)+'s';}});
 if(!('IntersectionObserver' in window)){nodes.forEach(function(n){n.classList.add('mti192-visible')});return;}
 var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('mti192-visible');io.unobserve(e.target)}})},{threshold:.08,rootMargin:'0px 0px -30px'});
 nodes.forEach(function(n){io.observe(n)});
}
function init(){reveal();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
new MutationObserver(function(){reveal()}).observe(document.body,{childList:true,subtree:true});
})();
