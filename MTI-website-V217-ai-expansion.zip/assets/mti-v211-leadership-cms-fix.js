/* MTI V211 — reliable leadership controls + CMS authentication */
(function(){
  'use strict';
  var path=(location.pathname||'/').replace(/\/+$/,'')||'/';

  function leadership(){
    if(path!=='/leadership') return;
    var root=document.querySelector('.leadership-grid');
    if(!root) return false;
    root.querySelectorAll('.leader-card').forEach(function(card){
      var bio=card.querySelector('.leader-bio');
      if(!bio || card.querySelector('.mti-v211-leader-toggle')) return;
      var paragraphs=bio.querySelectorAll('p');
      var text=(bio.textContent||'').trim();
      if(!text || text.length<180) return;
      var btn=document.createElement('button');
      btn.type='button';
      btn.className='mti-v211-leader-toggle mti-v185-leader-toggle';
      btn.textContent='Read more';
      btn.setAttribute('aria-expanded','false');
      btn.setAttribute('aria-label','Read the full biography');
      btn.addEventListener('click',function(){
        var open=card.classList.toggle('is-expanded');
        btn.textContent=open?'Close biography':'Read more';
        btn.setAttribute('aria-expanded',open?'true':'false');
        btn.setAttribute('aria-label',open?'Close biography':'Read the full biography');
        if(open) bio.setAttribute('tabindex','-1');
      });
      bio.insertAdjacentElement('afterend',btn);
    });
    return true;
  }

  if(path==='/leadership'){
    var tries=0;
    function scan(){
      if(leadership()) return;
      if(++tries<40) setTimeout(scan,150);
    }
    scan();
    var mo=new MutationObserver(function(){leadership();});
    mo.observe(document.getElementById('root')||document.body,{childList:true,subtree:true});
  }

  if(path!=='/admin' && path!=='/cms' && path!=='/content-management') return;

  var SUPABASE_URL='https://vjpwllvssblgpwckbiff.supabase.co';
  var SUPABASE_KEY='sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal';
  var STORE='sb-vjpwllvssblgpwckbiff-auth-token';

  function setStatus(form,text,error){
    var box=form.querySelector('.notice') || document.createElement('p');
    box.className='notice';
    box.setAttribute('role','status');
    if(!box.parentNode) form.appendChild(box);
    box.textContent=text;
    box.style.color=error?'#8b3027':'';
    box.style.borderLeftColor=error?'#8b3027':'';
  }
  function waitForForm(){
    var form=document.querySelector('form');
    if(!form || !/Admin email/i.test(document.body.textContent||'')) return;
    if(form.dataset.mti211AuthBound==='1') return;
    form.dataset.mti211AuthBound='1';
    document.addEventListener('submit',async function(e){
      if(e.target!==form || form.dataset.mti211Busy==='1') return;
      e.preventDefault();
      e.stopImmediatePropagation();
      var email=(form.querySelector('input[type="email"]')||{}).value||'';
      var password=(form.querySelector('input[type="password"]')||{}).value||'';
      var button=form.querySelector('button[type="submit"],button');
      if(!email.trim()||!password){setStatus(form,'Enter your administrator email and password.',true);return;}
      form.dataset.mti211Busy='1';
      if(button){button.disabled=true;button.textContent='Signing in…';}
      setStatus(form,'Connecting securely to MTI authentication…',false);
      var controller=new AbortController();
      var timer=setTimeout(function(){controller.abort();},15000);
      try{
        var response=await fetch(SUPABASE_URL+'/auth/v1/token?grant_type=password',{
          method:'POST',
          headers:{apikey:SUPABASE_KEY,'Content-Type':'application/json'},
          body:JSON.stringify({email:email.trim().toLowerCase(),password:password}),
          signal:controller.signal,
          cache:'no-store'
        });
        var data=await response.json().catch(function(){return {};});
        if(!response.ok || !data.access_token){
          throw new Error(data.error_description||data.msg||data.message||'Unable to sign in. Please check your administrator credentials.');
        }
        data.expires_at=data.expires_at||Math.floor(Date.now()/1000)+3600;
        localStorage.setItem(STORE,JSON.stringify(data));
        setStatus(form,'Sign-in successful. Opening MTI CMS…',false);
        setTimeout(function(){location.reload();},250);
      }catch(err){
        setStatus(form,err&&err.name==='AbortError'?'The authentication request timed out. Please check your connection and try again.':(err.message||'Unable to sign in.'),true);
        form.dataset.mti211Busy='0';
        if(button){button.disabled=false;button.textContent='Sign in';}
      }finally{clearTimeout(timer);}
    },true);
  }
  var ctries=0;
  function cmsScan(){waitForForm();if(++ctries<40)setTimeout(cmsScan,200);}
  cmsScan();
})();
