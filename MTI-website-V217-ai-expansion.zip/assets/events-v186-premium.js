/* MTI V186 — Events Premium Motion */
(function(){
  function enhance(){
    var root=document.querySelector('.events');
    if(!root) return;
    document.documentElement.classList.add('mti-events-route');
    var cards=root.querySelectorAll('article');
    cards.forEach(function(card,i){
      if(!card.querySelector('.mti-event-index')){
        var label=document.createElement('span');
        label.className='mti-event-index';
        label.textContent='MTI EVENT · '+String(i+1).padStart(2,'0');
        var title=card.querySelector('h3');
        if(title) title.parentNode.insertBefore(label,title);
      }
    });
    if(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches){cards.forEach(function(c){c.classList.add('is-visible')});return;}
    if(!('IntersectionObserver' in window)){cards.forEach(function(c){c.classList.add('is-visible')});return;}
    var io=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target)}})},{threshold:.12});
    cards.forEach(function(c){io.observe(c)});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',enhance); else enhance();
  var mo=new MutationObserver(function(){enhance()});
  mo.observe(document.body,{childList:true,subtree:true});
  setTimeout(function(){mo.disconnect()},8000);
})();
