(function(){'use strict';
  function init(){
    var path=window.location.pathname||'/';
    var isPortal=/^\/(student|lecturer|management|admin|portal|online-classroom|academic-|course-registration|result-|graduation-|transcript-|certificate-|student-|lecturer-|sug-executives-management)/.test(path);
    if(isPortal)return;
    document.documentElement.classList.add('mti-v201-public-meta');
    var title=document.title||'Methodist Theological Institute, Umuahia | MTI';
    var desc=document.querySelector('meta[name="description"]');
    if(desc && !desc.content)desc.content='Methodist Theological Institute, Umuahia — rooted in faith and growing in truth.';
    document.querySelectorAll('a[target="_blank"]').forEach(function(a){
      var rel=(a.getAttribute('rel')||'').split(/\s+/).filter(Boolean);
      ['noopener','noreferrer'].forEach(function(v){if(rel.indexOf(v)===-1)rel.push(v)});
      a.setAttribute('rel',rel.join(' '));
    });
    var live=document.createElement('span');
    live.className='mti-v201-share-preview';
    live.setAttribute('aria-hidden','true');
    live.textContent=title;
    document.body.appendChild(live);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
