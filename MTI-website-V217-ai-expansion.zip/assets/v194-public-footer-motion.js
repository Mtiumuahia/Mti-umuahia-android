/* MTI V194 — public footer motion, route-isolated */
(function(){'use strict';
  var PUBLIC_ROUTES=['/','/about','/governance','/visit','/leadership','/programmes','/admissions','/news','/events','/gallery','/sug-executives','/faq','/contact','/research','/library','/alumni','/campus','/student-life','/support'];
  function isPublic(){var p=(location.pathname||'/').replace(/\/$/,'')||'/';return PUBLIC_ROUTES.indexOf(p)!==-1;}
  function init(){
    if(!isPublic())return;
    document.documentElement.classList.add('mti59-public');
    var reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var io=null;
    if(!reduced&&'IntersectionObserver' in window){
      io=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-visible');io.unobserve(e.target);}})},{threshold:.08,rootMargin:'0px 0px -30px 0px'});
    }
    function enhance(){
      var nodes=document.querySelectorAll('footer, footer > *');
      nodes.forEach(function(el,i){
        if(!el.classList.contains('mti-v194-reveal')){el.classList.add('mti-v194-reveal');el.style.transitionDelay=Math.min((i%6)*55,275)+'ms';}
        if(reduced||!io)el.classList.add('is-visible');else if(!el.classList.contains('is-visible'))io.observe(el);
      });
    }
    enhance();
    var root=document.getElementById('root')||document.body;
    var timer;
    new MutationObserver(function(){clearTimeout(timer);timer=setTimeout(enhance,40)}).observe(root,{childList:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
