/* MTI V184 — Gallery media controls */
(function(){
  'use strict';
  if(location.pathname.replace(/\/$/,'') !== '/gallery') return;
  function mediaUrl(el){return el.currentSrc||el.src||el.getAttribute('data-src')||el.getAttribute('data-url')||'';}
  function label(el){return el.getAttribute('alt')||el.getAttribute('title')||'MTI Gallery media';}
  function download(url,name){if(!url)return;var a=document.createElement('a');a.href=url;a.download=name||'MTI-gallery-media';a.target='_blank';a.rel='noopener';document.body.appendChild(a);a.click();a.remove();}
  function addLightbox(){
    if(document.querySelector('.gallery-v184-lightbox')) return;
    var box=document.createElement('div');box.className='gallery-v184-lightbox';box.setAttribute('aria-hidden','true');
    box.innerHTML='<div class="gallery-v184-lightbox-inner"><button class="gallery-v184-close" type="button" aria-label="Close">×</button><div class="gallery-v184-stage"></div><div class="gallery-v184-caption"></div></div>';
    document.body.appendChild(box);
    var stage=box.querySelector('.gallery-v184-stage');
    var cap=box.querySelector('.gallery-v184-caption');
    function close(){box.classList.remove('is-open');box.setAttribute('aria-hidden','true');stage.innerHTML='';document.body.style.overflow='';}
    box.querySelector('.gallery-v184-close').addEventListener('click',close);
    box.addEventListener('click',function(e){if(e.target===box)close();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')close();});
    window.__mtiGalleryOpen=function(src,type,text){
      stage.innerHTML='';var node;
      if(type==='video'){node=document.createElement('video');node.src=src;node.controls=true;node.autoplay=true;node.playsInline=true;}
      else {node=document.createElement('img');node.src=src;node.alt=text||'MTI Gallery';}
      stage.appendChild(node);cap.textContent=text||'';box.classList.add('is-open');box.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';
    };
  }
  function enhance(){
    addLightbox();
    var root=document.querySelector('#root');if(!root)return;
    var media=[].slice.call(root.querySelectorAll('img,video')).filter(function(el){return !el.closest('.gallery-v184-lightbox') && mediaUrl(el);});
    media.forEach(function(el){
      if(el.dataset.v184Enhanced==='1')return;el.dataset.v184Enhanced='1';
      var url=mediaUrl(el), text=label(el), type=el.tagName.toLowerCase()==='video'?'video':'image';
      var wrap=el.parentElement;
      if(wrap && !wrap.classList.contains('gallery-v184-media-wrap')){wrap.classList.add('gallery-v184-media-wrap');}
      var host=wrap||el.parentElement;if(!host)return;
      var actions=document.createElement('div');actions.className='gallery-v184-actions';
      var open=document.createElement('button');open.type='button';open.className='gallery-v184-open';open.textContent=type==='video'?'▶ Watch':'↗ View';open.addEventListener('click',function(){window.__mtiGalleryOpen(url,type,text);});
      var dl=document.createElement('button');dl.type='button';dl.className='gallery-v184-download';dl.textContent='↓ Download';dl.addEventListener('click',function(){download(url,'MTI-gallery-'+(type==='video'?'video':'image'));});
      actions.append(open,dl);host.appendChild(actions);
    });
  }
  var observer=new MutationObserver(function(){enhance();});
  document.addEventListener('DOMContentLoaded',function(){enhance();observer.observe(document.querySelector('#root')||document.body,{childList:true,subtree:true});});
})();
