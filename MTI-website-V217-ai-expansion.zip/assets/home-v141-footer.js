/* MTI V141 — Exact homepage footer hierarchy */
(function(){
  'use strict';
  if(location.pathname!=='/'&&location.pathname!=='')return;
  var processed=null;
  function run(){
    var footer=document.querySelector('footer');
    if(!footer||footer===processed)return;
    footer.querySelectorAll('a').forEach(function(a){var t=(a.textContent||'').trim().toLowerCase();if(t==='contact'||t==='gallery')a.remove();});
    footer.querySelectorAll('.mti-v136-footer-brand,.mti-v136-quick-links,.mti-v140-footer-meta,.mti-v141-footer-meta').forEach(function(x){x.remove();});
    footer.querySelectorAll(':scope > div').forEach(function(x){var t=(x.textContent||'').replace(/\s+/g,' ').trim().toLowerCase();if(t.indexOf('methodist theological institute, umuahia')!==-1 && t.indexOf('all rights reserved')!==-1)x.remove();});
    var meta=document.createElement('div');
    meta.className='mti-v141-footer-meta';
    meta.innerHTML='<div class="mti-v141-quick"><span>QUICK LINKS</span><div class="mti-v141-links"><a href="/">Home</a><a href="/programmes">Programmes</a><a href="/admissions">Admissions</a><a href="/leadership">Leadership</a><a href="/library">Digital Library</a><a href="/student-portal">Student Portal</a><a href="/lecturer-portal">Lecturer Portal</a><a href="/online-classroom">Online Classroom</a></div></div><div class="mti-v141-institute">Methodist Theological Institute, Umuahia</div><div class="mti-v141-copy">© 2026 MTI Umuahia. All rights reserved.</div><div class="mti-v141-developed">Developed by <strong>GOD\'SLOVE DIGITAL CONCEPT</strong></div>';
    footer.appendChild(meta);
    processed=footer;
  }
  run();
  new MutationObserver(run).observe(document.body,{childList:true,subtree:true});
})();
