(function(){
  var root=document.documentElement;
  if(!root.classList.contains('mti-v151-institutional')) return;
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce) return;
  var items=document.querySelectorAll('.content > *, .timeline article, .about-panel, .leader-card, .visit-card, .governance-card, .policy-card');
  items.forEach(function(el,i){el.style.opacity='0';el.style.transform='translateY(18px)';el.style.transition='opacity .65s ease '+Math.min(i*35,350)+'ms, transform .65s ease '+Math.min(i*35,350)+'ms';});
  var reveal=function(el){el.style.opacity='1';el.style.transform='none';};
  if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){reveal(e.target);io.unobserve(e.target);}})},{threshold:.08});items.forEach(function(el){io.observe(el);});}
  else items.forEach(reveal);
})();
