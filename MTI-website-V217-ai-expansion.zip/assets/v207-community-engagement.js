/* MTI V207 — unified public communication and support actions */
(function(){
  'use strict';
  var FACEBOOK_URL='https://www.facebook.com/profile.php?id=61550301347674';
  var TECHNICAL_EMAIL='godslovedigitalconcerpts@gmail.com';
  var PUBLIC_ROUTES=['/','/about','/governance','/visit','/leadership','/programmes','/admissions','/news','/events','/gallery','/sug-executives','/faq','/contact','/research','/library','/alumni','/campus','/student-life','/support'];
  function isPublic(){var p=(location.pathname||'/').replace(/\/$/,'')||'/';return PUBLIC_ROUTES.indexOf(p)!==-1;}
  function button(text,href,extra){var a=document.createElement('a');a.className='mti-v207-action '+(extra||'');a.href=href;a.textContent=text;if(/^https:\/\//.test(href)){a.target='_blank';a.rel='noopener noreferrer';}return a;}
  function build(){
    if(!isPublic())return;
    document.querySelectorAll('.mti-v203-engagement,.mti-v204-engagement,.mti-v205-help').forEach(function(x){x.remove();});
    var footer=document.querySelector('footer');
    if(footer&&!footer.querySelector('.mti-v207-engagement')){var wrap=document.createElement('div');wrap.className='mti-v207-engagement';wrap.appendChild(button('Click here to visit our Facebook page',FACEBOOK_URL,'mti-v207-facebook'));wrap.appendChild(button('Click here for technical complaints','mailto:'+TECHNICAL_EMAIL,'mti-v207-support'));footer.appendChild(wrap);}
    var band=document.querySelector('.contact-band');
    if(band&&!band.querySelector('.mti-v207-engagement')){var actions=band.querySelector('.contact-actions')||band;var wrap2=document.createElement('div');wrap2.className='mti-v207-engagement';wrap2.appendChild(button('Click here to visit our Facebook page',FACEBOOK_URL,'mti-v207-facebook'));wrap2.appendChild(button('Click here for technical complaints','mailto:'+TECHNICAL_EMAIL,'mti-v207-support'));actions.appendChild(wrap2);}
  }
  function init(){build();new MutationObserver(build).observe(document.body,{childList:true,subtree:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
