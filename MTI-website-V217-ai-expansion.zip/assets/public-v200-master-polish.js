/* MTI V200 — Public Master Polish */
(function(){'use strict';
  var p=location.pathname.replace(/\/$/,'')||'/';
  var excluded=/^(\/student-portal|\/lecturer-portal|\/applicant-portal|\/management-dashboard|\/academic-administration|\/admissions-administration|\/student-onboarding|\/student-registry|\/course-registration|\/teaching-load-management|\/lecturer-gradebook|\/result-review|\/academic-clearance|\/graduation-candidates|\/graduation-register|\/graduation-certificates|\/certificate-verification|\/graduation-clearance|\/transcript-records|\/transcript-verification|\/official-transcript|\/student-activation|\/application-status|\/apply-now|\/online-classroom|\/online-learning|\/sug-executives-management)(\/|$)/.test(p);
  if(excluded)return;
  document.documentElement.classList.add('mti-v200-public');
  function init(){
    var main=document.querySelector('main');
    if(main&&!main.id)main.id='main-content';
    if(!document.querySelector('.mti-v200-skip')){
      var a=document.createElement('a');a.className='mti-v200-skip';a.href=main&&main.id?'#'+main.id:'#main-content';a.textContent='Skip to main content';document.body.prepend(a);
    }
    document.querySelectorAll('a[target="_blank"]').forEach(function(a){
      var rel=(a.getAttribute('rel')||'').split(/\s+/).filter(Boolean);
      if(rel.indexOf('noopener')<0)rel.push('noopener');
      if(rel.indexOf('noreferrer')<0)rel.push('noreferrer');
      a.setAttribute('rel',rel.join(' '));
    });
    document.querySelectorAll('img').forEach(function(img,i){
      if(i>1 && !img.getAttribute('loading'))img.setAttribute('loading','lazy');
      if(!img.getAttribute('decoding'))img.setAttribute('decoding','async');
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
