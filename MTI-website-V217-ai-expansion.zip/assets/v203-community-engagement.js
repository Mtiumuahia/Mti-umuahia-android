/* MTI V203 — Community engagement buttons
 * Adds Facebook engagement and technical-complaint actions without exposing
 * the underlying Facebook URL or technical email address in visible copy.
 */
(function(){
  'use strict';
  var FACEBOOK_URL='https://www.facebook.com/search/top?q=Methodist%20Theological%20Institute%20Umuahia';
  var TECHNICAL_EMAIL='godslovedigitalconcerpts@gmail.com';

  function button(text,href,extra){
    var a=document.createElement('a');
    a.className='mti-v203-action '+(extra||'');
    a.href=href;
    a.textContent=text;
    if(/^https:\/\//.test(href)){
      a.target='_blank';
      a.rel='noopener noreferrer';
    }
    return a;
  }

  function addToFooter(){
    var footer=document.querySelector('footer');
    if(!footer || footer.querySelector('.mti-v203-engagement')) return;
    var wrap=document.createElement('div');
    wrap.className='mti-v203-engagement';
    wrap.appendChild(button('Click here to visit our Facebook page',FACEBOOK_URL,'mti-v203-facebook'));
    wrap.appendChild(button('Click here for technical support','mailto:'+TECHNICAL_EMAIL,'mti-v203-support'));
    footer.appendChild(wrap);
  }

  function addToContact(){
    var band=document.querySelector('.contact-band');
    if(!band || band.querySelector('.mti-v203-engagement')) return;
    var actions=band.querySelector('.contact-actions') || band;
    var wrap=document.createElement('div');
    wrap.className='mti-v203-engagement';
    wrap.appendChild(button('Click here to visit our Facebook page',FACEBOOK_URL,'mti-v203-facebook'));
    wrap.appendChild(button('Click here for technical complaints','mailto:'+TECHNICAL_EMAIL,'mti-v203-support'));
    actions.appendChild(wrap);
  }

  function run(){ addToFooter(); addToContact(); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',run); else run();
  new MutationObserver(run).observe(document.body,{childList:true,subtree:true});
})();
