/* MTI V142 — student portal session protection */
(function(){
  'use strict';

  if(location.pathname.replace(/\/$/,'')!=='/student-portal') return;

  var KEY='sb-vjpwllvssblgpwckbiff-auth-token';
  var EXIT='mti_v142_student_last_exit';
  var MAX=60000;
  var FIRST='mti_v142_student_initial_login_reset';

  function read(){
    try{return JSON.parse(localStorage.getItem(KEY)||'null');}
    catch(e){return null;}
  }

  function clearToken(callServer){
    var raw=read();
    if(callServer && raw && raw.access_token){
      fetch('https://vjpwllvssblgpwckbiff.supabase.co/auth/v1/logout',{
        method:'POST',
        headers:{
          apikey:'sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal',
          Authorization:'Bearer '+raw.access_token
        },
        keepalive:true
      }).catch(function(){});
    }
    localStorage.removeItem(KEY);
    sessionStorage.clear();
  }

  /* Every fresh load of the Student Portal starts with a clean login. */
  clearToken(true);

  var lastExit=Number(localStorage.getItem(EXIT)||0);
  if(lastExit && Date.now()-lastExit>=MAX){
    clearToken(true);
  }

  function rememberExit(){
    localStorage.setItem(EXIT,String(Date.now()));
  }

  function forgetExit(){
    localStorage.removeItem(EXIT);
  }

  document.addEventListener('visibilitychange',function(){
    if(document.visibilityState==='hidden'){
      rememberExit();
      return;
    }
    var t=Number(localStorage.getItem(EXIT)||0);
    if(t && Date.now()-t>=MAX){
      clearToken(true);
      location.reload();
    }else{
      forgetExit();
    }
  });

  window.addEventListener('pagehide',rememberExit);
  window.addEventListener('pageshow',function(){
    var t=Number(localStorage.getItem(EXIT)||0);
    if(t && Date.now()-t>=MAX){
      clearToken(false);
      location.reload();
    }
  });
})();
