/* MTI V204 — Community engagement and technical support
 * Adds Facebook engagement and technical-complaint actions without exposing
 * the underlying Facebook URL or technical email address in visible copy.
 */
(function(){
  'use strict';
  var FACEBOOK_URL='https://www.facebook.com/profile.php?id=61550301347674';
  var TECHNICAL_EMAIL='godslovedigitalconcerpts@gmail.com';

  function button(text,href,extra){
    var a=document.createElement('a');
    a.className='mti-v204-action '+(extra||'');
    a.href=href;
    a.textContent=text;
    if(/^https:\/\//.test(href)){
      a.target='_blank';
      a.rel='noopener noreferrer';
    }
    return a;
  }

  function addToFooter(){
    var footer=document.querySelector('footer');
    if(!footer || footer.querySelector('.mti-v204-engagement')) return;
    var wrap=document.createElement('div');
    wrap.className='mti-v204-engagement';
    wrap.appendChild(button('Click here to visit our Facebook page',FACEBOOK_URL,'mti-v204-facebook'));
    wrap.appendChild(button('Click here for technical complaints','mailto:'+TECHNICAL_EMAIL,'mti-v204-support'));
    footer.appendChild(wrap);
  }

  function addToContact(){
    var band=document.querySelector('.contact-band');
    if(!band || band.querySelector('.mti-v204-engagement')) return;
    var actions=band.querySelector('.contact-actions') || band;
    var wrap=document.createElement('div');
    wrap.className='mti-v204-engagement';
    wrap.appendChild(button('Click here to visit our Facebook page',FACEBOOK_URL,'mti-v204-facebook'));
    wrap.appendChild(button('Click here for technical complaints','mailto:'+TECHNICAL_EMAIL,'mti-v204-support'));
    actions.appendChild(wrap);
  }

  function run(){ addToFooter(); addToContact(); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',run); else run();
  new MutationObserver(run).observe(document.body,{childList:true,subtree:true});
})();
