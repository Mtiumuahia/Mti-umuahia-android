/* MTI V138 — lightweight site-wide motion controller */
(function(){'use strict';
  function mark(root){
    if(!root)return;
    var selectors=['.v81-content > *','.v82-content > *','.mti-online-wrap > *','main > section','body > #root > *'];
    selectors.forEach(function(sel){root.querySelectorAll(sel).forEach(function(el,i){
      if(el.dataset.mti138Motion)return;
      el.dataset.mti138Motion='1';
      el.classList.add('mti-v138-enter');
      el.style.animationDelay=Math.min(i*55,330)+'ms';
    });});
  }
  function start(){var root=document.getElementById('root')||document.body;mark(document);var mo=new MutationObserver(function(){mark(document)});mo.observe(root,{childList:true,subtree:true});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
