(function(){
  function init(){
    if(location.pathname!=='/'&&location.pathname!=='') return;
    var root=document.querySelector('#root'); if(!root) return;
    function decorate(){
      root.querySelectorAll('section, article, .card, [class*="news"], [class*="event"], [class*="gallery"], [class*="programme"]').forEach(function(el){
        if(el.dataset.mti188) return;
        el.dataset.mti188='1'; el.classList.add('mti188-reveal');
        if(el.matches('article,.card,[class*="news"],[class*="event"],[class*="gallery"],[class*="programme"]')) el.classList.add('mti188-soft-hover');
        observer.observe(el);
      });
    }
    var observer=new IntersectionObserver(function(entries){entries.forEach(function(e){if(e.isIntersecting){e.target.classList.add('is-visible');observer.unobserve(e.target)}})},{threshold:.08});
    init=undefined; decorate();
    new MutationObserver(decorate).observe(root,{childList:true,subtree:true});
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else setTimeout(init,60);
})();
