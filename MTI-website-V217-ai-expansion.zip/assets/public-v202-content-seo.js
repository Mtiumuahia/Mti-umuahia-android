(function(){'use strict';
  var path=(location.pathname||'/').replace(/\/$/,'')||'/';
  var publicRoutes=['','/news','/events','/gallery','/leadership','/about','/governance','/visit','/programmes','/admissions','/sug-executives'];
  var isNews=path==='/news'||path.indexOf('/news/')===0;
  var isEvents=path==='/events'||path.indexOf('/events/')===0;
  var isPublic=publicRoutes.indexOf(path)>=0||isNews||isEvents;
  if(!isPublic)return;
  document.documentElement.classList.add('mti-v202-public');

  var base='https://mtiumuahia.org';
  var configs={
    '/':{title:'Methodist Theological Institute, Umuahia | MTI',desc:'Explore Methodist Theological Institute, Umuahia — programmes, admissions, leadership, news, events, gallery and student life.'},
    '/news':{title:'News & Announcements | MTI Umuahia',desc:'Latest news, announcements, stories and institutional updates from Methodist Theological Institute, Umuahia.'},
    '/events':{title:'Events & Activities | MTI Umuahia',desc:'Upcoming and recent events, academic activities, worship gatherings and institutional programmes at MTI Umuahia.'},
    '/gallery':{title:'Gallery | MTI Umuahia',desc:'Explore photographs and media from life, worship, learning, events and community at MTI Umuahia.'},
    '/leadership':{title:'Leadership | MTI Umuahia',desc:'Meet the leadership of Methodist Theological Institute, Umuahia and learn about institutional responsibilities.'},
    '/about':{title:'About MTI Umuahia | Methodist Theological Institute',desc:'Learn about the Methodist Theological Institute, Umuahia, its mission, formation and theological education.'},
    '/governance':{title:'Governance | MTI Umuahia',desc:'Institutional governance, structure, accountability and official information from MTI Umuahia.'},
    '/programmes':{title:'Programmes | MTI Umuahia',desc:'Explore theological education and academic programmes available through Methodist Theological Institute, Umuahia.'},
    '/admissions':{title:'Admissions | MTI Umuahia',desc:'Admission information, requirements and the application journey for Methodist Theological Institute, Umuahia.'},
    '/sug-executives':{title:'SUG Executives | MTI Umuahia',desc:'Meet the Students Union Government executives of Methodist Theological Institute, Umuahia.'}
  };

  function ensure(name,attrs){var el=document.head.querySelector('meta['+name+'="'+attrs[name]+'"]');return el}
  function setMeta(key,val,prop){
    var selector=prop?'meta[property="'+key+'"]':'meta[name="'+key+'"]';
    var el=document.head.querySelector(selector);
    if(!el){el=document.createElement('meta');if(prop)el.setAttribute('property',key);else el.setAttribute('name',key);document.head.appendChild(el)}
    el.setAttribute('content',val||'');
  }
  function setLink(rel,href){var el=document.head.querySelector('link[rel="'+rel+'"]');if(!el){el=document.createElement('link');el.rel=rel;document.head.appendChild(el)}el.href=href}
  function clean(t){return (t||'').replace(/\s+/g,' ').trim()}
  function firstText(sel){var e=document.querySelector(sel);return e?clean(e.textContent):''}
  function getImage(){var img=document.querySelector('main img');return img&&img.src?img.src:(base+'/assets/mti-logo.png')}
  function apply(kind){
    var cfg=configs[path]||{};
    var heading=firstText('main h1')||firstText('main h2');
    var title=cfg.title||clean(document.title)||'MTI Umuahia';
    var desc=cfg.desc||clean(firstText('main p')).slice(0,155);
    var article=(kind==='news'||kind==='event') && path!=='/news' && path!=='/events';
    if(article&&heading){title=heading+' | MTI Umuahia';var p=firstText('main p');if(p)desc=p.slice(0,155)}
    document.title=title;
    setMeta('description',desc);
    setMeta('og:title',title,true);setMeta('og:description',desc,true);setMeta('og:type',article?'article':'website',true);setMeta('og:url',location.href.split('#')[0],true);setMeta('og:image',getImage(),true);
    setMeta('twitter:card','summary_large_image');setMeta('twitter:title',title);setMeta('twitter:description',desc);setMeta('twitter:image',getImage());
    setLink('canonical',location.href.split('#')[0]);
    var old=document.getElementById('mti-v202-jsonld');if(old)old.remove();
    var data={};
    if(kind==='news'&&article){data={'@context':'https://schema.org','@type':'NewsArticle','headline':heading||title,'description':desc,'url':location.href.split('#')[0],'image':[getImage()],'publisher':{'@type':'Organization','name':'Methodist Theological Institute, Umuahia'}}}
    else if(kind==='event'&&article){data={'@context':'https://schema.org','@type':'Event','name':heading||title,'description':desc,'url':location.href.split('#')[0],'image':getImage(),'organizer':{'@type':'Organization','name':'Methodist Theological Institute, Umuahia'}}}
    else {data={'@context':'https://schema.org','@type':'WebPage','name':title,'description':desc,'url':location.href.split('#')[0],'isPartOf':{'@type':'WebSite','name':'MTI Umuahia'}}}
    var script=document.createElement('script');script.id='mti-v202-jsonld';script.type='application/ld+json';script.textContent=JSON.stringify(data);document.head.appendChild(script);
    addShare(article);
  }
  function addShare(article){
    if(!article)return;
    var main=document.querySelector('main');if(!main||main.querySelector('.mti-v202-share'))return;
    var target=main.querySelector('article')||main.querySelector('section');if(!target)return;
    var box=document.createElement('div');box.className='mti-v202-share';box.setAttribute('aria-label','Share this page');
    var b=document.createElement('button');b.type='button';b.textContent='Share this page';
    var copy=document.createElement('button');copy.type='button';copy.textContent='Copy link';
    var status=document.createElement('span');status.className='mti-v202-share-status';status.setAttribute('aria-live','polite');
    b.onclick=function(){if(navigator.share){navigator.share({title:document.title,text:document.title,url:location.href}).catch(function(){})}else{copyLink()}};
    copy.onclick=copyLink;
    function copyLink(){if(navigator.clipboard){navigator.clipboard.writeText(location.href).then(function(){status.textContent='Link copied.'},function(){status.textContent='Copy unavailable.'})}else{status.textContent='Copy unavailable.'}}
    box.appendChild(b);box.appendChild(copy);box.appendChild(status);target.insertBefore(box,target.firstChild);
  }
  function run(){apply(isNews?'news':isEvents?'event':'page')}
  var tries=0;function boot(){run();if(tries++<8){setTimeout(boot,500)}}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
})();
