(function(){
  const path=()=>location.pathname.replace(/\/$/,'')||'/';
  function pageClass(){
    const p=path();
    const publicRoutes=['/','/about','/governance','/visit','/leadership','/programmes','/admissions','/news','/events','/gallery','/sug-executives','/faq','/contact','/research','/library','/alumni','/campus','/student-life','/support'];
    if(publicRoutes.indexOf(p)===-1)return false;
    document.documentElement.classList.add('mti-v175-public');
    document.documentElement.classList.remove('mti-v175-home','mti-v175-news','mti-v175-events','mti-v175-gallery','mti-v175-leadership');
    if(p==='/') document.documentElement.classList.add('mti-v175-home');
    if(p==='/news') document.documentElement.classList.add('mti-v175-news');
    if(p==='/events') document.documentElement.classList.add('mti-v175-events');
    if(p==='/gallery') document.documentElement.classList.add('mti-v175-gallery');
    if(p==='/leadership') document.documentElement.classList.add('mti-v175-leadership');
    return true;
  }
  function enhance(){
    if(!pageClass())return;
    const root=document.getElementById('root'); if(!root)return;
    root.querySelectorAll('img').forEach(img=>{img.loading='lazy';img.decoding='async'});
    root.querySelectorAll('a[href^="/"]').forEach(a=>{a.addEventListener('click',()=>{document.documentElement.classList.add('mti-v175-navigating')},{passive:true})});
  }
  function start(){
    enhance();
    const obs=new MutationObserver(()=>enhance());
    obs.observe(document.getElementById('root')||document.body,{childList:true,subtree:true});
    window.addEventListener('popstate',enhance);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
