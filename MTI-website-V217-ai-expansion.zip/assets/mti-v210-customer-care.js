/* MTI V210 — Customer Care floating assistant. Public routes only; no backend required. */
(function(){
  'use strict';
  var path=(location.pathname||'/').replace(/\/+$/,'')||'/';
  var excluded=[
    '/student-portal','/lecturer-portal','/applicant-portal','/management-dashboard','/academic-administration',
    '/admissions-administration','/student-onboarding','/student-registry','/course-registration','/teaching-load-management',
    '/lecturer-gradebook','/result-review','/academic-clearance','/graduation-candidates','/graduation-register',
    '/graduation-certificates','/certificate-verification','/graduation-clearance','/transcript-records','/transcript-verification',
    '/official-transcript','/student-results','/lecturer-result-entry','/academic-session-control','/academic-timetable',
    '/sug-executives-management','/application-status','/student-activation','/online-classroom','/online-learning',
    '/cms','/content-management','/management','/admin'
  ];
  if(excluded.indexOf(path)!==-1 || document.querySelector('[data-mti210-chat]')) return;

  var root=document.createElement('div');
  root.className='mti210-chat'; root.setAttribute('data-mti210-chat','');
  root.innerHTML=''+
    '<div class="mti210-panel" role="dialog" aria-modal="false" aria-label="MTI Customer Care" aria-hidden="true">'+
      '<div class="mti210-head">'+
        '<div class="mti210-brand">'+
          '<div class="mti210-avatar"><img src="/assets/mti-logo.png" alt="MTI logo"></div>'+ 
          '<div class="mti210-head-copy"><p class="mti210-head-title">MTI Customer Care</p><p class="mti210-status">How may we help you today?</p></div>'+ 
        '</div>'+ 
        '<button class="mti210-close" type="button" aria-label="Close customer care chat">×</button>'+ 
      '</div>'+ 
      '<div class="mti210-messages" aria-live="polite"></div>'+ 
      '<div class="mti210-quick-wrap"><p class="mti210-quick-title">Quick help</p><div class="mti210-quicks"></div></div>'+ 
      '<div class="mti210-actions">'+
        '<a class="mti210-link" href="/apply-now">Admissions</a>'+ 
        '<a class="mti210-link" href="/visit">Visit MTI</a>'+ 
        '<a class="mti210-link" href="mailto:godslovedigitalconcerpts@gmail.com?subject=MTI%20Technical%20Complaint">Technical support</a>'+ 
      '</div>'+ 
      '<form class="mti210-composer"><input class="mti210-input" aria-label="Ask MTI Customer Care" autocomplete="off" placeholder="Type your question…"><button class="mti210-send" type="submit" aria-label="Send message">➤</button></form>'+ 
    '</div>'+ 
    '<button class="mti210-launch" type="button" aria-expanded="false" aria-controls="mti210-panel" aria-label="Open MTI Customer Care">'+
      '<span class="mti210-launch-icon" aria-hidden="true">✦</span><span class="mti210-launch-text">Customer Care</span>'+ 
    '</button>';
  document.body.appendChild(root);
  var panel=root.querySelector('.mti210-panel'); panel.id='mti210-panel';
  var launch=root.querySelector('.mti210-launch'), close=root.querySelector('.mti210-close'), messages=root.querySelector('.mti210-messages'), quicks=root.querySelector('.mti210-quicks'), form=root.querySelector('.mti210-composer'), input=root.querySelector('.mti210-input');

  var data=[
    {label:'Admissions',q:'How do I apply?',a:'When MTI admissions are officially open, you can submit the online application through the Admissions page. You do not create a Student Portal password at the application stage. After the selection process, admitted students receive their MTI registration number and one-time activation code.'},
    {label:'Application status',q:'How can I check my application status?',a:'Use the Application Status page to check the status of an application submitted to MTI. Keep the details used during your application available.'},
    {label:'Student Portal',q:'How do I access the Student Portal?',a:'Student Portal access is for admitted students. An admitted student uses the MTI registration number and one-time activation code supplied by MTI, then creates a password.'},
    {label:'Programmes',q:'What programmes does MTI offer?',a:'Please open the Programmes page for the Institute’s current programme and affiliation information. MTI programme information is maintained there as the official public reference.'},
    {label:'Visit MTI',q:'How can I visit MTI?',a:'Open Visit MTI for information about visiting the Institute, planning your next step and contacting the Institute.'},
    {label:'Hostel',q:'How does hostel allocation work?',a:'The hostel fee is ₦5,000. After payment, print your receipt and report to the MTI Chief of Staff office for hostel allocation.'},
    {label:'Technical help',q:'I found a technical problem.',a:'For a website or technical complaint, use the Technical support button below. It opens a support email without displaying the email address publicly.'}
  ];

  function addMessage(text,who){
    var row=document.createElement('div'); row.className='mti210-msg '+who;
    var bubble=document.createElement('div'); bubble.className='mti210-bubble'; bubble.textContent=text;
    row.appendChild(bubble); messages.appendChild(row); messages.scrollTop=messages.scrollHeight;
  }
  function answer(item){addMessage(item.q,'user'); setTimeout(function(){addMessage(item.a,'bot');},120);}
  function findAnswer(q){
    var s=q.toLowerCase();
    if(/admission|apply|application/.test(s)) return data[0];
    if(/status|track/.test(s)) return data[1];
    if(/student portal|portal|activation|password/.test(s)) return data[2];
    if(/programme|program|course|degree/.test(s)) return data[3];
    if(/visit|location|where.*mti|campus/.test(s)) return data[4];
    if(/hostel|accommodation/.test(s)) return data[5];
    if(/technical|bug|error|problem|not working|broken/.test(s)) return data[6];
    return {q:q,a:'I can help with admissions, application status, Student Portal access, programmes, visiting MTI, hostel information or technical support. Please choose one of the quick-help options below.'};
  }
  data.forEach(function(item){var b=document.createElement('button');b.type='button';b.className='mti210-quick';b.textContent=item.label;b.addEventListener('click',function(){answer(item);});quicks.appendChild(b);});
  addMessage('Welcome to MTI Customer Care. I can help you find information about admissions, portals, programmes, visiting MTI and common support questions. What would you like to know?','bot');
  function open(){root.classList.add('is-open');launch.setAttribute('aria-expanded','true');panel.setAttribute('aria-hidden','false');setTimeout(function(){input.focus();},50);}
  function shut(){root.classList.remove('is-open');launch.setAttribute('aria-expanded','false');panel.setAttribute('aria-hidden','true');launch.focus();}
  launch.addEventListener('click',function(){root.classList.contains('is-open')?shut():open();}); close.addEventListener('click',shut);
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&root.classList.contains('is-open')) shut();});
  form.addEventListener('submit',function(e){e.preventDefault();var q=input.value.trim();if(!q)return;var item=findAnswer(q);answer(item);input.value='';});
})();
