(function(){'use strict';
 function init(){
  var path=location.pathname.replace(/\/$/,'');
  var pub=['','/news','/events','/gallery','/leadership','/about','/governance','/visit','/programmes','/admissions','/sug-executives','/sug-executives-management'].indexOf(path)>=0;
  if(!pub)return;
  document.documentElement.classList.add('mti-v197-qa');
  document.querySelectorAll('a[href="#"]').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault()},{passive:false})});
  document.querySelectorAll('img').forEach(function(img){if(!img.hasAttribute('decoding'))img.setAttribute('decoding','async');});
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
