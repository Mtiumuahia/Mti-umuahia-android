/* MTI V178 — public storytelling motion */
(function(){
  'use strict';
  var reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var publicRoutes=['/','/about','/governance','/visit','/leadership','/programmes','/admissions','/news','/events','/gallery','/sug-executives','/faq','/contact','/research','/library','/alumni','/campus','/student-life','/support'];
  var path=(location.pathname||'/').replace(/\/$/,'')||'/';
  if(publicRoutes.indexOf(path)===-1)return;
  document.documentElement.classList.add('mti-public-page');
  function reveal(){
    var els=document.querySelectorAll('main section,main article,.news-card,.event-card,.gallery-card,.leadership-card,.programme-card,.story-card,.content-card');
    if(!els.length)return;
    if(reduced){els.forEach(function(e){e.style.opacity='1';e.style.transform='none';});return;}
    els.forEach(function(e,i){if(e.dataset.mti178)return;e.dataset.mti178='1';e.style.opacity='0';e.style.transform='translateY(18px)';e.style.transition='opacity .65s ease '+Math.min(i*35,280)+'ms,transform .65s cubic-bezier(.22,.8,.25,1) '+Math.min(i*35,280)+'ms';});
    if(!('IntersectionObserver' in window)){els.forEach(function(e){e.style.opacity='1';e.style.transform='none';});return;}
    var io=new IntersectionObserver(function(entries){entries.forEach(function(x){if(x.isIntersecting){x.target.style.opacity='1';x.target.style.transform='none';io.unobserve(x.target);}})},{threshold:.08,rootMargin:'0px 0px -40px'});
    els.forEach(function(e){io.observe(e);});
  }
  function pageClass(){document.documentElement.classList.add('mti-public-page');document.body.classList.add('mti-public-page');}
  pageClass(); reveal();
  var mo=new MutationObserver(function(){reveal();});
  mo.observe(document.body,{childList:true,subtree:true});
  window.addEventListener('load',reveal,{once:true});
})();
