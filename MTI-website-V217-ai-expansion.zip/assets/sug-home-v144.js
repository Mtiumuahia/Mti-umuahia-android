/* MTI V144 — resilient SUG public homepage showcase */
(function(){
  'use strict';
  if(location.pathname!=='/' && location.pathname!=='') return;

  var U='https://vjpwllvssblgpwckbiff.supabase.co';
  var K='sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal';
  var mounted=false;

  function esc(v){
    return String(v==null?'':v).replace(/[&<>"']/g,function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function photo(x){
    return x.photo_url||'/assets/mti-logo.png';
  }

  async function load(){
    try{
      var r=await fetch(
        U+'/rest/v1/sug_executives_v142?select=id,full_name,office,biography,photo_url,display_order&active=eq.true&order=display_order.asc,full_name.asc&limit=6',
        {headers:{apikey:K,Accept:'application/json'}}
      );
      if(!r.ok)return [];
      return await r.json();
    }catch(e){
      return [];
    }
  }

  function mount(rows){
    if(mounted || !rows.length)return true;

    var root=document.getElementById('root');
    if(!root)return false;

    var footer=root.querySelector('footer');
    if(!footer)return false;

    if(root.querySelector('.mti-v143-sug-showcase')){
      mounted=true;
      return true;
    }

    var section=document.createElement('section');
    section.className='mti-v143-sug-showcase';
    section.innerHTML=
      '<div class="mti-v143-sug-inner">'+
        '<div class="mti-v143-sug-head">'+
          '<div>'+
            '<span>STUDENTS’ UNION GOVERNMENT</span>'+
            '<h2>Student leadership at MTI</h2>'+
            '<p>Meet the elected SUG executives serving the student community of the Methodist Theological Institute, Umuahia.</p>'+
          '</div>'+
          '<a href="/sug-executives">View SUG directory <b>→</b></a>'+
        '</div>'+
        '<div class="mti-v143-sug-grid">'+
          rows.map(function(x,i){
            return '<article class="mti-v143-sug-card" style="--i:'+i+'">'+
              '<div class="mti-v143-sug-photo"><img src="'+esc(photo(x))+'" alt="'+esc(x.full_name)+'" loading="lazy"></div>'+
              '<div class="mti-v143-sug-copy">'+
                '<span>'+esc(x.office)+'</span>'+
                '<h3>'+esc(x.full_name)+'</h3>'+
                '<p>'+esc((x.biography||'').slice(0,150))+(x.biography&&x.biography.length>150?'…':'')+'</p>'+
              '</div>'+
            '</article>';
          }).join('')+
        '</div>'+
      '</div>';

    footer.parentNode.insertBefore(section,footer);
    mounted=true;
    return true;
  }

  load().then(function(rows){
    if(!rows.length)return;
    if(mount(rows))return;

    /* Homepage React may create the footer after this script executes. */
    var attempts=0;
    var timer=setInterval(function(){
      attempts++;
      if(mount(rows)||attempts>=30){
        clearInterval(timer);
      }
    },500);
  });
})();
