/* MTI V195 — public accessibility and responsive QA */
(function(){'use strict';
 function init(){
  var root=document.documentElement;
  if(!root.classList.contains('mti59-public')) return;
  if(!document.querySelector('.mti-v195-skip')){
   var skip=document.createElement('a');
   skip.className='mti-v195-skip';skip.href='#mti-v195-main';skip.textContent='Skip to main content';
   document.body.insertBefore(skip,document.body.firstChild);
  }
  var main=document.querySelector('main');
  if(main){main.id=main.id||'mti-v195-main';if(!main.hasAttribute('tabindex'))main.setAttribute('tabindex','-1');}
  document.querySelectorAll('img').forEach(function(img){
   if(!img.hasAttribute('loading') && !img.closest('header,nav')) img.setAttribute('loading','lazy');
   if(!img.hasAttribute('decoding')) img.setAttribute('decoding','async');
  });
  document.querySelectorAll('a[href]').forEach(function(a){
   var href=a.getAttribute('href')||'';
   if(href==='#' || href==='javascript:void(0)') a.addEventListener('click',function(e){e.preventDefault();});
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
 new MutationObserver(function(){if(document.documentElement.classList.contains('mti59-public'))init();}).observe(document.documentElement,{attributes:true,attributeFilter:['class']});
})();
