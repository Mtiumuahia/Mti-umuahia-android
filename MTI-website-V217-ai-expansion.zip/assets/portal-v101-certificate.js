(function(){'use strict';if(location.pathname.replace(/\/$/,'')!=='/graduation-certificates')return;const U='https://vjpwllvssblgpwckbiff.supabase.co',K='sb_publishable_oWY2V2aWyoQ4SnLYJHKVbhQ_2V-_TZal',root=document.getElementById('root');let rows=[];function token(){for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i)||'';if(k.startsWith('sb-')&&k.endsWith('-auth-token')){try{const v=JSON.parse(localStorage.getItem(k)||'{}');if(v.access_token)return v.access_token}catch(e){}}}return K}async function rpc(n,b){const r=await fetch(U+'/rest/v1/rpc/'+n,{method:'POST',headers:{apikey:K,Authorization:'Bearer '+token(),'Content-Type':'application/json'},body:JSON.stringify(b||{})});let d;try{d=await r.json()}catch(_){d=null}if(!r.ok)throw Error(d?.message||d?.hint||'Request failed.');return d}function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}function pill(x){return `<span class="mti101-pill ${x==='issued'?'ok':'hold'}">${esc(x||'issued')}</span>`}function app(){root.innerHTML=`<div class="mti101-app"><header class="mti101-top"><img src="/assets/mti-logo.png"><div><small>METHODIST THEOLOGICAL INSTITUTE · UMUAHIA</small><b>Graduation Certificates & Awards</b></div></header><main class="mti101-main"><section class="mti101-card"><div class="mti101-head"><h1>Certificate Management</h1><p>Issue, verify, print and control official graduation certificates.</p></div><div class="mti101-controls"><input id="q" placeholder="Search certificate, code, register number, student number or name"><select id="status"><option value="">All statuses</option><option value="issued">Issued</option><option value="revoked">Revoked</option></select><span></span><button id="go">Refresh</button></div><div id="msg" class="mti101-msg">Loading…</div><div id="table"></div><p class="mti101-note">Certificates can only be issued for graduates already marked <b>Graduated</b> in V100.</p></section></main></div>`;document.getElementById('go').onclick=load;load()}async function load(){const m=document.getElementById('msg');m.textContent='Loading…';try{rows=await rpc('mti_list_graduation_certificates_v101',{p_search:document.getElementById('q').value||null,p_status:document.getElementById('status').value||null});if(!Array.isArray(rows))rows=[];render();m.textContent=rows.length?rows.length+' certificate record(s) loaded.':'No certificate records found.';m.className='mti101-msg mti101-ok'}catch(e){m.textContent=e.message;m.className='mti101-msg mti101-error'}}function render(){const el=document.getElementById('table');if(!rows.length){el.innerHTML='<div class="mti101-empty">No certificates found. Mark the graduate as Graduated in V100, then issue the certificate here.</div>';return}el.innerHTML=`<div class="mti101-tablewrap"><table class="mti101-table"><thead><tr><th>Certificate</th><th>Graduate</th><th>Award</th><th>Classification</th><th>Issue Date</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map(r=>`<tr><td><strong>${esc(r.certificate_number)}</strong><br><small>Code: ${esc(r.verification_code)}</small></td><td><strong>${esc(r.student_name)}</strong><br><small>${esc(r.student_number)} · ${esc(r.programme)}</small></td><td>${esc(r.award_title)}<br><small>${esc(r.graduation_session)}</small></td><td>${esc(r.classification||'—')}</td><td>${esc(r.issue_date||'—')}</td><td>${pill(r.status)}</td><td><div class="mti101-actions">${r.status==='issued'?`<button class="print" data-print="${esc(r.certificate_id)}">Print</button><button class="revoke" data-revoke="${esc(r.certificate_id)}">Revoke</button>`:r.status==='revoked'?'<span>Revoked</span>':`<button class="issue" data-issue="${esc(r.register_id)}">Issue Certificate</button>`}</div></td></tr>`).join('')}</tbody></table></div>`}async function issue(registerId){try{const d=await rpc('mti_issue_graduation_certificate_v101',{p_register_id:registerId});alert('Certificate issued: '+(d?.[0]?.certificate_number||''));await load()}catch(e){alert(e.message)}}async function revoke(id){const reason=prompt('Reason for revocation (optional):','');if(reason===null)return;if(!confirm('Revoke this certificate?'))return;try{await rpc('mti_revoke_graduation_certificate_v101',{p_certificate_id:id,p_reason:reason||null});await load()}catch(e){alert(e.message)}}function showCert(r){
  const modal=document.createElement('div');
  modal.className='mti108-modal';
  const verifyUrl=location.origin+'/certificate-verification?code='+encodeURIComponent(r.verification_code||r.certificate_number||'');
  modal.innerHTML=`
  <div class="mti108-print-sheet">
    <div class="mti108-border mti108-border-outer"></div>
    <div class="mti108-border mti108-border-inner"></div>
    <div class="mti108-watermark">MTI</div>
    <button class="mti108-close no-print">Close</button>
    <button class="mti108-print no-print">Print Certificate</button>

    <header class="mti108-cert-header">
      <img src="/assets/mti-logo.png" class="mti108-logo" onerror="this.style.display='none'">
      <div>
        <div class="mti108-country">METHODIST CHURCH NIGERIA</div>
        <div class="mti108-institute">METHODIST THEOLOGICAL INSTITUTE, UMUAHIA</div>
        <div class="mti108-motto">TRAINING SERVANTS FOR CHRIST AND HIS CHURCH</div>
      </div>
    </header>

    <div class="mti108-rule"></div>
    <div class="mti108-title">CERTIFICATE OF GRADUATION</div>
    <div class="mti108-subtitle">This is to certify that</div>

    <div class="mti108-name">${esc(r.student_name)}</div>
    <div class="mti108-student">Student Number: ${esc(r.student_number||'—')}</div>

    <p class="mti108-body">having satisfactorily fulfilled the academic and institutional requirements of the Institute, has been duly admitted to the award of</p>
    <div class="mti108-award">${esc(r.award_title)}</div>
    <div class="mti108-programme">${esc(r.programme||'')}</div>

    <div class="mti108-details">
      <div><span>Classification</span><b>${esc(r.classification||'Graduation Award')}</b></div>
      <div><span>Graduation Session</span><b>${esc(r.graduation_session||'—')}</b></div>
      <div><span>Certificate No.</span><b>${esc(r.certificate_number||'—')}</b></div>
      <div><span>Date of Issue</span><b>${esc(r.issue_date||'—')}</b></div>
    </div>

    <div class="mti108-bottom">
      <div class="mti108-signature"><div class="mti108-line"></div><b>Rector</b><span>Methodist Theological Institute, Umuahia</span></div>
      <div class="mti108-seal">OFFICIAL<br><strong>MTI</strong><br>SEAL</div>
      <div class="mti108-signature"><div class="mti108-line"></div><b>Registrar</b><span>Methodist Theological Institute, Umuahia</span></div>
    </div>

    <div class="mti108-verification">
      <div id="certificateQr"></div>
      <div><b>Digital Verification</b><small>Scan this QR code to verify this certificate through the official MTI verification service.</small><span>${esc(verifyUrl)}</span></div>
    </div>

    <div class="mti108-footer">Verification Code: <b>${esc(r.verification_code||'—')}</b> · This certificate is issued by Methodist Theological Institute, Umuahia.</div>
  </div>`;
  document.body.appendChild(modal);
  modal.querySelector('.mti108-close').onclick=()=>modal.remove();
  modal.querySelector('.mti108-print').onclick=()=>window.print();
  const printNow=()=>window.print();
  if(window.QRCode){
    QRCode.toCanvas(verifyUrl,{width:112,margin:1,errorCorrectionLevel:'H'},(err,canvas)=>{
      const box=modal.querySelector('#certificateQr');
      if(!err&&box){box.innerHTML='';box.appendChild(canvas)}
    });
  }
}
document.addEventListener('click',async e=>{const i=e.target.closest('[data-issue]');if(i)return issue(i.dataset.issue);const b=e.target.closest('[data-revoke]');if(b)return revoke(b.dataset.revoke);const p=e.target.closest('[data-print]');if(p){const r=rows.find(x=>x.certificate_id===p.dataset.print);if(r)showCert(r)}});app()})();
