/* MTI V150 — Public Academics & Admissions interaction polish */
(function(){
  'use strict';
  var path=(location.pathname||'/').replace(/\/$/,'')||'/';
  if(path!=='/programmes' && path!=='/admissions') return;
  document.documentElement.classList.add('mti-v150-public');

  function enhance(){
    var links=document.querySelectorAll('header a[href], nav a[href]');
    links.forEach(function(a){
      var href=(a.getAttribute('href')||'').replace(/\/$/,'')||'/';
      if(href===path){
        a.classList.add('mti-v150-active');
        a.setAttribute('aria-current','page');
      }
    });

    if(path==='/admissions'){
      var cta=document.querySelector('.admissions-cta');
      if(cta && !cta.querySelector('[data-mti-v150-apply]')){
        var contact=cta.querySelector('a[href="/contact"]');
        if(contact){
          contact.textContent='Contact MTI →';
          contact.classList.add('mti-v150-secondary');
          var wrap=document.createElement('div');
          wrap.className='mti-v150-cta-actions';
          contact.parentNode.insertBefore(wrap,contact);
          wrap.appendChild(contact);
          var apply=document.createElement('a');
          apply.href='/apply-now';
          apply.className='btn';
          apply.setAttribute('data-mti-v150-apply','1');
          apply.textContent='Start Application →';
          wrap.appendChild(apply);
        }
      }
    }

    if(path==='/programmes'){
      var pcta=document.querySelector('.programme-cta');
      if(pcta && !pcta.querySelector('[data-mti-v150-admissions]')){
        var contact2=pcta.querySelector('a[href="/contact"]');
        if(contact2){
          contact2.classList.add('mti-v150-secondary');
          var wrap2=document.createElement('div');
          wrap2.className='mti-v150-cta-actions';
          contact2.parentNode.insertBefore(wrap2,contact2);
          wrap2.appendChild(contact2);
          var adm=document.createElement('a');
          adm.href='/admissions';
          adm.className='btn';
          adm.setAttribute('data-mti-v150-admissions','1');
          adm.textContent='View Admissions →';
          wrap2.appendChild(adm);
        }
      }
    }
    return !!document.querySelector('.hero');
  }

  var tries=0;
  function boot(){
    tries++;
    if(enhance() || tries>=18) return;
    requestAnimationFrame(boot);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
  else boot();
})();
