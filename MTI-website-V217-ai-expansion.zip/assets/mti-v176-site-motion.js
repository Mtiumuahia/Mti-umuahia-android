/* MTI V176 — tasteful site-wide scroll and page motion */
(function(){'use strict';
  var root=document.documentElement;
  root.classList.add('mti-motion-ready');
  var reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var path=(location.pathname||'/').replace(/\/$/,'')||'/';
  function eligible(el){
    if(!el||el.nodeType!==1||el.dataset.mti176Motion)return false;
    if(el.closest('.gallery-lightbox,[role="dialog"],input,textarea,select,button'))return false;
    var tag=el.tagName.toLowerCase();
    if(['script','style','link','svg','path'].indexOf(tag)>=0)return false;
    return true;
  }
  function mark(){
    var selectors=[
      '#root > main > section',
      '#root main > section',
      '#root .content > section',
      '#root .content > .grid3',
      '#root .content > .events',
      '#root .content > .gallery',
      '#root .content > .leadership-grid',
      '#root .content > article',
      '#root .content > .card',
      '#root .content > .panel',
      '#root .content > .section',
      '#root .hero',
      '#root .page-hero',
      '#root .leadership-intro'
    ];
    var nodes=[];
    selectors.forEach(function(sel){document.querySelectorAll(sel).forEach(function(el){if(eligible(el)&&nodes.indexOf(el)<0)nodes.push(el)})});
    nodes.forEach(function(el,i){
      el.dataset.mti176Motion='1';
      el.classList.add('mti-motion-item');
      if(i%7===2)el.dataset.motion='left'; else if(i%7===4)el.dataset.motion='right'; else if(i%7===6)el.dataset.motion='scale';
    });
    if(reduced){nodes.forEach(function(el){el.classList.add('mti-motion-visible')});return;}
    if(!('IntersectionObserver' in window)){nodes.forEach(function(el){el.classList.add('mti-motion-visible')});return;}
    if(!window.__mti176IO){
      window.__mti176IO=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('mti-motion-visible');window.__mti176IO.unobserve(entry.target)}})},{threshold:.12,rootMargin:'0px 0px -45px 0px'});
    }
    nodes.forEach(function(el){if(!el.classList.contains('mti-motion-visible'))window.__mti176IO.observe(el)});
  }
  function pageIn(){root.classList.add('mti-page-enter');setTimeout(function(){root.classList.remove('mti-page-enter')},750)}
  function run(){pageIn();mark();}
  var timer;
  function schedule(){clearTimeout(timer);timer=setTimeout(run,60)}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',run);else run();
  var target=document.getElementById('root')||document.body;
  new MutationObserver(schedule).observe(target,{childList:true,subtree:true});
  window.addEventListener('popstate',function(){setTimeout(run,80)});
  window.addEventListener('pageshow',function(){setTimeout(run,40)});
})();
