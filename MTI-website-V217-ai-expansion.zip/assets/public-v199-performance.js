/* MTI V199 — public performance helpers */
(function(){'use strict';
 function init(){
  var root=document.documentElement;
  var p=location.pathname.replace(/\/$/,'');
  var publicRoutes=['','/about','/governance','/visit','/leadership','/programmes','/admissions','/news','/events','/gallery','/sug-executives'];
  if(!publicRoutes.includes(p))return;
  root.classList.add('mti-v199-public');
  var imgs=document.querySelectorAll('img');
  imgs.forEach(function(img,i){
   if(!img.getAttribute('decoding'))img.setAttribute('decoding','async');
   if(i>1 && !img.getAttribute('loading'))img.setAttribute('loading','lazy');
   if(i>2 && !img.getAttribute('fetchpriority'))img.setAttribute('fetchpriority','low');
  });
  var links=document.querySelectorAll('a[href]');
  links.forEach(function(a){
   var h=a.getAttribute('href')||'';
   if(/^https?:\/\//i.test(h) && !a.target){a.target='_blank';a.rel='noopener noreferrer';}
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
