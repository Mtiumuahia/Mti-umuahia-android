/* MTI V196 — SUG directory interaction */
(function(){'use strict';
function init(){
 var path=location.pathname.replace(/\/$/,''); if(path!=='/sug-executives')return;
 var root=document.getElementById('root'); if(!root)return;
 var grid=root.querySelector('.sug146-grid'), head=root.querySelector('.sug146-section-head'); if(!grid||!head)return;
 var cards=[].slice.call(grid.querySelectorAll('.sug146-card'));
 var tools=document.createElement('div'); tools.className='mti196-sug-tools';
 tools.innerHTML='<input class="mti196-sug-search" type="search" aria-label="Search SUG executives" placeholder="Search by name or office…"><span class="mti196-sug-count"></span>';
 grid.parentNode.insertBefore(tools,grid);
 var input=tools.querySelector('input'), count=tools.querySelector('.mti196-sug-count');
 cards.forEach(function(card){
   var p=card.querySelector('.sug146-card-body p');
   if(p&&p.textContent.trim().length>185){p.dataset.full=p.textContent;p.textContent=p.textContent.slice(0,185).trim()+'…';var b=document.createElement('button');b.type='button';b.className='mti196-sug-more';b.textContent='Read biography';b.onclick=function(){var open=b.dataset.open==='1';p.textContent=open?p.dataset.full:p.dataset.full.slice(0,185).trim()+'…';b.textContent=open?'Read biography':'Read full biography';b.dataset.open=open?'0':'1'};p.parentNode.appendChild(b);
   }
   var img=card.querySelector('img'); if(img){img.addEventListener('error',function(){if(img.dataset.fallback)return;img.dataset.fallback='1';img.removeAttribute('src');img.classList.add('mti196-sug-photo-fallback');img.alt='';img.textContent=(card.querySelector('h3')?.textContent||'M').trim().charAt(0).toUpperCase()})}
 });
 function filter(){var q=(input.value||'').trim().toLowerCase(),shown=0;cards.forEach(function(c){var t=c.textContent.toLowerCase();var ok=!q||t.indexOf(q)>-1;c.classList.toggle('mti196-sug-card-hidden',!ok);if(ok)shown++});count.textContent=shown+' of '+cards.length+' profiles';var empty=grid.querySelector('.mti196-sug-empty-filter');if(!shown){if(!empty){empty=document.createElement('div');empty.className='mti196-sug-empty-filter';grid.appendChild(empty)}empty.textContent='No SUG executive matches your search.'}else if(empty)empty.remove()}
 input.addEventListener('input',filter);filter();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
