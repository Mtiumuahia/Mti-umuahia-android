/* MTI V187 — News reading experience */
(function(){
  'use strict';
  var active=null;
  function esc(s){return String(s||'').replace(/[&<>"']/g,function(c){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]})}
  function close(){if(active){active.remove();active=null;document.body.classList.remove('mti-news-reading-open')}}
  function openArticle(article){
    if(active) close();
    var title=(article.querySelector('h3')||{}).textContent||'MTI News';
    var date=(article.querySelector('small')||{}).textContent||'';
    var text=(article.querySelector('p')||{}).textContent||'';
    var media=article.querySelector('.mti-v180-public-media');
    var mediaHtml='';
    if(media){
      var img=media.querySelector('img'), vid=media.querySelector('video');
      if(img) mediaHtml='<img src="'+esc(img.currentSrc||img.src)+'" alt="'+esc(img.alt)+'">';
      else if(vid) mediaHtml='<video src="'+esc(vid.currentSrc||vid.src)+'" controls playsinline></video>';
    } else {
      var cover=article.querySelector(':scope > img');
      if(cover) mediaHtml='<img src="'+esc(cover.currentSrc||cover.src)+'" alt="'+esc(cover.alt)+'">';
    }
    var dl=media && media.querySelector('.mti-v180-news-download');
    active=document.createElement('div');
    active.className='mti-v187-reader';
    active.innerHTML='<div class="mti-v187-reader-backdrop"></div><section class="mti-v187-reader-panel" role="dialog" aria-modal="true" aria-label="News article"><button class="mti-v187-reader-close" aria-label="Close">×</button><div class="mti-v187-reader-media">'+mediaHtml+'</div><div class="mti-v187-reader-body"><span class="mti-v187-reader-kicker">MTI NEWS</span><time>'+esc(date)+'</time><h2>'+esc(title)+'</h2><div class="mti-v187-reader-copy">'+esc(text)+'</div><div class="mti-v187-reader-actions">'+(dl?'<a class="mti-v187-reader-download" href="'+esc(dl.href)+'" target="_blank" rel="noreferrer">Download Media</a>':'')+'<button class="mti-v187-reader-print">Print Article</button><button class="mti-v187-reader-share">Share</button></div></div></section>';
    document.body.appendChild(active); document.body.classList.add('mti-news-reading-open');
    active.querySelector('.mti-v187-reader-close').onclick=close; active.querySelector('.mti-v187-reader-backdrop').onclick=close;
    active.querySelector('.mti-v187-reader-print').onclick=function(){window.print()};
    active.querySelector('.mti-v187-reader-share').onclick=function(){var data={title:title,text:text,url:location.href}; if(navigator.share) navigator.share(data).catch(function(){}); else {navigator.clipboard&&navigator.clipboard.writeText(location.href); this.textContent='Link copied'}};
    document.addEventListener('keydown',key); setTimeout(function(){var b=active.querySelector('.mti-v187-reader-close');if(b)b.focus()},30);
  }
  function key(e){if(e.key==='Escape')close()}
  function bind(){
    if(location.pathname.replace(/\/$/,'')!=='/news') return;
    document.querySelectorAll('#root .grid3 article').forEach(function(a){if(a.dataset.mti187)return;a.dataset.mti187='1';var btn=document.createElement('button');btn.className='mti-v187-read';btn.type='button';btn.textContent='Read full story';btn.onclick=function(e){e.stopPropagation();openArticle(a)};a.appendChild(btn)});
  }
  function init(){bind();new MutationObserver(function(){bind()}).observe(document.getElementById('root')||document.body,{childList:true,subtree:true});window.addEventListener('popstate',function(){setTimeout(bind,60)})}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
