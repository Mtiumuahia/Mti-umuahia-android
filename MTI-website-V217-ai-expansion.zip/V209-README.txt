MTI V209 — Site-Wide Public Route & Contrast QA

Purpose
- Repair blank About MTI, Leadership and Governance & Policies routes caused by route branches loading enhancement scripts without loading the main public renderer.
- Make renderer loading occur before page-specific institutional enhancements.
- Order Visit MTI rendering before its institutional enhancement scripts.
- Harden contrast on dark public sections so dark text cannot be forced onto dark-green backgrounds.
- Fix the Campus CTA button contrast.
- Remove legacy Contact and Gallery links from the public React footer and add a defensive cleanup for cached/legacy output.

No SQL migration required.
No Supabase tables, RPCs, buckets, RLS policies, or storage policies were changed.
