MTI V147 — Production Hardening + Whole-Class Results + Exam Registry

1. Lecturer Result Entry
- One class sheet lists every registered student.
- Displays name, MTI registration number and institution-controlled exam number.
- Lecturer enters scores in one table and saves the class together using the existing V91 bulk result engine.
- Search, print and mobile horizontal-table support included.
- Published results remain locked.

2. Examination Number Registry
- Management Dashboard now includes Examination Numbers.
- Management can assign or update unique examination numbers for student records.
- Uses student_profiles.exam_number created in V146.

3. Conflict hardening
- V146 duplicate frontend assets removed.
- Route loader points to V147 result assets and V147 management assets.
- No duplicate result table created.
- No duplicate SUG table created.

DATABASE
Run MTI-V147-SQL.sql once in Supabase SQL Editor.
V147 does not replace or delete existing academic data.
