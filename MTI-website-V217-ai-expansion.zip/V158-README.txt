MTI V158 — Management Command Centre & Admissions Office UI Audit

Executive dashboard KPI cards, structured quick administration, improved responsive management layout, visible admission control workflow, improved Admissions Office styling, and corrected student programme field fallback.
No SQL migration required; existing V154 admission control and V137 staff-account services are reused.
