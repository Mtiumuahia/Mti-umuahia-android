BEGIN;

ALTER TABLE public.news
  ADD COLUMN IF NOT EXISTS media_url text,
  ADD COLUMN IF NOT EXISTS media_type text,
  ADD COLUMN IF NOT EXISTS media_name text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM pg_constraint
    WHERE conname = 'news_media_type_check'
      AND conrelid = 'public.news'::regclass
  ) THEN
    ALTER TABLE public.news
      ADD CONSTRAINT news_media_type_check
      CHECK (
        media_type IS NULL
        OR media_type IN ('image','video')
      );
  END IF;
END $$;

INSERT INTO storage.buckets (id, name, public)
VALUES ('mti-news-media', 'mti-news-media', true)
ON CONFLICT (id) DO UPDATE SET public = true;

DROP POLICY IF EXISTS v180_news_media_public_read
ON storage.objects;

CREATE POLICY v180_news_media_public_read
ON storage.objects
FOR SELECT
TO anon, authenticated
USING (bucket_id = 'mti-news-media');

DROP POLICY IF EXISTS v180_news_media_authenticated_insert
ON storage.objects;

CREATE POLICY v180_news_media_authenticated_insert
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'mti-news-media');

DROP POLICY IF EXISTS v180_news_media_authenticated_update
ON storage.objects;

CREATE POLICY v180_news_media_authenticated_update
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'mti-news-media')
WITH CHECK (bucket_id = 'mti-news-media');

DROP POLICY IF EXISTS v180_news_media_authenticated_delete
ON storage.objects;

CREATE POLICY v180_news_media_authenticated_delete
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'mti-news-media');

CREATE INDEX IF NOT EXISTS news_media_type_idx
ON public.news(media_type);

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
