-- MTI V159 — Admission Submission Ambiguity Fix
--
-- Fixes the PostgreSQL "column reference \"id\" is ambiguous" error
-- encountered when submitting an online admission application.
-- The conflict came from the V154 admission-control RPC because the
-- function RETURNS TABLE (id ...) while its SELECT used an unqualified
-- `id` in the admission-control table predicate.
--
-- This migration also hardens the V157 public application-status lookup
-- by qualifying application columns explicitly.

BEGIN;

-- ============================================================
-- 1. Correct the V154 public admission status function.
-- ============================================================
CREATE OR REPLACE FUNCTION public.mti_get_admission_portal_status_v154()
RETURNS TABLE (
  is_open boolean,
  application_opened_at timestamptz,
  application_closed_at timestamptz,
  selection_conference_date date,
  selection_conference_venue text,
  selection_notice text,
  required_documents text
)
LANGUAGE sql
SECURITY DEFINER
STABLE
SET search_path = public
AS $function$
  SELECT
    c.is_open,
    c.application_opened_at,
    c.application_closed_at,
    c.selection_conference_date,
    c.selection_conference_venue,
    c.selection_notice,
    c.required_documents
  FROM public.mti_admission_portal_control_v154 AS c
  WHERE c.id = true;
$function$;

REVOKE ALL
ON FUNCTION public.mti_get_admission_portal_status_v154()
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.mti_get_admission_portal_status_v154()
TO anon, authenticated;

-- ============================================================
-- 2. Correct the public application submission RPC.
--    The only functional change is qualification of the control
--    table id predicate and the generated application's id reads.
-- ============================================================
CREATE OR REPLACE FUNCTION public.mti_submit_public_application_v153(
  p_full_name text,
  p_email text,
  p_phone text,
  p_programme text,
  p_level text DEFAULT NULL,
  p_section text DEFAULT NULL,
  p_statement text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  application_no text,
  application_number text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_open boolean;
  v_id uuid;
  v_app_no text;
  v_app_number text;
  v_name text := trim(coalesce(p_full_name, ''));
  v_email text := lower(trim(coalesce(p_email, '')));
  v_phone text := trim(coalesce(p_phone, ''));
  v_programme text := trim(coalesce(p_programme, ''));
  v_level text := NULLIF(trim(coalesce(p_level, '')), '');
  v_section text := NULLIF(trim(coalesce(p_section, '')), '');
  v_statement text := NULLIF(trim(coalesce(p_statement, '')), '');
  v_cols text[] := ARRAY['id'];
  v_vals text[] := ARRAY['gen_random_uuid()'];
  v_required text;
  v_default text;
  v_nullable text;
  v_exists boolean;
  v_generated text;
BEGIN
  SELECT c.is_open
  INTO v_open
  FROM public.mti_admission_portal_control_v154 AS c
  WHERE c.id = true;

  IF coalesce(v_open, false) = false THEN
    RAISE EXCEPTION 'Admission is not ongoing now. Please check later.';
  END IF;

  IF length(v_name) < 3 THEN
    RAISE EXCEPTION 'Full name is required.';
  END IF;

  IF length(v_name) > 180 THEN
    RAISE EXCEPTION 'Full name is too long.';
  END IF;

  IF v_email !~* '^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$' THEN
    RAISE EXCEPTION 'Please provide a valid email address.';
  END IF;

  IF length(v_phone) < 7 THEN
    RAISE EXCEPTION 'A valid phone number is required.';
  END IF;

  IF v_programme = '' THEN
    RAISE EXCEPTION 'Please select a programme.';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM public.applications AS a
    WHERE lower(coalesce(a.email, '')) = v_email
      AND a.created_at > now() - interval '10 minutes'
  ) THEN
    RAISE EXCEPTION
      'An application using this email address was submitted recently. Please wait or contact MTI Admissions.';
  END IF;

  FOREACH v_required IN ARRAY ARRAY[
    'full_name','email','phone','programme','level','section','statement','status','user_id'
  ]
  LOOP
    SELECT EXISTS (
      SELECT 1
      FROM information_schema.columns AS ic
      WHERE ic.table_schema = 'public'
        AND ic.table_name = 'applications'
        AND ic.column_name = v_required
    )
    INTO v_exists;

    IF NOT v_exists THEN
      CONTINUE;
    END IF;

    SELECT ic.is_nullable, ic.column_default
    INTO v_nullable, v_default
    FROM information_schema.columns AS ic
    WHERE ic.table_schema = 'public'
      AND ic.table_name = 'applications'
      AND ic.column_name = v_required;

    IF v_required = 'full_name' THEN
      v_cols := array_append(v_cols, 'full_name');
      v_vals := array_append(v_vals, quote_nullable(v_name));
    ELSIF v_required = 'email' THEN
      v_cols := array_append(v_cols, 'email');
      v_vals := array_append(v_vals, quote_nullable(v_email));
    ELSIF v_required = 'phone' THEN
      v_cols := array_append(v_cols, 'phone');
      v_vals := array_append(v_vals, quote_nullable(v_phone));
    ELSIF v_required = 'programme' THEN
      v_cols := array_append(v_cols, 'programme');
      v_vals := array_append(v_vals, quote_nullable(v_programme));
    ELSIF v_required = 'level' AND v_level IS NOT NULL THEN
      v_cols := array_append(v_cols, 'level');
      v_vals := array_append(v_vals, quote_nullable(v_level));
    ELSIF v_required = 'section' AND v_section IS NOT NULL THEN
      v_cols := array_append(v_cols, 'section');
      v_vals := array_append(v_vals, quote_nullable(v_section));
    ELSIF v_required = 'statement' AND v_statement IS NOT NULL THEN
      v_cols := array_append(v_cols, 'statement');
      v_vals := array_append(v_vals, quote_nullable(v_statement));
    ELSIF v_required = 'status' THEN
      v_cols := array_append(v_cols, 'status');
      v_vals := array_append(v_vals, quote_literal('submitted'));
    ELSIF v_required = 'user_id' AND v_nullable = 'YES' THEN
      v_cols := array_append(v_cols, 'user_id');
      v_vals := array_append(v_vals, 'NULL');
    END IF;
  END LOOP;

  SELECT EXISTS (
    SELECT 1
    FROM information_schema.columns AS ic
    WHERE ic.table_schema = 'public'
      AND ic.table_name = 'applications'
      AND ic.column_name = 'application_no'
  )
  INTO v_exists;

  IF v_exists THEN
    SELECT ic.column_default
    INTO v_default
    FROM information_schema.columns AS ic
    WHERE ic.table_schema = 'public'
      AND ic.table_name = 'applications'
      AND ic.column_name = 'application_no';

    IF v_default IS NULL THEN
      v_generated :=
        'MTI/APP/' ||
        to_char(now(), 'YYYY') ||
        '/' ||
        upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8));

      v_cols := array_append(v_cols, 'application_no');
      v_vals := array_append(v_vals, quote_literal(v_generated));
    END IF;
  ELSE
    SELECT EXISTS (
      SELECT 1
      FROM information_schema.columns AS ic
      WHERE ic.table_schema = 'public'
        AND ic.table_name = 'applications'
        AND ic.column_name = 'application_number'
    )
    INTO v_exists;

    IF v_exists THEN
      SELECT ic.column_default
      INTO v_default
      FROM information_schema.columns AS ic
      WHERE ic.table_schema = 'public'
        AND ic.table_name = 'applications'
        AND ic.column_name = 'application_number';

      IF v_default IS NULL THEN
        v_generated :=
          'MTI/APP/' ||
          to_char(now(), 'YYYY') ||
          '/' ||
          upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 8));

        v_cols := array_append(v_cols, 'application_number');
        v_vals := array_append(v_vals, quote_literal(v_generated));
      END IF;
    END IF;
  END IF;

  FOREACH v_required IN ARRAY ARRAY['created_at', 'updated_at']
  LOOP
    SELECT EXISTS (
      SELECT 1
      FROM information_schema.columns AS ic
      WHERE ic.table_schema = 'public'
        AND ic.table_name = 'applications'
        AND ic.column_name = v_required
    )
    INTO v_exists;

    IF v_exists THEN
      SELECT ic.column_default
      INTO v_default
      FROM information_schema.columns AS ic
      WHERE ic.table_schema = 'public'
        AND ic.table_name = 'applications'
        AND ic.column_name = v_required;

      IF v_default IS NULL THEN
        v_cols := array_append(v_cols, v_required);
        v_vals := array_append(v_vals, 'now()');
      END IF;
    END IF;
  END LOOP;

  EXECUTE
    'INSERT INTO public.applications (' || array_to_string(v_cols, ',') ||
    ') VALUES (' || array_to_string(v_vals, ',') ||
    ') RETURNING id'
  INTO v_id;

  IF EXISTS (
    SELECT 1
    FROM information_schema.columns AS ic
    WHERE ic.table_schema = 'public'
      AND ic.table_name = 'applications'
      AND ic.column_name = 'application_no'
  ) THEN
    EXECUTE
      'SELECT a.application_no::text FROM public.applications AS a WHERE a.id = $1'
    INTO v_app_no
    USING v_id;
  END IF;

  IF EXISTS (
    SELECT 1
    FROM information_schema.columns AS ic
    WHERE ic.table_schema = 'public'
      AND ic.table_name = 'applications'
      AND ic.column_name = 'application_number'
  ) THEN
    EXECUTE
      'SELECT a.application_number::text FROM public.applications AS a WHERE a.id = $1'
    INTO v_app_number
    USING v_id;
  END IF;

  RETURN QUERY
  SELECT v_id AS id, v_app_no AS application_no, v_app_number AS application_number;
END;
$function$;

REVOKE ALL
ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text)
TO anon, authenticated;

-- ============================================================
-- 3. Harden the V157 application-status lookup as well.
-- ============================================================
CREATE OR REPLACE FUNCTION public.mti_lookup_application_status_v157(
  p_application_ref text,
  p_email text
)
RETURNS TABLE (
  id uuid,
  application_no text,
  application_number text,
  full_name text,
  email text,
  programme text,
  status text,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path = public
AS $function$
DECLARE
  v_ref text := trim(coalesce(p_application_ref, ''));
  v_email text := lower(trim(coalesce(p_email, '')));
BEGIN
  IF v_ref = '' OR v_email = '' THEN
    RAISE EXCEPTION 'Application number and email address are required.';
  END IF;

  RETURN QUERY
  SELECT
    a.id AS id,
    a.application_no::text AS application_no,
    a.application_number::text AS application_number,
    a.full_name::text AS full_name,
    a.email::text AS email,
    a.programme::text AS programme,
    coalesce(a.status, 'submitted')::text AS status,
    a.created_at AS created_at
  FROM public.applications AS a
  WHERE lower(trim(coalesce(a.email, ''))) = v_email
    AND (
      lower(trim(coalesce(a.application_no, ''))) = lower(v_ref)
      OR lower(trim(coalesce(a.application_number, ''))) = lower(v_ref)
    )
  LIMIT 1;
END;
$function$;

REVOKE ALL
ON FUNCTION public.mti_lookup_application_status_v157(text, text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.mti_lookup_application_status_v157(text, text)
TO anon, authenticated;

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
