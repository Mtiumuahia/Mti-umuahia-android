MTI V211 — Leadership Biography & CMS Authentication Fix

Based on MTI V210.

Changes:
1. Leadership biographies now have a visible Read more control for substantial biographies.
2. Read more expands the biography without navigating away; Close biography collapses it again.
3. Existing V185 leadership motion/presentation is retained, with a guard against duplicate biography controls.
4. CMS administrator sign-in uses a bounded direct Supabase password-token request so the UI cannot remain indefinitely at “Signing in…”.
5. Authentication timeout and server error messages are shown in the CMS login form.
6. Successful CMS authentication stores the existing Supabase session key and reloads into the existing role-gated CMS.
7. No database schema changes.

SQL: No SQL migration required.

Testing performed:
- All JavaScript files passed node --check.
- CSS brace-balance validation passed.
- Local asset references from index.html checked.
- V211 structural assertions passed.
- ZIP integrity checked with unzip -t.

AI MTI Assistant is intentionally NOT implemented in V211; it is the next planned feature after this issue is verified.
