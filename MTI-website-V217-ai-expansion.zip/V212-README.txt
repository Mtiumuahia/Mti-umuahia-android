MTI V212 — AI ASSISTANT

Purpose
- Replaces the V210 keyword-only customer-care responder with a genuinely AI-powered public MTI Assistant.
- Uses a Netlify Function as a secure server-side gateway to the OpenAI Responses API.
- The OpenAI API key is NEVER placed in browser JavaScript.
- Answers are grounded in an approved MTI public knowledge base and instructed not to invent institutional facts.
- Personal application, student, payment, result and account data are not exposed through this public assistant.

Setup required after deployment
1. In Netlify Site configuration > Environment variables, add OPENAI_API_KEY with your OpenAI API key.
2. Give it Functions scope.
3. Optional: set MTI_AI_MODEL (default: gpt-5.6-luna).
4. Optional: set MTI_AI_ALLOWED_ORIGINS to a comma-separated list of allowed site origins.
5. Redeploy after changing environment variables.

No SQL migration required.
