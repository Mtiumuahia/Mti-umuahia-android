MTI V166 — Digital Classroom Workspace

Focus:
- Rebuilt active online-classroom and online-learning UI.
- Professional digital campus landing page and authenticated lobby.
- Search/filter for virtual sessions.
- Session metadata, course/title, schedule and room entry.
- Reuses existing online_classes data; no database migration required.
- Student/Lecturer portals remain untouched.
