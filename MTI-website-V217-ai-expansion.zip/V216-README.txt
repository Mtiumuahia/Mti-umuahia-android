MTI WEBSITE V216 — AI ASSISTANT UX, RESILIENCE & PROMPT-SAFETY HARDENING

What changed
- Audited V215 before modification.
- Added a New conversation control to clear the current AI conversation without reloading the page.
- Added Copy action to assistant replies using the already-clean plain-text response.
- Limited the browser composer to 600 characters and added a client timeout so a stalled request does not leave the assistant locked indefinitely.
- Preserved the V215 asterisk/Markdown cleanup on both server and client.
- Added a server-side total conversation-history cap to keep requests bounded.
- Added explicit prompt-safety rules: visitor-supplied history and live CMS/public content are treated as untrusted data, not executable instructions.
- Kept private portal/application/payment/result/credential data outside the retrieval layer.
- No Supabase tables, buckets, policies, RPCs, or SQL migrations were created or changed.

Testing
- node --check run across all JavaScript and module files.
- ZIP integrity checked with unzip -t.
- Local asset references audited.
- Active index.html references V216 CSS/JS.

SQL
NO SQL MIGRATION REQUIRED FOR V216.
