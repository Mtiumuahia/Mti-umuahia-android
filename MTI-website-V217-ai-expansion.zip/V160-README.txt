MTI Website V160
Selection Conference Assessment & Admission Decision Centre

Changes:
- Adds management-only Selection Conference assessment records for written examination, document verification, interview and medical examination.
- Adds a management Admissions Office assessment page.
- Admission finalization requires all four assessment stages to be marked completed.
- Reuses the existing V137 admitted-student registration number and one-time activation-token workflow.
- Keeps applicant password/account creation out of the public application process.
- Adds a clearer admission-decision workflow in the Admissions Office.
- V159 admission submission ambiguity fix remains included.
- V159 Digital Classroom remains included.

SQL required: YES — run V160.sql in Supabase before using Selection Assessment / Finalize Admission.
