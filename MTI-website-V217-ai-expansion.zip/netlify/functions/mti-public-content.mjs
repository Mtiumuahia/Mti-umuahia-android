/* MTI V213 — server-side retrieval of approved public MTI content.
   Uses the same Supabase public/publishable credentials already used by the public site.
   No service-role key and no private portal data are used here. */

const SUPABASE_URL = process.env.MTI_SUPABASE_URL || 'https://vjpwllvssblgpwckbiff.supabase.co';
const SUPABASE_KEY = process.env.MTI_SUPABASE_ANON_KEY || 'sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal';
const FETCH_TIMEOUT = 7000;

function clean(value, max = 900) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
}

async function request(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeout || FETCH_TIMEOUT);
  try {
    const response = await fetch(`${SUPABASE_URL}${path}`, {
      method: options.method || 'GET',
      headers: {
        apikey: SUPABASE_KEY,
        Authorization: `Bearer ${SUPABASE_KEY}`,
        ...(options.body ? { 'Content-Type': 'application/json' } : {})
      },
      body: options.body ? JSON.stringify(options.body) : undefined,
      signal: controller.signal
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) throw new Error(`Supabase request failed: ${response.status}`);
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function compact(rows, fields, limit = 10) {
  return (Array.isArray(rows) ? rows : []).slice(0, limit).map(row => {
    const out = {};
    for (const field of fields) if (row?.[field] !== null && row?.[field] !== undefined && row?.[field] !== '') out[field] = clean(row[field]);
    return out;
  });
}

export async function getPublicMTIContext() {
  const jobs = [
    request('/rest/v1/news?select=id,title,excerpt,published_at,slug&published=eq.true&order=published_at.desc&limit=10').catch(() => []),
    request('/rest/v1/events?select=id,title,description,location,starts_at,ends_at&order=starts_at.asc&limit=12').catch(() => []),
    request('/rest/v1/programmes?select=id,name,duration,description&order=created_at.desc&limit=100').catch(() => []),
    request('/rest/v1/leadership?select=id,name,role,bio,sort_order&order=sort_order.asc&limit=30').catch(() => []),
    request('/rest/v1/gallery_photos?select=id,title,media_type,created_at,category&order=created_at.desc&limit=8').catch(() => []),
    request('/rest/v1/rpc/mti_get_admission_portal_status_v154', { method: 'POST', body: {} }).catch(() => null)
  ];
  const [news, events, programmes, leadership, gallery, admissionRaw] = await Promise.all(jobs);
  const admission = Array.isArray(admissionRaw) ? admissionRaw[0] : admissionRaw;

  return {
    retrieved_at: new Date().toISOString(),
    source: 'MTI public Supabase content and approved public admission-status RPC',
    news: compact(news, ['title','excerpt','published_at','slug'], 10),
    events: compact(events, ['title','description','location','starts_at','ends_at'], 12),
    programmes: compact(programmes, ['name','duration','description'], 100),
    leadership: compact(leadership, ['name','role','bio','sort_order'], 30),
    gallery: compact(gallery, ['title','media_type','created_at','category'], 8),
    admissions: admission ? {
      is_open: admission.is_open === true,
      application_opened_at: admission.application_opened_at || null,
      application_closed_at: admission.application_closed_at || null,
      selection_conference_date: admission.selection_conference_date || null,
      selection_conference_venue: clean(admission.selection_conference_venue, 500) || null,
      selection_notice: clean(admission.selection_notice, 1200) || null,
      required_documents: clean(admission.required_documents, 1200) || null
    } : null
  };
}

export function contextForModel(data) {
  const safe = JSON.parse(JSON.stringify(data || {}));
  return `LIVE APPROVED MTI PUBLIC CONTENT (retrieved at ${safe.retrieved_at || 'request time'})\n${JSON.stringify(safe)}\n\nInterpretation rules: this live block is authoritative for current public News, Events, published Programmes, Leadership, Gallery metadata, and the Admissions portal status. If a live field is missing, do not invent it. Do not expose internal IDs unless useful to explain a page record. Never use this content to answer private student/application/payment/result questions.`;
}
