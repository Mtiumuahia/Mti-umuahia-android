BEGIN;

-- MTI V207 — backend security hardening for the existing news-media bucket.
-- Reuses the existing mti-news-media bucket and V180 public-read behaviour.
-- No new application table, bucket, RPC or schema is created.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM storage.buckets WHERE id = 'mti-news-media') THEN
    INSERT INTO storage.buckets (id, name, public) VALUES ('mti-news-media', 'mti-news-media', true);
  END IF;
END $$;

DROP POLICY IF EXISTS v180_news_media_authenticated_insert ON storage.objects;
DROP POLICY IF EXISTS v180_news_media_authenticated_update ON storage.objects;
DROP POLICY IF EXISTS v180_news_media_authenticated_delete ON storage.objects;
DROP POLICY IF EXISTS v207_news_media_management_insert ON storage.objects;
DROP POLICY IF EXISTS v207_news_media_management_update ON storage.objects;
DROP POLICY IF EXISTS v207_news_media_management_delete ON storage.objects;

CREATE POLICY v207_news_media_management_insert
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'mti-news-media' AND (public.has_portal_role('management') OR public.has_portal_role('admin')));

CREATE POLICY v207_news_media_management_update
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'mti-news-media' AND (public.has_portal_role('management') OR public.has_portal_role('admin')))
WITH CHECK (bucket_id = 'mti-news-media' AND (public.has_portal_role('management') OR public.has_portal_role('admin')));

CREATE POLICY v207_news_media_management_delete
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'mti-news-media' AND (public.has_portal_role('management') OR public.has_portal_role('admin')));

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
