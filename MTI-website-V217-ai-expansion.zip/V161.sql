BEGIN;

CREATE TABLE IF NOT EXISTS public.admission_notification_log_v161 (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  application_id uuid NOT NULL
    REFERENCES public.applications(id)
    ON DELETE CASCADE,
  channel text NOT NULL DEFAULT 'email+sms'
    CHECK (channel IN ('email','sms','email+sms')),
  delivery_status text NOT NULL
    CHECK (delivery_status IN ('sent','partial','failed')),
  email_sent boolean NOT NULL DEFAULT false,
  sms_sent boolean NOT NULL DEFAULT false,
  provider_message text,
  sent_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  sent_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS admission_notification_log_v161_application_idx
  ON public.admission_notification_log_v161(application_id, sent_at DESC);

ALTER TABLE public.admission_notification_log_v161 ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS v161_notification_management_select
ON public.admission_notification_log_v161;

CREATE POLICY v161_notification_management_select
ON public.admission_notification_log_v161
FOR SELECT
TO authenticated
USING (
  public.has_portal_role('management')
  OR public.has_portal_role('admin')
);

DROP POLICY IF EXISTS v161_notification_management_insert
ON public.admission_notification_log_v161;

CREATE POLICY v161_notification_management_insert
ON public.admission_notification_log_v161
FOR INSERT
TO authenticated
WITH CHECK (
  (
    public.has_portal_role('management')
    OR public.has_portal_role('admin')
  )
  AND sent_by = auth.uid()
);

CREATE OR REPLACE FUNCTION public.mti_log_admission_notification_v161(
  p_application_id uuid,
  p_channel text DEFAULT 'email+sms',
  p_delivery_status text DEFAULT 'failed',
  p_email_sent boolean DEFAULT false,
  p_sms_sent boolean DEFAULT false,
  p_provider_message text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_id uuid;
  v_channel text := lower(trim(coalesce(p_channel, '')));
  v_status text := lower(trim(coalesce(p_delivery_status, '')));
BEGIN
  IF NOT (
    public.has_portal_role('management')
    OR public.has_portal_role('admin')
  ) THEN
    RAISE EXCEPTION 'Management access is required.';
  END IF;

  IF NOT EXISTS (
    SELECT 1
    FROM public.applications AS a
    WHERE a.id = p_application_id
  ) THEN
    RAISE EXCEPTION 'Application not found.';
  END IF;

  IF v_channel NOT IN ('email','sms','email+sms') THEN
    RAISE EXCEPTION 'Invalid notification channel.';
  END IF;

  IF v_status NOT IN ('sent','partial','failed') THEN
    RAISE EXCEPTION 'Invalid notification delivery status.';
  END IF;

  INSERT INTO public.admission_notification_log_v161 (
    application_id,
    channel,
    delivery_status,
    email_sent,
    sms_sent,
    provider_message,
    sent_by,
    sent_at
  )
  VALUES (
    p_application_id,
    v_channel,
    v_status,
    coalesce(p_email_sent, false),
    coalesce(p_sms_sent, false),
    NULLIF(trim(coalesce(p_provider_message, '')), ''),
    auth.uid(),
    now()
  )
  RETURNING id INTO v_id;

  RETURN v_id;
END;
$function$;

REVOKE ALL
ON FUNCTION public.mti_log_admission_notification_v161(
  uuid,text,text,boolean,boolean,text
)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.mti_log_admission_notification_v161(
  uuid,text,text,boolean,boolean,text
)
TO authenticated;

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
