MTI Website V162 — Unified Academic Workspace & Executive Digital Classroom

Changes:
- Rebuilt active Student Portal visual layer on the existing secure V132 application engine.
- Rebuilt active Lecturer Portal visual layer on the existing secure V132 application engine.
- Improved navigation density, cards, dashboard spacing, mobile drawer behavior and tables.
- Rebuilt Online Classroom / Online Learning presentation as a premium MTI Digital Campus experience.
- Both /online-classroom and /online-learning now use the V162 classroom experience.
- Existing Supabase authentication and online_classes data source retained.
- Existing meeting URL fields retained.
- No database migration required.

Deployment:
Deploy the contents of this package to Netlify. No SQL is required for V162.
