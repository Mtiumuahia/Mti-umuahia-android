MTI V217 — AI Assistant knowledge expansion and professional UI refinement

Changes:
- Broader general knowledge and theological/biblical question support.
- Balanced handling of differing theological traditions.
- MTI-specific facts remain grounded in approved MTI content and live public retrieval.
- Refined suggested-question chips with lighter typography and professional institutional styling.
- Updated welcome message.
- No database schema changes.

SQL migration required: NO.
