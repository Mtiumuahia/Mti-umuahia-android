-- MTI V153 — Public Admission Submission + Admitted-Student Activation Workflow
--
-- Purpose:
-- 1. Applicants submit an application WITHOUT creating an Auth account.
-- 2. Applications remain unlinked to auth.users until MTI admits the applicant.
-- 3. Existing V137 admission workflow then generates the MTI Registration Number
--    and one-time activation token.
-- 4. The existing activate-student-v137 Edge Function is used only after admission
--    to create the Student Portal account and password.
--
-- Run AFTER the existing MTI V137 SQL migration.

BEGIN;

-- ------------------------------------------------------------
-- 1. Applications must be able to exist before an Auth account.
-- ------------------------------------------------------------
DO $migration$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND table_name = 'applications'
      AND column_name = 'user_id'
  ) THEN
    EXECUTE 'ALTER TABLE public.applications ALTER COLUMN user_id DROP NOT NULL';
  END IF;
END
$migration$;

-- ------------------------------------------------------------
-- 2. Anonymous/public application submission RPC.
--    SECURITY DEFINER keeps the applications table protected by RLS;
--    applicants only receive their new application id/number.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.mti_submit_public_application_v153(
  p_full_name text,
  p_email text,
  p_phone text,
  p_programme text,
  p_level text DEFAULT NULL,
  p_section text DEFAULT NULL,
  p_statement text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  application_no text,
  application_number text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  v_name text := trim(coalesce(p_full_name, ''));
  v_email text := lower(trim(coalesce(p_email, '')));
  v_phone text := trim(coalesce(p_phone, ''));
  v_programme text := trim(coalesce(p_programme, ''));
  v_level text := NULLIF(trim(coalesce(p_level, '')), '');
  v_section text := NULLIF(trim(coalesce(p_section, '')), '');
  v_statement text := NULLIF(trim(coalesce(p_statement, '')), '');
  v_id uuid;
  v_app_no text;
  v_app_number text;
  v_cols text[] := ARRAY['id'];
  v_vals text[] := ARRAY['gen_random_uuid()'];
  v_required text;
  v_default text;
  v_nullable text;
  v_exists boolean;
  v_generated text;
BEGIN
  IF length(v_name) < 3 THEN
    RAISE EXCEPTION 'Full name is required.';
  END IF;

  IF length(v_name) > 180 THEN
    RAISE EXCEPTION 'Full name is too long.';
  END IF;

  IF v_email !~* '^[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}$' THEN
    RAISE EXCEPTION 'Please provide a valid email address.';
  END IF;

  IF length(v_phone) < 7 THEN
    RAISE EXCEPTION 'A valid phone number is required.';
  END IF;

  IF v_programme = '' THEN
    RAISE EXCEPTION 'Please select a programme.';
  END IF;

  -- Basic duplicate/throttle protection. This prevents accidental repeated
  -- submissions while still allowing a genuine later application cycle.
  IF EXISTS (
    SELECT 1
    FROM public.applications a
    WHERE lower(coalesce(a.email, '')) = v_email
      AND a.created_at > now() - interval '10 minutes'
  ) THEN
    RAISE EXCEPTION 'An application using this email address was submitted recently. Please wait or contact MTI Admissions if you believe this is an error.';
  END IF;

  -- Required identity/application fields.
  FOREACH v_required IN ARRAY ARRAY[
    'full_name','email','phone','programme','level','section','statement','status','user_id'
  ] LOOP
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public'
        AND table_name='applications'
        AND column_name=v_required
    ) INTO v_exists;

    IF NOT v_exists THEN
      CONTINUE;
    END IF;

    SELECT is_nullable, column_default
      INTO v_nullable, v_default
    FROM information_schema.columns
    WHERE table_schema='public'
      AND table_name='applications'
      AND column_name=v_required;

    IF v_required='full_name' THEN
      v_cols:=array_append(v_cols,'full_name');
      v_vals:=array_append(v_vals,quote_nullable(v_name));
    ELSIF v_required='email' THEN
      v_cols:=array_append(v_cols,'email');
      v_vals:=array_append(v_vals,quote_nullable(v_email));
    ELSIF v_required='phone' THEN
      v_cols:=array_append(v_cols,'phone');
      v_vals:=array_append(v_vals,quote_nullable(v_phone));
    ELSIF v_required='programme' THEN
      v_cols:=array_append(v_cols,'programme');
      v_vals:=array_append(v_vals,quote_nullable(v_programme));
    ELSIF v_required='level' AND v_level IS NOT NULL THEN
      v_cols:=array_append(v_cols,'level');
      v_vals:=array_append(v_vals,quote_nullable(v_level));
    ELSIF v_required='section' AND v_section IS NOT NULL THEN
      v_cols:=array_append(v_cols,'section');
      v_vals:=array_append(v_vals,quote_nullable(v_section));
    ELSIF v_required='statement' AND v_statement IS NOT NULL THEN
      v_cols:=array_append(v_cols,'statement');
      v_vals:=array_append(v_vals,quote_nullable(v_statement));
    ELSIF v_required='status' THEN
      v_cols:=array_append(v_cols,'status');
      v_vals:=array_append(v_vals,quote_literal('submitted'));
    ELSIF v_required='user_id' AND v_nullable='YES' THEN
      v_cols:=array_append(v_cols,'user_id');
      v_vals:=array_append(v_vals,'NULL');
    END IF;
  END LOOP;

  -- If the installation requires an application number without a default,
  -- provide a collision-resistant number. Otherwise the table's existing
  -- default/sequence remains authoritative.
  SELECT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='applications'
      AND column_name='application_no'
  ) INTO v_exists;

  IF v_exists THEN
    SELECT column_default INTO v_default
    FROM information_schema.columns
    WHERE table_schema='public' AND table_name='applications'
      AND column_name='application_no';

    IF v_default IS NULL THEN
      v_generated := 'MTI/APP/' || to_char(now(),'YYYY') || '/' || upper(substr(encode(gen_random_bytes(6),'hex'),1,8));
      v_cols:=array_append(v_cols,'application_no');
      v_vals:=array_append(v_vals,quote_literal(v_generated));
    END IF;
  ELSE
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name='applications'
        AND column_name='application_number'
    ) INTO v_exists;

    IF v_exists THEN
      SELECT column_default INTO v_default
      FROM information_schema.columns
      WHERE table_schema='public' AND table_name='applications'
        AND column_name='application_number';

      IF v_default IS NULL THEN
        v_generated := 'MTI/APP/' || to_char(now(),'YYYY') || '/' || upper(substr(encode(gen_random_bytes(6),'hex'),1,8));
        v_cols:=array_append(v_cols,'application_number');
        v_vals:=array_append(v_vals,quote_literal(v_generated));
      END IF;
    END IF;
  END IF;

  -- Handle installations where timestamps have no defaults.
  FOREACH v_required IN ARRAY ARRAY['created_at','updated_at'] LOOP
    SELECT EXISTS (
      SELECT 1 FROM information_schema.columns
      WHERE table_schema='public' AND table_name='applications'
        AND column_name=v_required
    ) INTO v_exists;

    IF v_exists THEN
      SELECT column_default INTO v_default
      FROM information_schema.columns
      WHERE table_schema='public' AND table_name='applications'
        AND column_name=v_required;

      IF v_default IS NULL THEN
        v_cols:=array_append(v_cols,v_required);
        v_vals:=array_append(v_vals,'now()');
      END IF;
    END IF;
  END LOOP;

  EXECUTE
    'INSERT INTO public.applications (' || array_to_string(v_cols, ',') ||
    ') VALUES (' || array_to_string(v_vals, ',') ||
    ') RETURNING id'
  INTO v_id;

  -- Read whichever application-number column exists without hard-coding
  -- a reference that could fail on a slightly different installation.
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='applications'
      AND column_name='application_no'
  ) THEN
    EXECUTE 'SELECT application_no::text FROM public.applications WHERE id=$1'
      INTO v_app_no USING v_id;
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='applications'
      AND column_name='application_number'
  ) THEN
    EXECUTE 'SELECT application_number::text FROM public.applications WHERE id=$1'
      INTO v_app_number USING v_id;
  END IF;

  RETURN QUERY SELECT v_id, v_app_no, v_app_number;
END;
$function$;

REVOKE ALL
ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text)
FROM PUBLIC;

GRANT EXECUTE
ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text)
TO anon, authenticated;

COMMENT ON FUNCTION public.mti_submit_public_application_v153(text,text,text,text,text,text,text)
IS 'Public MTI admission submission. Creates an application only; does not create an Auth account or Student Portal account. Admission and activation are handled separately.';

NOTIFY pgrst, 'reload schema';
NOTIFY pgrst, 'reload config';

COMMIT;
