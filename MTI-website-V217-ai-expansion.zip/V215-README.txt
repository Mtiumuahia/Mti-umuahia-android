MTI WEBSITE V215 — AI ASSISTANT HARDENING

What changed
- Kept the working V213 live approved-content architecture and existing Supabase structures.
- Added server-side response cleanup so AI answers never return asterisks (*) including Markdown-style ** or *** emphasis.
- Added a matching frontend cleanup as a defense-in-depth fallback before assistant text is displayed.
- Updated the AI instructions to request plain text only, with hyphen bullets instead of star bullets or Markdown emphasis.
- Removed unnecessary internal row IDs from the live public-content context sent to the model. Public page content remains the source; private portal/application/payment/result data is still excluded.
- No new Supabase table, bucket, policy, RPC, or SQL migration was created.

Security and boundaries
- OPENAI_API_KEY remains server-side in the Netlify Function.
- The browser calls only /.netlify/functions/mti-assistant.
- Private student, applicant, payment, result, credential, and management records are not queried by the AI retrieval layer.
- If information is not confirmed by approved knowledge or live public content, the assistant must say so rather than inventing it.

Testing performed
- node --check passed for all JavaScript and module files.
- ZIP integrity checked with unzip -t.
- Local asset/reference audit performed against the deployment package.

SQL
NO SQL MIGRATION REQUIRED FOR V215.
