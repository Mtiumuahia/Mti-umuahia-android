# MTI Android V318 — Professional UI System

V318 is based directly on the working V317 baseline.

## Scope
- Adds a shared native MTI visual layer across existing activities.
- Applies polished rounded controls, professional form fields, elevation, institutional green styling, touch feedback, and screen entrance motion.
- Applies the visual layer to public content, community, student, lecturer, AI, management and existing native screens without replacing their data architecture.
- Preserves the existing Supabase, portal, community, admissions and AI architecture.
- Preserves reduced-motion support already present in the app.
- No destructive database migration is included.

## Version
- versionCode: 318
- versionName: 10.4.0

Final Android compilation remains delegated to the existing GitHub Actions workflow because this project archive does not contain a Gradle wrapper.
