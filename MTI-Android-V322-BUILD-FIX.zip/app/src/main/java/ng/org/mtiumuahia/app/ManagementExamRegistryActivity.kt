package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.widget.*

class ManagementExamRegistryActivity : MtiBaseActivity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val ink=Color.rgb(23,53,44); private val gold=Color.rgb(184,149,74)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(Color.WHITE);setBackgroundColor(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    override fun onCreate(b:Bundle?){super.onCreate(b);show()}
    private fun show(){
        val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(20))}
        r.addView(text("MTI · UMUAHIA",12f,gold,true));r.addView(text("Examination Number Registry",28f,ink,true))
        r.addView(text("This management module preserves the existing MTI examination-number registry as the authoritative workspace. No new examination-number table, numbering algorithm, or RPC is introduced without confirmed backend architecture."))
        r.addView(text("EXAMINATION NUMBER ADMINISTRATION",12f,gold,true))
        r.addView(text("Use the existing authenticated management workspace to view and administer examination-number records. This avoids creating duplicate numbering data or bypassing existing RLS and institutional controls."))
        r.addView(button("Open Examination Number Registry"){openWeb("/exam-number-registry")})
        r.addView(button("Open Management Command Centre"){openWeb("/management-dashboard")})
        r.addView(button("Back"){finish()})
        setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})
    }
    private fun openWeb(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
