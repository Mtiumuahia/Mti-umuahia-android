package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementCommunicationsActivity: MtiBaseActivity(){
    private val cream=Color.rgb(248,245,236); private val green=Color.rgb(18,67,48); private val ink=Color.rgb(28,37,33); private val gold=Color.rgb(166,132,48)
    private val base by lazy{getString(R.string.supabase_url).trimEnd('/')}; private val token by lazy{intent.getStringExtra("access_token").orEmpty()}; private val executor=Executors.newSingleThreadExecutor()
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun t(s:String,sp:Float=14f,c:Int=ink,b:Boolean=false)=TextView(this).apply{text=s;textSize=sp;setTextColor(c);setPadding(0,dp(6),0,dp(6));if(b) typeface=android.graphics.Typeface.DEFAULT_BOLD}
    private fun b(s:String,action:()->Unit)=Button(this).apply{text=s;setTextColor(Color.WHITE);setBackgroundColor(green);setPadding(dp(12),dp(5),dp(12),dp(5));setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(7),0,dp(7))}}
    private fun card(title:String,body:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10));setBackgroundColor(Color.WHITE);addView(t(title,16f,green,true));addView(t(body,13f,ink));layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun web(path:String){startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    private fun get(path:String):String{val c=(URL(base+path).openConnection() as HttpURLConnection);c.requestMethod="GET";c.setRequestProperty("apikey",getString(R.string.supabase_anon_key));c.setRequestProperty("Authorization","Bearer $token");c.connectTimeout=12000;c.readTimeout=12000;return c.inputStream.bufferedReader().use{it.readText()}}
    override fun onDestroy(){executor.shutdownNow();super.onDestroy()}
    override fun onCreate(state:Bundle?){super.onCreate(state)
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(22))}
        root.addView(t("OFFICIAL COMMUNICATIONS",12f,gold,true));root.addView(t("Institutional Communications",28f,ink,true))
        root.addView(t("Live read-only monitoring of the existing MTI announcement architecture. Publishing and privileged edits remain in the authoritative management workspace."))
        root.addView(t("CURRENT NOTICE ACTIVITY",13f,gold,true));val stats=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(stats);stats.addView(t("Loading current notices…"))
        root.addView(t("RECENT OFFICIAL NOTICES",17f,green,true));val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(list)
        root.addView(b("Open Management Communications Workspace"){web("/management-dashboard")})
        root.addView(b("Open Student Notice Board"){web("/student-portal#notices")})
        root.addView(b("Open Lecturer Notice Board"){web("/lecturer-portal#notices")})
        root.addView(b("Back"){finish()})
        setContentView(ScrollView(this).apply{isFillViewport=true;addView(root)})
        executor.execute{try{val arr=JSONArray(get("/rest/v1/portal_announcements?select=*&order=created_at.desc&limit=50"));runOnUiThread{stats.removeAllViews();stats.addView(card("Published notice records","${arr.length()} record${if(arr.length()==1)"" else "s"} returned from the existing portal_announcements source."));list.removeAllViews();if(arr.length()==0)list.addView(card("No current notices","No announcement records were returned."));for(i in 0 until minOf(arr.length(),15)){val x=arr.getJSONObject(i);val title=x.optString("title").ifBlank{"MTI Notice"};val body=x.optString("body").ifBlank{x.optString("content").ifBlank{"No notice content supplied."}};val created=x.optString("created_at").ifBlank{"Date not supplied"};list.addView(card(title,created+"\n\n"+body))}}}catch(e:Exception){runOnUiThread{stats.removeAllViews();stats.addView(card("Notice monitoring unavailable","The existing authorised notice source could not be read. Use the full Management Communications workspace for complete records."));list.removeAllViews();list.addView(card("Unable to load notices",e.message?:"Request failed"))}}}
    }
}
