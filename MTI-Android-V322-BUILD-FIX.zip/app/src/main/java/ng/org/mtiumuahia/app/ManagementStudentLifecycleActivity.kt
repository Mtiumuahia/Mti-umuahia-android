package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.widget.*
import android.content.res.ColorStateList

class ManagementStudentLifecycleActivity : MtiBaseActivity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun card(h:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));addView(text(h,16f,green,true));addView(text(b,13f,ink));layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun open(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    override fun onCreate(b:Bundle?){super.onCreate(b);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(20))};r.addView(text("MANAGEMENT · STUDENT LIFECYCLE",12f,gold,true));r.addView(text("Student Lifecycle & Registry",28f,ink,true));r.addView(text("A controlled management hub for the student's institutional journey—from onboarding and registry records through academic progress, services and completion. It deliberately reuses MTI's existing authoritative workspaces rather than creating a second lifecycle database."));r.addView(card("01 · Admission & Onboarding","Admission decisions and activation remain under the existing admission/activation workflow."));r.addView(button("Open Admission Activation & Onboarding"){open("/management-dashboard#admission-control")});r.addView(card("02 · Student Registry","Use the existing Student Registry as the authoritative institutional profile and registry workspace."));r.addView(button("Open Student Registry"){open("/student-registry")});r.addView(card("03 · Academic Progress","Existing course registration, results, attendance, schedule and transcript systems remain the source of truth."));r.addView(button("Open Academic Administration"){open("/academic-administration")});r.addView(button("Open Official Transcript"){open("/official-transcript")});r.addView(card("04 · Student Services","Hostel, fees, payments, notices and other student-service records continue through their existing secured workspaces."));r.addView(button("Open Hostel & Student Services"){open("/hostel-centre")});r.addView(button("Open Finance & Payment Administration"){open("/finance-dashboard")});r.addView(card("Lifecycle integrity","No new student-status table, lifecycle RPC, role, service account or privileged bypass was introduced in V266."));r.addView(button("Open Management Command Centre"){open("/management-dashboard")});setContentView(ScrollView(this).apply{addView(r)})}
}
