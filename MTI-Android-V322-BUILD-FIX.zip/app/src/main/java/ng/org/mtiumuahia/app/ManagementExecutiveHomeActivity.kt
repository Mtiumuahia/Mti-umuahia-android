package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList

class ManagementExecutiveHomeActivity : MtiBaseActivity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private var token:String?=null
    override fun onCreate(b:Bundle?){super.onCreate(b);token=intent.getStringExtra("access_token");show()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,c:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{c()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun web(path:String)=startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))
    private fun native(c:Class<*>)=startActivity(Intent(this,c).apply{putExtra("access_token",token)})
    private fun show(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(18))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}
        root.addView(text("METHODIST THEOLOGICAL INSTITUTE · UMUAHIA",12f,gold,true));root.addView(text("Executive Quick Actions",28f,ink,true));root.addView(text("A focused starting point for recurring management operations. These actions open the existing MTI workspaces; they do not create a second administrative system."))
        root.addView(text("ADMISSIONS",12f,gold,true));root.addView(button("Review Applicants"){native(ManagementApplicantSelectionActivity::class.java)});root.addView(button("Admission Activation & Onboarding"){native(ManagementAdmissionActivationActivity::class.java)})
        root.addView(text("ACADEMIC",12f,gold,true));root.addView(button("Course Administration"){native(ManagementAcademicActivity::class.java)});root.addView(button("Results Review"){native(ManagementResultReviewActivity::class.java)});root.addView(button("Attendance Monitoring"){native(ManagementAttendanceMonitoringActivity::class.java)})
        root.addView(text("FINANCE & SERVICES",12f,gold,true));root.addView(button("Finance & Payments"){native(ManagementFinanceActivity::class.java)});root.addView(button("Hostel & Student Services"){native(ManagementHostelActivity::class.java)})
        root.addView(text("DIGITAL LEARNING",12f,gold,true));root.addView(button("Online Classroom"){native(ManagementOnlineClassroomActivity::class.java)});root.addView(button("Learning Materials"){native(ManagementLearningMaterialsActivity::class.java)})
        root.addView(text("INSTITUTIONAL CONTROL",12f,gold,true));root.addView(button("Notifications & Operational Alerts"){native(ManagementNotificationsActivity::class.java)});root.addView(button("Institutional Reporting"){native(ManagementReportingActivity::class.java)});root.addView(button("Audit & Security"){native(ManagementSecurityActivity::class.java)})
        root.addView(text("AUTHORITATIVE WEB",12f,gold,true));root.addView(button("Full Management Command Centre"){web("/management-dashboard")});root.addView(button("Management Communications"){web("/management-dashboard")})
        root.addView(text("Architecture note: existing Supabase Auth, RLS, roles, RPCs and management workspaces remain authoritative. No new database layer is introduced by this screen.",12f,ink))
        setContentView(scroll)
    }
}
