package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*

class ManagementSearchActivity : MtiBaseActivity() {
    private val green = Color.rgb(16, 63, 45)
    private val cream = Color.rgb(248, 244, 234)
    private val gold = Color.rgb(170, 132, 45)
    private val white = Color.WHITE
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String, size:Float=15f, color:Int=Color.DKGRAY)=TextView(this).apply{this.text=s;setTextSize(size);setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6))}
    private fun button(s:String, action:()->Unit)=Button(this).apply{text=s;setTextColor(white);setBackgroundColor(green);setOnClickListener{action()};isAllCaps=false}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(24));setBackgroundColor(cream)}
    private fun label(s:String)=text(s,12f,gold).apply{setPadding(0,dp(12),0,dp(5))}
    private fun title(s:String)=text(s,27f,green).apply{setTypeface(null,android.graphics.Typeface.BOLD);setPadding(0,dp(4),0,dp(8))}
    override fun onCreate(b:Bundle?){super.onCreate(b);show()}
    private fun show(){
        val r=root(); r.addView(label("MANAGEMENT NAVIGATION")); r.addView(title("Search & Workspace Finder"))
        r.addView(text("Find an existing management workspace quickly. This finder searches the Android workspace catalogue and opens the authoritative existing module; it does not create a second database search layer."))
        val input=EditText(this).apply{hint="Search admissions, students, finance, results…";setSingleLine(true);setPadding(dp(12),0,dp(12),0)}
        r.addView(input,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(10),0,dp(10))})
        val results=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        r.addView(results)
        val items=listOf(
            "Admissions & Applicants" to "/admissions-administration",
            "Student Registry" to "/student-registry",
            "Academic Administration" to "/academic-administration",
            "Teaching Load Management" to "/teaching-load",
            "Result Review" to "/result-review",
            "Finance & Payment Administration" to "/finance-dashboard",
            "Hostel & Student Services" to "/hostel-centre",
            "Learning Materials" to "/lecturer-materials",
            "Online Classroom" to "/online-classroom",
            "Communications & Notices" to "/management-dashboard",
            "SUG Executives Management" to "/sug-executives-management",
            "Examination Number Registry" to "/exam-number-registry",
            "Management Command Centre" to "/management-dashboard"
        )
        fun render(q:String){results.removeAllViews();items.filter{q.isBlank()||it.first.contains(q,true)}.forEach{(name,path)->results.addView(button(name){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))},LinearLayout.LayoutParams(-1,dp(52)).apply{setMargins(0,dp(3),0,dp(3))})}; if(results.childCount==0)results.addView(text("No matching management workspace."))}
        input.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(s?.toString()?.trim()?:(""))};override fun afterTextChanged(e:android.text.Editable?) {}})
        render("")
        r.addView(button("Back"){finish()})
        setContentView(r)
    }
}
