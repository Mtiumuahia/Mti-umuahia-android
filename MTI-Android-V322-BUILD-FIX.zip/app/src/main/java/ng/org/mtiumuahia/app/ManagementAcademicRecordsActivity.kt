package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class ManagementAcademicRecordsActivity : MtiBaseActivity() {
    private val executor=Executors.newFixedThreadPool(2)
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"; private val supabaseKey="sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken:String?=null
    private val students=mutableListOf<JSONObject>(); private val results=mutableListOf<JSONObject>(); private val courses=mutableListOf<JSONObject>()
    private var query=""
    override fun onCreate(b:Bundle?){super.onCreate(b);accessToken=intent.getStringExtra("access_token");show()}
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(14),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun card(h:String,b:String,click:(()->Unit)?=null)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(11),dp(14),dp(11));addView(text(h,16f,green,true));addView(text(b,13f,ink));if(click!=null){setOnClickListener{click()};isClickable=true}}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";c.connectTimeout=12000;c.readTimeout=18000;c.setRequestProperty("apikey",supabaseKey);c.setRequestProperty("Authorization","Bearer ${accessToken ?: ""}");c.setRequestProperty("Accept","application/json");val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception("Authorised request failed (HTTP $code)");return body}
    private fun show(){
        val r=root();r.addView(label("MANAGEMENT · ACADEMIC RECORDS"));r.addView(title("Student Academic Records"));r.addView(text("Read-only management view of existing student profiles and published academic results. Transcript generation and result changes remain governed by the existing MTI web workflows and database permissions."))
        r.addView(button("Open Official Transcript Workspace"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/official-transcript")))})
        val search=EditText(this).apply{hint="Search name, MTI registration number, programme or email…";isSingleLine=true;setTextColor(ink)};r.addView(search,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,dp(4))})
        val summary=text("Loading academic records…",13f);r.addView(summary);val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(list);setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){query=s?.toString()?.trim()?.lowercase() ?: "";render(list,summary)};override fun afterTextChanged(e:android.text.Editable?) {}})
        executor.execute{try{val ss=JSONArray(get("/rest/v1/student_profiles?select=*&limit=5000"));val rr=JSONArray(get("/rest/v1/student_results?select=*&status=eq.published&limit=10000"));val cc=JSONArray(get("/rest/v1/academic_courses?select=id,course_code,course_title,credit_load&limit=3000"));students.clear();results.clear();courses.clear();for(i in 0 until ss.length())students.add(ss.getJSONObject(i));for(i in 0 until rr.length())results.add(rr.getJSONObject(i));for(i in 0 until cc.length())courses.add(cc.getJSONObject(i));runOnUiThread{render(list,summary)}}catch(x:Exception){runOnUiThread{summary.text="Academic records could not be loaded. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}";list.removeAllViews();list.addView(card("Academic records unavailable","Use the full Student Registry or Official Transcript workspace."))}}}
    }
    private fun render(list:LinearLayout,summary:TextView){list.removeAllViews();val shown=students.filter{s->val hay=listOf(s.optString("first_name"),s.optString("middle_name"),s.optString("last_name"),s.optString("full_name"),s.optString("student_number"),s.optString("programme"),s.optString("email")).joinToString(" ").lowercase();query.isBlank()||hay.contains(query)};summary.text="${students.size} students · ${results.size} published result records · showing ${shown.size}";if(shown.isEmpty()){list.addView(card("No matching students","Try another search."));return};shown.take(250).forEach{s->val ids=setOf(s.optString("id"),s.optString("user_id")).filter{it.isNotBlank()};val mine=results.filter{ids.contains(it.optString("student_id"))||ids.contains(it.optString("user_id"))};val credits=mine.sumOf{it.optDouble("credit_load",courseFor(it).optDouble("credit_load",0.0))};val avg=mine.mapNotNull{it.optString("score").toDoubleOrNull()}.let{if(it.isEmpty())null else it.average()};val name=listOf(s.optString("first_name"),s.optString("middle_name"),s.optString("last_name")).filter{it.isNotBlank()}.joinToString(" ").ifBlank{s.optString("full_name").ifBlank{"Student"}};val reg=s.optString("student_number").ifBlank{"No registration number"};val meta="${mine.size} published result${if(mine.size==1)"" else "s"} · ${if(avg==null)"Average score —" else "Average score %.2f".format(avg)} · Credits %.1f".format(credits);list.addView(card(name,"$reg\n$meta\n${s.optString("programme")}" ){openStudentTranscript(s)})};if(shown.size>250)list.addView(card("Showing first 250 students","Use search to narrow the registry."))}
    private fun courseFor(o:JSONObject):JSONObject=courses.firstOrNull{it.optString("id")==o.optString("course_id")}?:JSONObject()
    private fun openStudentTranscript(s:JSONObject){val number=s.optString("student_number");val url=getString(R.string.mti_base_url).trimEnd()+"/official-transcript"+(if(number.isNotBlank())"?student="+URLEncoder.encode(number,"UTF-8") else "");startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}
}
