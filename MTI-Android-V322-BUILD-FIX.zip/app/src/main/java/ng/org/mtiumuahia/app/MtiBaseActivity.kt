package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Shared MTI visual layer. It styles existing native screens without changing their data or navigation architecture. */
open class MtiBaseActivity : Activity() {
    private val green = Color.rgb(11, 61, 46)
    private val deep = Color.rgb(5, 37, 28)
    private val cream = Color.rgb(247, 244, 237)
    private val gold = Color.rgb(190, 157, 82)
    private val ink = Color.rgb(25, 45, 39)
    private val border = Color.rgb(220, 216, 205)

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = deep
        window.navigationBarColor = deep
        window.decorView.systemUiVisibility = 0
    }

    override fun setContentView(view: View?) {
        if (view == null) return
        super.setContentView(view)
        applyVisualSystem(view)
    }

    override fun setContentView(view: View?, params: ViewGroup.LayoutParams?) {
        if (view == null) return
        super.setContentView(view, params)
        applyVisualSystem(view)
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        val contentRoot = findViewById<ViewGroup>(android.R.id.content)
        if (contentRoot.childCount > 0) applyVisualSystem(contentRoot.getChildAt(0))
    }

    private fun applyVisualSystem(root: View) {
        root.setBackgroundIfPlain()
        styleTree(root)
        if (Settings.Global.getFloat(contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) != 0f) {
            root.alpha = 0f
            root.translationY = 10f
            root.animate().alpha(1f).translationY(0f).setDuration(280L)
                .setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun styleTree(v: View) {
        if (v is LinearLayout) styleContainer(v)
        when (v) {
            is Button -> styleButton(v)
            is EditText -> styleEditText(v)
            is TextView -> {
                if (v.typeface == null) v.typeface = Typeface.create("sans", Typeface.NORMAL)
            }
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) styleTree(v.getChildAt(i))
        }
    }


    private fun styleContainer(v: LinearLayout) {
        val bg = v.background
        if (bg is ColorDrawable && bg.color == Color.WHITE) {
            v.background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(16).toFloat()
                setStroke(dp(1), border)
            }
            v.elevation = dp(2).toFloat()
        }
    }

    private fun styleButton(v: Button) {
        v.isAllCaps = false
        v.textSize = if (v.textSize / resources.displayMetrics.scaledDensity < 13f) 13f else 14f
        v.typeface = Typeface.create("sans", Typeface.BOLD)
        v.setTextColor(Color.WHITE)
        v.minHeight = dp(50)
        v.minimumHeight = dp(50)
        v.setPadding(dp(16), dp(5), dp(16), dp(5))
        v.background = GradientDrawable().apply {
            setColor(green)
            cornerRadius = dp(15).toFloat()
            setStroke(dp(1), Color.argb(45, 255, 255, 255))
        }
        v.backgroundTintList = null
        v.elevation = dp(2).toFloat()
        v.stateListAnimator = null
        v.setOnTouchListener { view, event ->
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> view.animate().scaleX(.985f).scaleY(.985f).setDuration(70).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> view.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            }
            false
        }
    }

    private fun styleEditText(v: EditText) {
        v.setTextColor(ink)
        v.setHintTextColor(Color.rgb(125, 133, 128))
        v.textSize = 15f
        v.setPadding(dp(16), dp(8), dp(16), dp(8))
        v.background = GradientDrawable().apply {
            setColor(Color.WHITE)
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), border)
        }
        v.elevation = dp(1).toFloat()
    }

    private fun View.setBackgroundIfPlain() {
        if (background == null) setBackgroundColor(cream)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
