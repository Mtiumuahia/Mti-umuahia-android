package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Html
import android.text.method.LinkMovementMethod
import android.view.View
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class PublicContentActivity : MtiBaseActivity() {
    private val cream = Color.rgb(247, 244, 237)
    private val green = Color.rgb(11, 61, 46)
    private val deep = Color.rgb(5, 37, 28)
    private val gold = Color.rgb(190, 157, 82)
    private val ink = Color.rgb(25, 45, 39)
    private val muted = Color.rgb(91, 105, 99)
    private val white = Color.WHITE
    private val supa = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val key = "sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private lateinit var root: LinearLayout
    private val exec = Executors.newFixedThreadPool(4)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(s: String, n: Float, c: Int = ink, b: Boolean = false) = TextView(this).apply {
        text = s
        textSize = n
        setTextColor(c)
        typeface = if (b) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setLineSpacing(0f, 1.22f)
    }
    private fun cardBg(c: Int = white) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.rgb(229, 225, 216))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        build()
        load(intent.getStringExtra("type") ?: "about")
    }

    private fun build() {
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cream) }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(16), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(deep, green))
        }
        top.addView(TextView(this).apply {
            text = "‹"; textSize = 34f; setTextColor(white); gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(46), dp(48)))
        top.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("MTI · UMUAHIA", 10f, gold, true))
            addView(tv("Explore MTI", 18f, white, true).apply { setPadding(0, dp(2), 0, 0) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(top)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(32))
        }
        shell.addView(ScrollView(this).apply { isFillViewport = true; addView(root) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(shell)
    }

    private fun load(type: String) {
        root.removeAllViews()
        root.addView(tv(kicker(type), 11f, gold, true))
        root.addView(tv(title(type), 30f, ink, true).apply { setPadding(0, dp(5), 0, dp(8)) })
        root.addView(tv(intro(type), 15f, muted).apply { setPadding(0, 0, 0, dp(18)) })

        if (type in listOf("news", "events", "gallery", "leadership", "programmes", "sug")) {
            val loading = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = cardBg()
            }
            loading.addView(tv("Loading MTI content…", 16f, green, true))
            loading.addView(tv("Retrieving approved public information from the MTI service.", 13.5f, muted).apply { setPadding(0, dp(5), 0, 0) })
            root.addView(loading)
            exec.execute {
                try {
                    val data = fetch(type)
                    runOnUiThread { render(type, data); animateContent() }
                } catch (e: Exception) {
                    runOnUiThread { renderError(type, e) }
                }
            }
        } else { renderStatic(type); animateContent() }
    }

    private fun kicker(t: String) = when (t) {
        "about" -> "THE INSTITUTE"
        "governance" -> "GOVERNANCE & OVERSIGHT"
        "admissions" -> "ADMISSIONS"
        "contact" -> "VISIT MTI"
        "campus" -> "CAMPUS & COMMUNITY"
        else -> "MTI PUBLIC INFORMATION"
    }
    private fun title(t: String) = when (t) {
        "about" -> "About MTI"; "governance" -> "Governance"; "programmes" -> "Programmes"
        "admissions" -> "Admissions"; "news" -> "News & Updates"; "events" -> "Events"
        "gallery" -> "Gallery"; "leadership" -> "Leadership"; "sug" -> "Student Leadership"
        "contact" -> "Visit & Contact"; "campus" -> "Campus Life"; else -> "MTI"
    }
    private fun intro(t: String) = when (t) {
        "about" -> "A theological institution shaped by Christian faith, academic formation, spiritual growth and service."
        "governance" -> "The leadership and institutional standards that support MTI's academic, spiritual and administrative life."
        "programmes" -> "Explore the academic pathways currently published by the Institute, from undergraduate formation to advanced theological and executive study."
        "admissions" -> "Understand the MTI application and Selection Conference journey, then continue to the official website when you are ready to apply."
        "news" -> "Read published MTI stories, announcements and institutional updates."
        "events" -> "Keep up with Institute activities, services, ceremonies and community events."
        "gallery" -> "A visual record of MTI community life, ministry, learning and institutional moments."
        "leadership" -> "Meet the people currently presented as MTI leadership through the Institute's public content."
        "sug" -> "Meet the Student Union Government executives serving the MTI student community."
        "campus" -> "Discover the worship, learning, formation, fellowship and service that shape life at MTI."
        else -> "Methodist Theological Institute, Mission Hill, Umuahia, Abia State, Nigeria."
    }

    private fun renderStatic(t: String) {
        when (t) {
            "about" -> {
                section("A BRIEF HISTORY", "Methodist Theological Institute, Umuahia traces its institutional story to 1956 and has grown as a centre for Christian theological education, ministerial formation and service. Across the decades, the Institute has prepared students for faithful ministry through study, worship, practical formation and life in Christian community.")
                section("FAITH · FORMATION · SCHOLARSHIP", "MTI brings together theological learning, spiritual formation and practical ministry preparation, serving the Methodist Church and the wider body of Christ.")
            }
            "governance" -> {
                personCard("Rector", "Very Rev. Kingsley Raphael Nwaike Ph.D.", "Institute leadership")
                personCard("Registrar", "Very Rev. Washington Okpara", "Registry and institutional administration")
                section("INSTITUTIONAL STANDARD", "MTI's academic, spiritual and administrative life is supported by recognised leadership, responsible stewardship, academic integrity and respectful community conduct.")
            }
            "campus" -> {
                section("FORMATION HAPPENS IN COMMUNITY", "Theological education is not only about what is taught. It is also about the people we become through worship, study, fellowship, reflection and service.")
                section("ACADEMIC SPACES", "An environment shaped for lectures, discussion, theological reflection and serious study.")
                section("WORSHIP & FORMATION", "Prayer, worship, spiritual formation and Christian community remain central to Institute life.")
                section("LEARNING & RESEARCH", "Library, digital learning and research resources support students as they grow in knowledge and ministry readiness.")
                section("PRACTICAL MINISTRY", "MTI connects theological learning with the realities of Christian service, leadership and mission.")
                section("COMMUNITY LIFE", "Students, faculty and staff learn together, build relationships and serve one another as part of the wider MTI family.")
            }
            "admissions" -> {
                section("APPLY TO MTI", "Start your application on the official MTI website. The application is submitted online, while the next stages of selection and admission follow the Institute's approved process.")
                val apply = Button(this).apply {
                    text = "Apply on the MTI website"
                    isAllCaps = false
                    textSize = 14f
                    setTextColor(white)
                    backgroundTintList = android.content.res.ColorStateList.valueOf(green)
                    setPadding(dp(18), dp(6), dp(18), dp(6))
                    setOnClickListener { openWebsite("/apply-now") }
                }
                root.addView(apply, LinearLayout.LayoutParams(-1, dp(54)).apply { setMargins(0, dp(7), 0, dp(8)) })
            }
            "contact" -> {
                personCard("Address", "Methodist Theological Institute, Mission Hill, Umuahia, Abia State, Nigeria", "Campus location")
                section("VISIT", "For an official visit, confirm the current office schedule and visitor arrangements with MTI before travelling.")
            }
        }
    }

    private fun openWebsite(path: String) {
        val base = getString(R.string.mti_base_url).trimEnd('/')
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(base + path)))
    }

    private fun section(label: String, body: String) {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(17), dp(18), dp(17)); background = cardBg()
        }
        b.addView(tv(label, 11f, gold, true))
        b.addView(tv(body, 16f, ink).apply { setPadding(0, dp(8), 0, 0) })
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) })
    }

    private fun personCard(role: String, name: String, detail: String) {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(17), dp(18), dp(17)); background = cardBg()
        }
        b.addView(tv(role, 11f, gold, true))
        b.addView(tv(name, 21f, green, true).apply { setPadding(0, dp(6), 0, dp(3)) })
        b.addView(tv(detail, 13.5f, muted))
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) })
    }

    private fun fetch(t: String): JSONArray {
        val path = when (t) {
            "news" -> "news?select=*&published=eq.true&order=published_at.desc,created_at.desc&limit=30"
            "events" -> "events?select=*&order=starts_at.desc,created_at.desc&limit=30"
            "gallery" -> "gallery_photos?select=*&order=created_at.desc&limit=60"
            "leadership" -> "leadership?select=*&order=sort_order.asc,created_at.asc&limit=30"
            "programmes" -> "programmes?select=*&order=created_at.desc&limit=50"
            "sug" -> "sug_executives_v142?select=*&active=eq.true&order=display_order.asc,full_name.asc&limit=50"
            else -> throw Exception("Unsupported content section")
        }
        val c = URL("$supa/rest/v1/$path").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.setRequestProperty("apikey", key)
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Accept", "application/json")
        c.connectTimeout = 12000; c.readTimeout = 15000
        val code = c.responseCode
        val input = if (code in 200..299) c.inputStream else c.errorStream
        val body = input?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) throw Exception("HTTP $code${parseError(body)}")
        return JSONArray(body)
    }

    private fun parseError(body: String): String = try {
        val o = JSONObject(body)
        val msg = o.optString("message").ifBlank { o.optString("hint") }
        if (msg.isBlank()) "" else ": ${msg.take(160)}"
    } catch (_: Exception) { "" }

    private fun renderError(t: String, e: Exception) {
        if (root.childCount > 3) root.removeViewAt(root.childCount - 1)
        val b = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(19), dp(19), dp(19), dp(19)); background = cardBg() }
        b.addView(tv("This MTI section is temporarily unavailable", 19f, green, true))
        b.addView(tv("The app reached the MTI content service, but the request was not completed. You can try again without leaving the app.", 14f, muted).apply { setPadding(0, dp(8), 0, dp(14)) })
        b.addView(Button(this).apply {
            text = "Try again"; isAllCaps = false; setTextColor(white)
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener { load(t) }
        })
        root.addView(b)
    }

    private fun render(t: String, a: JSONArray) {
        if (root.childCount > 3) root.removeViewAt(root.childCount - 1)
        if (a.length() == 0) {
            if (t == "programmes") { renderProgrammeFallback(); return }
            section("NO PUBLISHED CONTENT", "There is currently no published information in this section.")
            return
        }
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            when (t) {
                "news" -> newsCard(o)
                "events" -> eventCard(o)
                "gallery" -> galleryCard(o)
                "leadership" -> leadershipCard(o)
                "programmes" -> programmeCard(o)
                "sug" -> sugCard(o)
            }
        }
    }

    private fun baseCard() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(17), dp(18), dp(17)); background = cardBg() }
    private fun addCard(b: LinearLayout) { root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) }) }
    private fun value(o: JSONObject, vararg names: String): String {
        for (n in names) { val v = o.optString(n).trim(); if (v.isNotBlank() && v != "null") return v }
        return ""
    }

    private fun newsCard(o: JSONObject) {
        val b = baseCard()
        val image = value(o, "featured_image_url", "cover_image_url", "image_url", "photo_url", "thumbnail_url")
        if (image.isNotBlank()) addRemoteImage(b, resolveMediaUrl(image), value(o, "title").ifBlank { "MTI News" }, 190)
        b.addView(tv(value(o, "category", "section", "type").ifBlank { "MTI NEWS" }.uppercase(), 10.5f, gold, true))
        b.addView(tv(value(o, "title").ifBlank { "MTI News" }, 21f, green, true).apply { setPadding(0, dp(6), 0, 0) })
        val date = value(o, "published_at", "created_at")
        if (date.isNotBlank()) b.addView(tv(formatDate(date), 11f, muted, true).apply { setPadding(0, dp(6), 0, 0) })
        val body = value(o, "excerpt", "summary", "body", "content", "description")
        if (body.isNotBlank()) b.addView(tv(stripHtml(body).take(220).let { if (body.length > 220) "$it…" else it }, 14.5f, ink).apply { setPadding(0, dp(9), 0, 0) })
        b.addView(tv("Read full article  ›", 13.5f, green, true).apply { setPadding(0, dp(13), 0, 0) })
        b.isClickable = true
        b.isFocusable = true
        b.setOnClickListener { openNewsArticle(o) }
        b.animate().alpha(1f).setDuration(260L).start()
        addCard(b)
    }

    private fun openNewsArticle(o: JSONObject) {
        startActivity(Intent(this, NewsArticleActivity::class.java).putExtra("news_json", o.toString()))
    }

    private fun stripHtml(text: String): String = Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY).toString().replace("\u00a0", " ").trim()

    private fun formatDate(raw: String): String {
        return raw.replace("T", " ").replace("Z", "").take(16)
    }

    private fun eventCard(o: JSONObject) {
        val b = baseCard(); b.addView(tv(value(o, "title").ifBlank { "MTI Event" }, 19f, green, true))
        val whenText = value(o, "starts_at", "start_date", "event_date"); if (whenText.isNotBlank()) b.addView(tv(whenText.replace("T", " ").take(16), 11f, gold, true).apply { setPadding(0, dp(5), 0, 0) })
        val loc = value(o, "location", "venue"); if (loc.isNotBlank()) b.addView(tv(loc, 13.5f, green, true).apply { setPadding(0, dp(7), 0, 0) })
        val body = value(o, "description", "details", "body"); if (body.isNotBlank()) b.addView(tv(body, 15f, ink).apply { setPadding(0, dp(8), 0, 0) }); addCard(b)
    }

    private fun programmeCard(o: JSONObject) {
        val b = baseCard(); b.addView(tv(value(o, "name", "title", "programme", "program_name").ifBlank { "MTI Programme" }, 20f, green, true))
        val duration = value(o, "duration", "length"); if (duration.isNotBlank()) b.addView(tv(duration, 12f, gold, true).apply { setPadding(0, dp(5), 0, 0) })
        val body = value(o, "description", "overview", "details"); if (body.isNotBlank()) b.addView(tv(body, 15f, ink).apply { setPadding(0, dp(8), 0, 0) }); addCard(b)
    }

    private fun leadershipCard(o: JSONObject) {
        val b = baseCard()
        val image = value(o, "photo_url", "image_url", "photo")
        if (image.isNotBlank()) addRemoteImage(b, resolveMediaUrl(image), value(o, "name", "full_name").ifBlank { "MTI leader" }, 230)
        b.addView(tv(value(o, "role", "office", "position").ifBlank { "MTI Leadership" }, 11f, gold, true))
        b.addView(tv(value(o, "name", "full_name").ifBlank { "MTI Leader" }, 20f, green, true).apply { setPadding(0, dp(6), 0, 0) })
        val bio = value(o, "bio", "biography", "description"); if (bio.isNotBlank()) b.addView(tv(bio, 15f, ink).apply { setPadding(0, dp(8), 0, 0) }); addCard(b)
    }

    private fun sugCard(o: JSONObject) {
        val b = baseCard()
        val image = value(o, "photo_url", "image_url", "photo")
        if (image.isNotBlank()) addRemoteImage(b, resolveMediaUrl(image), value(o, "full_name", "name").ifBlank { "MTI Student Leader" }, 210)
        b.addView(tv(value(o, "office", "position").ifBlank { "SUG Executive" }, 11f, gold, true))
        b.addView(tv(value(o, "full_name", "name").ifBlank { "MTI Student Leader" }, 20f, green, true).apply { setPadding(0, dp(6), 0, dp(3)) })
        val bio = value(o, "biography", "bio", "description"); if (bio.isNotBlank()) b.addView(tv(bio, 14.5f, ink)); addCard(b)
    }

    private fun galleryCard(o: JSONObject) {
        val b = baseCard()
        val image = resolveGalleryUrl(value(o, "image_url", "photo_url", "media_url", "url", "file_url"))
        if (image.isNotBlank()) addRemoteImage(b, image, value(o, "title", "caption").ifBlank { "MTI gallery image" }, 230)
        b.addView(tv(value(o, "title", "caption").ifBlank { "MTI Community" }, 17f, green, true).apply { setPadding(0, dp(9), 0, dp(2)) })
        val cat = value(o, "category", "album"); if (cat.isNotBlank()) b.addView(tv(cat, 12f, gold, true)); addCard(b)
    }

    private fun addRemoteImage(parent: LinearLayout, rawUrl: String, description: String, height: Int) {
        val iv = ImageView(this).apply {
            adjustViewBounds = true; scaleType = ImageView.ScaleType.CENTER_CROP; contentDescription = description
            setBackgroundColor(Color.rgb(231, 228, 219))
        }
        parent.addView(iv, LinearLayout.LayoutParams(-1, dp(height)).apply { setMargins(0, 0, 0, dp(10)) })
        exec.execute {
            try {
                val url = URL(rawUrl)
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 15000; c.instanceFollowRedirects = true
                val bmp = if (c.responseCode in 200..299) c.inputStream.use { BitmapFactory.decodeStream(it) } else null
                c.disconnect()
                if (bmp != null) runOnUiThread { iv.setImageBitmap(bmp); iv.alpha = 0f; iv.animate().alpha(1f).setDuration(360L).start() }
            } catch (_: Exception) { }
        }
    }

    private fun resolveMediaUrl(raw: String): String {
        if (raw.isBlank()) return ""
        if (raw.startsWith("http://") || raw.startsWith("https://")) return raw
        return try {
            if (raw.startsWith("/")) "$supa$raw" else raw
        } catch (_: Exception) { raw }
    }

    private fun resolveGalleryUrl(raw: String): String {
        if (raw.isBlank()) return ""
        val cleaned = raw.trim()
        if (cleaned.startsWith("http://") || cleaned.startsWith("https://")) {
            // Supabase storage URLs may contain spaces encoded as '+', which is form encoding
            // and is not reliable for a URL path. Normalise the known MTI gallery bucket.
            return cleaned.replace("Mti+Umuahia+Gallery", "Mti%20Umuahia%20Gallery")
                .replace("Mti%20Umuahia%20Gallery", "Mti%20Umuahia%20Gallery")
        }
        var path = cleaned.removePrefix("/")
        val marker = "storage/v1/object/public/"
        val markerIndex = path.indexOf(marker)
        if (markerIndex >= 0) {
            val publicPath = path.substring(markerIndex + marker.length)
            val slash = publicPath.indexOf('/')
            if (slash >= 0) {
                val bucket = publicPath.substring(0, slash).replace("+", "%20").replace(" ", "%20")
                val objectPath = publicPath.substring(slash + 1).split('/').joinToString("/") {
                    java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20")
                }
                return "$supa/storage/v1/object/public/$bucket/$objectPath"
            }
        }
        // Gallery records commonly store only the object path. Use the authoritative public bucket.
        path = path.removePrefix("Mti Umuahia Gallery/").removePrefix("Mti%20Umuahia%20Gallery/")
        val encodedPath = path.split('/').joinToString("/") {
            java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20")
        }
        return "$supa/storage/v1/object/public/Mti%20Umuahia%20Gallery/$encodedPath"
    }

    private fun renderProgrammeFallback() {
        section("AFFILIATION NOTE", "Following the approval of the Nigerian Universities Commission (NUC) for Wesley University Ondo to run B.A. Theology, MTI Umuahia moved its affiliation to Wesley University Ondo by directive of the Church.")
        programmeFallbackCard("UNDERGRADUATE", "Bachelor-level theological formation", "100–400 Level", "Biblical studies, Christian theology, ethics, church history, evangelism, homiletics, pastoral theology, church administration, ministry practicum and a final-year project.")
        programmeFallbackCard("POSTGRADUATE", "Postgraduate Diploma in Ministry / Master of Divinity", "Core ministerial formation", "Christian spirituality, Old and New Testament studies, church history, worship, preaching, systematic theology, leadership, ministerial ethics, pastoral care, Wesleyan studies, mission, Christian education and ministry practice.")
        programmeFallbackCard("ADVANCED THEOLOGICAL STUDY", "Master of Theology (M.Th)", "Wesley University Ondo", "Tracks include Biblical Studies, Wesleyan Studies, Practical Theology, Mission / Evangelism and Systematic Theology, with general courses including Research Methodology, Theology on Modern Africa and Interfaith Relations / Ecumenism.")
        programmeFallbackCard("DOCTORAL MINISTRY", "Doctor of Ministry (D.Min)", "Ministry-focused doctoral study", "Areas published by MTI include Social Development, Pastoral Counselling, Spiritual Formation and Discipleship, Intergenerational Ministries, and Preaching and Worship.")
        programmeFallbackCard("DISTANT E-LEARNING", "Flexible and professional pathways", "Conversion, PGDE and executive study", "Published pathways include Conversion Programmes, Postgraduate Diploma in Education, professional postgraduate programmes, and College of Education, Arts, and Social and Management Sciences offerings.")
        programmeFallbackCard("EXECUTIVE & CERTIFICATE", "Executive Diploma in Theology", "Lay and ordained Christian formation", "Certificate opportunities include Church Leadership, Youth Ministry, Entrepreneurship, Women Ministry and Children's Training, alongside Executive Diploma in Theology courses.")
    }

    private fun programmeFallbackCard(label: String, name: String, meta: String, body: String) {
        val b = baseCard()
        b.addView(tv(label, 11f, gold, true))
        b.addView(tv(name, 20f, green, true).apply { setPadding(0, dp(6), 0, dp(3)) })
        b.addView(tv(meta, 12f, gold, true))
        b.addView(tv(body, 15f, ink).apply { setPadding(0, dp(9), 0, 0) })
        addCard(b)
    }

    private fun animateContent() {
        if (android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) return
        for (i in 0 until root.childCount) {
            val child = root.getChildAt(i)
            child.alpha = 0f
            child.translationY = dp(18).toFloat()
            child.scaleX = .985f
            child.scaleY = .985f
            child.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setStartDelay((i * 55L).coerceAtMost(500L)).setDuration(420L)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
    }

    override fun onDestroy() { exec.shutdownNow(); super.onDestroy() }
}
