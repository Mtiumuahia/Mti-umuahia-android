package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList

class ManagementStudentServicesActivity : MtiBaseActivity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44)
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun t(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun b(s:String,action:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(Color.WHITE);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun web(path:String){startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    override fun onCreate(state:Bundle?){super.onCreate(state);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(20))};r.addView(t("STUDENT SERVICES",12f,gold,true));r.addView(t("Student Services & Welfare",28f,ink,true));r.addView(t("Management access to student-service workflows that are already established in the MTI web portal. This release does not invent a welfare/disciplinary schema where the audited backend does not expose one."));r.addView(t("Available institutional services",17f,green,true));r.addView(t("• Student registry and biodata\n• Hostel and allocation services\n• Fees and payment administration\n• Academic administration\n• Notices and institutional communication\n• Other approved management workspaces"));r.addView(b("Open Student Registry"){web("/student-registry")});r.addView(b("Open Management Command Centre"){web("/management-dashboard")});r.addView(b("Open Hostel & Student Services"){web("/hostel")});r.addView(b("Back"){finish()});setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})}
}
