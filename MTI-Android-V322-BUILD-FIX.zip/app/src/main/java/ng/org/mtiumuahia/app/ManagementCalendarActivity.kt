package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList

class ManagementCalendarActivity : MtiBaseActivity() {
    private val green = Color.rgb(18,72,54)
    private val cream = Color.rgb(248,245,237)
    private val gold = Color.rgb(183,145,62)
    private val ink = Color.rgb(35,42,39)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); show() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(24));setBackgroundColor(cream)}
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(16),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun card(head:String,body:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));addView(text(head,16f,green,true));addView(text(body,13f,ink))}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun set(r:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})}
    private fun show(){
        val r=root()
        r.addView(label("MANAGEMENT · ACADEMIC PLANNING"))
        r.addView(title("Academic Calendar & Scheduling"))
        r.addView(text("A secure Android access point for MTI's existing academic planning and scheduling workspaces."))
        r.addView(card("Audit result","The existing project contains academic course and class-schedule structures, but the audited SQL does not establish a dedicated institutional academic-calendar table or calendar-management RPC. This screen therefore does not create one or guess its schema."))
        r.addView(label("EXISTING AUTHORITATIVE WORKSPACES"))
        r.addView(button("Academic Administration"){openWeb("/academic-administration")})
        r.addView(button("Student Class Schedule"){openWeb("/student-portal")})
        r.addView(button("Full Management Command Centre"){openWeb("/management-dashboard")})
        r.addView(label("CURRENT ARCHITECTURE"))
        r.addView(card("Academic courses","The existing academic_courses catalogue remains the source for course planning and lecturer assignment."))
        r.addView(card("Class timetable","The existing academic_class_schedule data is already consumed by the authenticated student portal for active class schedules."))
        r.addView(card("No duplicate calendar layer","No new calendar table, RPC, role, service-role credential, or parallel scheduling engine was introduced in V257."))
        r.addView(button("Back"){finish()})
        set(r)
    }
    private fun openWeb(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
