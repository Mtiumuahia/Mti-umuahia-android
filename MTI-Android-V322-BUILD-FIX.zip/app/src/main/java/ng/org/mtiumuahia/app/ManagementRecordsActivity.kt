package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class ManagementRecordsActivity : MtiBaseActivity() {
    private val cream=Color.rgb(246,241,230); private val ink=Color.rgb(23,53,44); private val gold=Color.rgb(184,149,74)
    private fun t(s:String,size:Float=14f,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(ink);setPadding(8,8,8,8);if(bold)setTypeface(null,1)}
    private fun btn(s:String,a:()->Unit)=Button(this).apply{text=s;isAllCaps=false;setOnClickListener{a()}}
    private fun card(h:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.WHITE);setPadding(16,14,16,14);addView(t(h,16f,true));addView(t(b))}
    override fun onCreate(b:Bundle?){super.onCreate(b);show()}
    private fun show(){
        val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(16,14,16,20)}
        r.addView(t("MTI · UMUAHIA",12f,true));r.addView(t("Document & Records Administration",27f,true))
        r.addView(t("A controlled management hub for official institutional records. It reuses the MTI workspaces and storage structures already established in the project rather than inventing a second document database."))
        r.addView(card("Admissions & applicant records","Application information and required-document workflow remain governed by the existing Admissions Administration and Selection workspaces."))
        r.addView(btn("Open Admissions Administration"){web("/admissions-administration")})
        r.addView(card("Student academic records","Student profiles, results, registration and transcript records remain governed by their existing secured academic workspaces."))
        r.addView(btn("Open Student Registry"){web("/student-registry")})
        r.addView(btn("Open Official Transcript"){web("/official-transcript")})
        r.addView(card("Learning resources","Lecturer materials and published digital-library resources continue to use the existing lecturer-materials/storage architecture."))
        r.addView(btn("Open Learning Materials"){web("/learning-materials")})
        r.addView(btn("Open Digital Library"){web("/library")})
        r.addView(card("Finance & payment records","Invoices, payment evidence and receipts remain in the existing finance/payment workspaces and storage policies."))
        r.addView(btn("Open Finance Dashboard"){web("/finance-dashboard")})
        r.addView(card("Architecture boundary","The audit of V268 did not establish a single generic institutional document table or a universal document-management RPC. V269 therefore does not fabricate one, expose private files, or create new storage buckets."))
        r.addView(t("SECURITY",12f,true).apply{setTextColor(gold)})
        r.addView(t("Management access continues to use the authenticated Supabase session and existing RLS/management authorization."))
        r.addView(btn("Open Management Command Centre"){web("/management-dashboard")})
        r.addView(btn("Back"){finish()});setContentView(ScrollView(this).apply{addView(r)})
    }
    private fun web(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
