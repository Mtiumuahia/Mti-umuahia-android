package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.content.res.ColorStateList
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class ManagementAttendanceMonitoringActivity : MtiBaseActivity() {
    private val executor=Executors.newFixedThreadPool(2)
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"; private val supabaseKey="sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken:String?=null
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun card(h:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));addView(text(h,16f,green,true));addView(text(b,13f,ink))}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun set(r:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Content-Type" to "application/json")
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";headers().forEach{(k,v)->c.setRequestProperty(k,v)};val code=c.responseCode;val body=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return body}
    private fun parseError(b:String)=try{val j=JSONObject(b);j.optString("message").ifBlank{j.optString("msg").ifBlank{"Request failed"}}}catch(_:Exception){"Request failed"}
    override fun onCreate(b:Bundle?){super.onCreate(b);accessToken=intent.getStringExtra("access_token");show()}
    private fun show(){
        val r=root();r.addView(text("METHODIST THEOLOGICAL INSTITUTE · UMUAHIA",12f,gold,true));r.addView(text("Student Attendance & Academic Monitoring",27f,ink,true));r.addView(text("Management-facing, read-only monitoring of attendance records already entered through the MTI academic attendance system."))
        r.addView(card("Existing academic source","Attendance uses the existing student_attendance_v123 records and the established lecturer attendance workflow. This screen does not create a new attendance table, policy, RPC or grading rule."))
        val status=text("Loading attendance records…",13f,ink);r.addView(status)
        val summary=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(summary)
        val search=EditText(this).apply{hint="Search student, course code/title or status";setSingleLine(true)};r.addView(search)
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(content)
        r.addView(button("Refresh Attendance"){load(status,summary,content,search.text.toString())})
        r.addView(button("Open Full Management Command Centre"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/management-dashboard")))})
        r.addView(button("Open Lecturer Attendance Workspace"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/lecturer-portal#attendance")))})
        r.addView(text("Monitoring only: attendance is recorded by authorised academic staff through the existing lecturer workflow. No new threshold for academic standing is imposed by this Android screen."))
        set(r);load(status,summary,content,"")
    }
    private fun load(status:TextView,summary:LinearLayout,content:LinearLayout,query:String){status.text="Loading attendance records…";executor.execute{try{
        val data=JSONArray(get("/rest/v1/student_attendance_v123?select=*&order=attendance_date.desc,created_at.desc&limit=5000"))
        val students=JSONArray(get("/rest/v1/student_profiles?select=id,first_name,middle_name,last_name,student_number&limit=5000"))
        val courses=JSONArray(get("/rest/v1/academic_courses?select=id,course_code,course_title&limit=2000"))
        val sm=HashMap<String,String>();for(i in 0 until students.length()){val x=students.getJSONObject(i);sm[x.optString("id")]=listOf(x.optString("first_name"),x.optString("middle_name"),x.optString("last_name")).filter{it.isNotBlank()}.joinToString(" ")+" · "+x.optString("student_number")}
        val cm=HashMap<String,String>();for(i in 0 until courses.length()){val x=courses.getJSONObject(i);cm[x.optString("id")]=x.optString("course_code")+" · "+x.optString("course_title")}
        val q=query.trim().lowercase();val rows=mutableListOf<JSONObject>();for(i in 0 until data.length()){val x=data.getJSONObject(i);val sid=x.optString("student_id");val cid=x.optString("course_id");val hay=(sm[sid].orEmpty()+" "+cm[cid].orEmpty()+" "+x.optString("course_code")+" "+x.optString("course_title")+" "+x.optString("status")+" "+x.optString("semester")+" "+x.optString("academic_session")+" "+x.optString("session")).lowercase();if(q.isBlank()||hay.contains(q))rows.add(x)}
        val counts=HashMap<String,Int>();rows.forEach{x->val s=x.optString("status").ifBlank{"Unknown"};counts[s]=counts.getOrDefault(s,0)+1}
        runOnUiThread{summary.removeAllViews();summary.addView(card("Records","${rows.size} matching attendance record${if(rows.size==1)"" else "s"}"));summary.addView(card("Status totals",counts.entries.sortedBy{it.key}.joinToString(" · "){it.key+": "+it.value}));content.removeAllViews();if(rows.isEmpty())content.addView(card("No matching records","Try a broader search or confirm that attendance has been entered for the selected period.")) else rows.take(200).forEach{x->val sid=x.optString("student_id");val cid=x.optString("course_id");val date=x.optString("attendance_date").ifBlank{x.optString("class_date")};val course=cm[cid].orEmpty().ifBlank{x.optString("course_code")+" · "+x.optString("course_title")};var body=(sm[sid].orEmpty().ifBlank{"Student ID: $sid"})+"\n"+course+"\n$date · "+x.optString("status").ifBlank{"Status unavailable"}+"\n"+listOf(x.optString("academic_session"),x.optString("session"),x.optString("semester")).firstOrNull{it.isNotBlank()}.orEmpty();if(x.optString("note").isNotBlank())body+="\nNote: "+x.optString("note");content.addView(card("Attendance record",body))};status.text="Loaded ${data.length()} records; showing ${rows.size} matching records."}
    }catch(x:Exception){runOnUiThread{status.text="Attendance monitoring could not load from the existing authorised data source.";summary.removeAllViews();content.removeAllViews();content.addView(card("Open the authoritative workspace","Request failed. Please use the authoritative MTI workspace if the problem persists."));content.addView(text("The app does not bypass RLS or create a service-role path. If management read access is not exposed for this table, use the existing MTI web management/lecturer workspace."))}}}
    }
}
