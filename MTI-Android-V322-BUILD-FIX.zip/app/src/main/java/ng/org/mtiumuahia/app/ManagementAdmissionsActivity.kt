package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementAdmissionsActivity : MtiBaseActivity() {
    private val executor = Executors.newFixedThreadPool(2)
    private val green = Color.rgb(11,61,46); private val cream = Color.rgb(246,241,230)
    private val gold = Color.rgb(184,149,74); private val ink = Color.rgb(23,53,44); private val white = Color.WHITE
    private val supabaseUrl = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabaseKey = "sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken: String? = null
    private val records = mutableListOf<JSONObject>()
    private var filter = "all"
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); accessToken = intent.getStringExtra("access_token"); showAdmissions() }
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(14),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun card(head:String,body:String,click:(()->Unit)?=null)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(11),dp(14),dp(11));addView(text(head,16f,green,true));addView(text(body,13f,ink));if(click!=null){setOnClickListener{click()};isClickable=true}}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun set(r:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Accept" to "application/json")
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";c.connectTimeout=12000;c.readTimeout=18000;headers().forEach{(k,v)->c.setRequestProperty(k,v)};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception("Authorised request failed (HTTP $code)");return body}

    private fun showAdmissions(){
        val r=root();r.addView(label("MANAGEMENT · ADMISSIONS"));r.addView(title("Admissions Administration"));r.addView(text("Authorised management view of existing MTI admission applications. This Android screen is read-only: admission decisions, tokens and other complex workflows remain on the existing management website."))
        r.addView(button("Open Full Admissions Administration"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/admissions-administration")))})
        val search=EditText(this).apply{hint="Search applicant, email, application number…";isSingleLine=true;setTextColor(ink)};r.addView(search,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,dp(4))})
        val spinner=Spinner(this);spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,arrayOf("All applications","Submitted","Pending","Admitted","Rejected","Other"));r.addView(spinner)
        val status=text("Loading admission applications…",13f,ink);r.addView(status)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(list)
        fun refresh(){query=search.text.toString().trim().lowercase();filter=spinner.selectedItem.toString();render(list)}
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){query=s?.toString()?.trim()?.lowercase() ?: "";render(list)};override fun afterTextChanged(e:android.text.Editable?) {}})
        spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){filter=spinner.selectedItem.toString();render(list)}}
        set(r)
        executor.execute{try{val a=JSONArray(get("/rest/v1/applications?select=*&order=created_at.desc&limit=500"));records.clear();for(i in 0 until a.length())records.add(a.getJSONObject(i));runOnUiThread{status.text="${records.size} application record${if(records.size==1)"" else "s"} loaded from the existing applications table.";render(list)}}catch(x:Exception){runOnUiThread{status.text="Applications could not be loaded from the authorised data source. Open the full management workspace for the complete workflow.";list.removeAllViews();list.addView(card("Admissions workspace","${"Request failed. Please use the authoritative MTI workspace if the problem persists."}\n\nThe app has not created or modified any admission data."))}}}
    }

    private fun render(list:LinearLayout){list.removeAllViews();val shown=records.filter{matches(it)};if(shown.isEmpty()){list.addView(card("No matching applications","Try another status or search term."));return};shown.forEachIndexed{idx,obj->
        val name=first(obj,"full_name","name").ifBlank{listOf(first(obj,"first_name"),first(obj,"middle_name"),first(obj,"last_name")).filter{it.isNotBlank()}.joinToString(" ")}.ifBlank{"Applicant ${idx+1}"}
        val appNo=first(obj,"application_number","application_no","application_id","id")
        val status=first(obj,"status","application_status").ifBlank{"Unknown"}
        val mode=first(obj,"p_level","entry_mode","level","programme","program")
        val body=listOf(appNo, status, mode).filter{it.isNotBlank()}.joinToString(" · ")
        list.addView(card(name,body){showDetail(obj)})
    }}
    private fun matches(o:JSONObject):Boolean{val s=first(o,"status","application_status").lowercase();val f=filter.lowercase();val statusOk=when(f){"all applications"->true;"submitted"->s=="submitted";"pending"->s.contains("pending");"admitted"->s.contains("admit");"rejected"->s.contains("reject");else->true};if(!statusOk)return false;if(query.isBlank())return true;return o.toString().lowercase().contains(query)}
    private fun first(o:JSONObject,vararg keys:String):String{for(k in keys){if(o.has(k)&&!o.isNull(k)){val v=o.optString(k).trim();if(v.isNotBlank())return v}};return ""}
    private fun showDetail(o:JSONObject){val r=root();r.addView(label("APPLICATION RECORD"));r.addView(title(first(o,"full_name","name").ifBlank{"Applicant details"}));r.addView(text("Read-only record from the existing MTI applications data source."));o.keys().asSequence().toList().sorted().forEach{k->val v=o.opt(k);if(v!=JSONObject.NULL&&v.toString().isNotBlank())r.addView(card(k.replace('_',' ').replaceFirstChar{it.uppercase()},v.toString()))};r.addView(label("ADMINISTRATION"));r.addView(text("For admission decisions, assessment, applicant communication, registration-number/token issuance, or other privileged actions, use the existing authorised management admissions workspace."));r.addView(button("Open Full Admissions Administration"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/admissions-administration"))) });r.addView(button("Back to Applications"){showAdmissions()});set(r)}
}
