package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*

class ManagementHelpActivity : MtiBaseActivity() {
    private val green = 0xFF0B3D2E.toInt()
    private val cream = 0xFFF7F3EA.toInt()
    private fun label(t:String)=TextView(this).apply{text=t;setTextColor(green);textSize=12f;setTypeface(null,Typeface.BOLD);setPadding(0,18,0,8)}
    private fun button(t:String, action:()->Unit)=Button(this).apply{text=t;setOnClickListener{action()};isAllCaps=false}
    override fun onCreate(b:Bundle?){super.onCreate(b)
        val s=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,24,28,28);setBackgroundColor(cream)}
        s.addView(TextView(this).apply{text="Management Help & Support";textSize=25f;setTextColor(green);setTypeface(null,Typeface.BOLD)})
        s.addView(TextView(this).apply{text="Guidance for using the MTI management app and reaching the authoritative institutional workspaces.";textSize=15f;setTextColor(green);setPadding(0,8,0,12)})
        s.addView(label("QUICK GUIDANCE"))
        s.addView(TextView(this).apply{text="Use the native screens for verified monitoring and navigation. For privileged workflows that remain web-authoritative, use the linked Management Command Centre or the relevant institutional workspace. Never share your password, activation token, or access token.";textSize=14f;setTextColor(green);setPadding(0,0,0,10)})
        s.addView(label("SUPPORT"))
        s.addView(button("Technical Support") { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:godslovedigitalconcerpts@gmail.com")).putExtra(Intent.EXTRA_SUBJECT,"MTI Management App Technical Support")) })
        s.addView(button("Management Command Centre") { openWeb("/management-dashboard") })
        s.addView(button("Admissions Administration") { openWeb("/admissions-administration") })
        s.addView(button("Finance & Payment Administration") { openWeb("/finance-dashboard") })
        s.addView(label("SECURITY"))
        s.addView(TextView(this).apply{text="If you suspect unauthorized access, sign out immediately and contact MTI management/technical support through the established institutional channels. This screen does not create or store an institutional support ticket.";textSize=14f;setTextColor(green)})
        s.addView(button("Back to Management Portal") { finish() })
        setContentView(ScrollView(this).apply{addView(s)})
    }
    private fun openWeb(path:String){
        val base=getString(R.string.base_url).trimEnd('/')
        startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(base+path)))
    }
}
