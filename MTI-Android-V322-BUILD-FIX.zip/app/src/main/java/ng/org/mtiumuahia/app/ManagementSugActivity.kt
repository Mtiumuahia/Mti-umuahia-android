package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.View
import android.widget.*

class ManagementSugActivity : MtiBaseActivity() {
    private val green = Color.rgb(20,67,52)
    private val ink = Color.rgb(28,38,34)
    private val cream = Color.rgb(248,245,237)
    private val gold = Color.rgb(176,145,72)
    override fun onCreate(b: Bundle?) { super.onCreate(b); build() }
    private fun build() {
        val scroll=ScrollView(this); val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,34,28,40);setBackgroundColor(cream)}
        r.addView(text("MTI · UMUAHIA",12f,gold,true)); r.addView(text("SUG & Student Leadership",28f,ink,true))
        r.addView(text("Management access to the existing Student Union Government executive records and publishing workflow. The Android app does not create a second SUG database or replace the authoritative MTI management workspace.",15f,Color.DKGRAY,false))
        r.addView(label("EXISTING SUG ARCHITECTURE"))
        r.addView(text("The public SUG directory already reads the established sug_executives_v142 structure. Management changes, executive records and photo uploads remain in the existing authorised web workspace.",14f,ink,false))
        r.addView(button("Open SUG Executives Management") { open("/sug-executives-management") })
        r.addView(button("Open Public SUG Directory") { open("/sug-executives") })
        r.addView(button("Open Management Command Centre") { open("/management-dashboard") })
        r.addView(label("SECURITY"))
        r.addView(text("This screen passes through the already-authenticated management session. No service-role key, new role, new RPC, or new SUG permission model is introduced.",14f,ink,false))
        scroll.addView(r);setContentView(scroll)
    }
    private fun open(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    private fun label(s:String)=text(s,12f,gold,true)
    private fun text(s:String,size:Float,color:Int,bold:Boolean)=TextView(this).apply{this.text=s;textSize=size;setTextColor(color);if(bold)typeface=android.graphics.Typeface.DEFAULT_BOLD;setPadding(0,12,0,12)}
    private fun button(s:String,action:()->Unit)=Button(this).apply{text=s;setTextColor(Color.WHITE);setBackgroundColor(green);setPadding(18,8,18,8);setOnClickListener{action()};layoutParams=LinearLayout.LayoutParams(-1,58).apply{setMargins(0,8,0,8)}}
}
