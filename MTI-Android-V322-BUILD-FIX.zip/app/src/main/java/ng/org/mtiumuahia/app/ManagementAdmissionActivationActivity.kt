package ng.org.mtiumuahia.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*

class ManagementAdmissionActivationActivity : MtiBaseActivity() {
    private val green=Color.rgb(20,70,52); private val cream=Color.rgb(248,245,236); private val ink=Color.rgb(31,42,37); private val gold=Color.rgb(177,143,72)
    private lateinit var rootBox: LinearLayout
    override fun onCreate(b:Bundle?){super.onCreate(b); showHome()}
    private fun showHome(){
        rootBox=LinearLayout(this); rootBox.orientation=LinearLayout.VERTICAL; rootBox.setPadding(34,42,34,34); rootBox.setBackgroundColor(cream)
        rootBox.addView(label("MANAGEMENT · ONBOARDING")); rootBox.addView(title("Admission Activation & Student Onboarding"))
        rootBox.addView(text("Secure management hub for the final transition from an admitted applicant to an MTI Student Portal account."))
        rootBox.addView(card("Existing MTI workflow","After MTI admits an applicant, the authorised management workflow issues the student's MTI registration number and one-time activation token. The admitted student then uses those credentials to activate the Student Portal and set a password."))
        rootBox.addView(card("Security boundary","This Android screen does not generate, expose, or duplicate activation tokens. It routes privileged token issuance and admission-status changes to the existing authoritative management workspace."))
        rootBox.addView(button("Open Admission Activation Workspace"){openWeb("/admissions-administration")})
        rootBox.addView(button("Open Management Command Centre"){openWeb("/management-dashboard")})
        rootBox.addView(button("Open Student Portal Activation"){openWeb("/student-portal")})
        setContentView(scroll(rootBox))
    }
    private fun openWeb(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    private fun scroll(v:android.view.View):ScrollView{val s=ScrollView(this);s.addView(v,ViewGroup.LayoutParams(-1,-2));return s}
    private fun label(t:String):TextView{return text(t,12f,gold,true)}
    private fun title(t:String):TextView{return text(t,27f,green,true)}
    private fun text(t:String,size:Float=14f,c:Int=ink,bold:Boolean=false):TextView{val v=TextView(this);v.text=t;v.textSize=size;v.setTextColor(c);v.setTypeface(null,if(bold)1 else 0);v.setPadding(0,10,0,16);return v}
    private fun card(h:String,b:String):TextView{val v=text("$h\n$b",14f,ink,false);v.setPadding(20,18,20,18);v.setBackgroundColor(Color.WHITE);val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,10,0,10);v.layoutParams=lp;return v}
    private fun button(t:String,click:()->Unit):Button{val v=Button(this);v.text=t;v.setTextColor(Color.WHITE);v.setBackgroundColor(green);v.setOnClickListener{click()};val lp=LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,8,0,8);v.layoutParams=lp;return v}
}
