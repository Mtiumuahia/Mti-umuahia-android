package ng.org.mtiumuahia.app

import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

/** V277: local app preferences only; no institutional/backend settings are changed. */
class ManagementSettingsActivity : MtiBaseActivity() {
    private val prefs by lazy { getSharedPreferences("mti_management_ui", Context.MODE_PRIVATE) }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(t:String,size:Float=15f)=TextView(this).apply{ text=t; textSize=size; setPadding(dp(4),dp(8),dp(4),dp(8)) }
    private fun button(t:String, action:()->Unit)=Button(this).apply{ text=t; setOnClickListener{action()} }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); title="App Settings"; show()}
    private fun show(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(24));gravity=Gravity.TOP}
        root.addView(text("MTI MANAGEMENT APP",12f));root.addView(text("Settings, appearance & accessibility",24f));root.addView(text("These controls affect this device only. They do not change institutional records, Supabase permissions, roles or management settings."))
        val motion=Switch(this).apply{text="Reduce interface motion";isChecked=prefs.getBoolean("reduce_motion",false);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("reduce_motion",v).apply()}}
        root.addView(motion);root.addView(text("Use this preference as a local accessibility signal. Existing screens continue to respect Android reduced-motion settings where implemented."))
        val large=Switch(this).apply{text="Prefer larger text";isChecked=prefs.getBoolean("large_text",false);setOnCheckedChangeListener{_,v->prefs.edit().putBoolean("large_text",v).apply();Toast.makeText(this@ManagementSettingsActivity,"Preference saved. Android system font size remains authoritative.",Toast.LENGTH_SHORT).show()}}
        root.addView(large)
        root.addView(text("For full accessibility, use Android Settings → Display & accessibility. The MTI app does not override the device's system accessibility configuration."))
        root.addView(button("Reset local app preferences"){prefs.edit().clear().apply();Toast.makeText(this,"Local preferences reset",Toast.LENGTH_SHORT).show();show()})
        root.addView(button("Back to Management Portal"){finish()})
        setContentView(root)
    }
}
