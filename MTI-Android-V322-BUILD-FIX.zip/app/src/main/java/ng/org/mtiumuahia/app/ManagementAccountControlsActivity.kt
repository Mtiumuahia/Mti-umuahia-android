package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList

class ManagementAccountControlsActivity : MtiBaseActivity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private var token:String?=null; private var email:String?=null; private var userId:String?=null
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(16),dp(4),dp(5))}
    private fun button(s:String,c:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{c()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    override fun onCreate(b:Bundle?){super.onCreate(b);token=intent.getStringExtra("access_token");email=intent.getStringExtra("email");userId=intent.getStringExtra("user_id");show()}
    private fun show(){
        val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(18))}
        r.addView(label("MANAGEMENT · ACCOUNT & SESSION"));r.addView(text("Secure Account Controls",27f,ink,true));r.addView(text("Review the current authenticated management session and manage local app conveniences without changing institutional roles or backend permissions."))
        r.addView(label("CURRENT SESSION"));r.addView(text("Management account\n${email?.ifBlank{"Authenticated management user"} ?: "Authenticated management user"}\n\nUser ID\n${userId?.ifBlank{"Available to the authenticated session"} ?: "Available to the authenticated session"}\n\nAccess token\nHeld in the current activity session only."))
        r.addView(label("LOCAL APP CONTROLS"));r.addView(button("Clear Recent Workspace History"){
            getSharedPreferences("management_workspace_launcher",MODE_PRIVATE).edit().remove("recent").apply();Toast.makeText(this,"Recent workspace history cleared on this device.",Toast.LENGTH_SHORT).show()
        })
        r.addView(button("Open Management Command Centre") { startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/management-dashboard"))) })
        r.addView(label("SECURITY BOUNDARY"));r.addView(text("This app does not create management accounts, change portal roles, expose service-role credentials, or invent a second password/permission system. Supabase Auth and the existing management role/RLS controls remain authoritative."))
        r.addView(label("END SESSION"));r.addView(button("Sign Out of Management Portal") { token=null; val i=Intent(this,ManagementPortalActivity::class.java);i.flags=Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP;startActivity(i);finish() })
        setContentView(ScrollView(this).apply{isFillViewport=true;addView(r)})
    }
}
