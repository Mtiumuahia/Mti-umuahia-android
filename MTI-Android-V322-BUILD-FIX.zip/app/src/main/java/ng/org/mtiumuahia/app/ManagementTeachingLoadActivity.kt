package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class ManagementTeachingLoadActivity : MtiBaseActivity() {
    private val executor=Executors.newFixedThreadPool(2)
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"; private val supabaseKey="sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken:String?=null
    private val lecturers=mutableListOf<JSONObject>(); private val courses=mutableListOf<JSONObject>(); private val assignments=mutableListOf<JSONObject>()
    private var query=""; private var activeOnly=true
    override fun onCreate(b:Bundle?){super.onCreate(b);accessToken=intent.getStringExtra("access_token");show()}
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(6),dp(4),dp(6));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(14),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(48);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(48)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun card(h:String,b:String,click:(()->Unit)?=null)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(11),dp(14),dp(11));addView(text(h,16f,green,true));addView(text(b,13f,ink));if(click!=null){setOnClickListener{click()};isClickable=true}}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun set(v:View){setContentView(ScrollView(this).apply{isFillViewport=true;addView(v)})}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Content-Type" to "application/json","Accept" to "application/json","Prefer" to "return=representation")
    private fun request(method:String,path:String,payload:String?=null):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod=method;c.connectTimeout=12000;c.readTimeout=18000;headers().forEach{(k,v)->c.setRequestProperty(k,v)};if(payload!=null){c.doOutput=true;c.outputStream.use{it.write(payload.toByteArray())}};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception("Authorised request failed (HTTP $code)");return body}
    private fun show(){
        val r=root();r.addView(label("MANAGEMENT · ACADEMICS"));r.addView(title("Teaching Load & Lecturer Assignments"));r.addView(text("Assign existing academic courses to existing lecturer profiles using the current lecturer_courses architecture. No new database objects are introduced."))
        r.addView(button("Open Full Teaching Load Workspace"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/teaching-load")))})
        val search=EditText(this).apply{hint="Search lecturer, staff number, course code or title…";isSingleLine=true;setTextColor(ink)};r.addView(search,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,dp(4))})
        val toggle=Switch(this).apply{text="Show active assignments only";isChecked=true;setTextColor(ink);setOnCheckedChangeListener{_,v->activeOnly=v;render()}};r.addView(toggle)
        val status=text("Loading teaching load…",13f);r.addView(status)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(list)
        r.addView(button("Assign Course to Lecturer"){showAssignmentEditor()})
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){query=s?.toString()?.trim()?.lowercase() ?: "";render()};override fun afterTextChanged(e:android.text.Editable?) {}})
        set(r)
        executor.execute{try{val l=JSONArray(request("GET","/rest/v1/lecturer_profiles?select=*&order=staff_no.asc&limit=2000"));val c=JSONArray(request("GET","/rest/v1/academic_courses?select=*&active=eq.true&order=course_code.asc&limit=2000"));val a=JSONArray(request("GET","/rest/v1/lecturer_courses?select=*&order=created_at.desc&limit=5000"));lecturers.clear();courses.clear();assignments.clear();for(i in 0 until l.length())lecturers.add(l.getJSONObject(i));for(i in 0 until c.length())courses.add(c.getJSONObject(i));for(i in 0 until a.length())assignments.add(a.getJSONObject(i));runOnUiThread{status.text="${assignments.size} assignment record${if(assignments.size==1)"" else "s"} · ${lecturers.size} lecturers · ${courses.size} active courses";render()}}catch(x:Exception){runOnUiThread{status.text="Teaching load could not be loaded. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}";list.removeAllViews();list.addView(card("Teaching load unavailable","Open the full Teaching Load workspace for the complete management workflow."))}}}
    }
    private fun lecturerName(id:String):String{val o=lecturers.firstOrNull{it.optString("user_id")==id||it.optString("id")==id};return o?.optString("full_name")?.takeIf{it.isNotBlank()}?:listOf(o?.optString("first_name"),o?.optString("middle_name"),o?.optString("last_name")).filter{it?.isNotBlank()==true}.joinToString(" ").ifBlank{"Lecturer $id"}}
    private fun render(){val sv=findViewById<ScrollView>(android.R.id.content)?.getChildAt(0) as? LinearLayout ?:return;val list=sv.getChildAt(sv.childCount-2) as? LinearLayout ?:return;list.removeAllViews();val shown=assignments.filter{val active=it.optString("assignment_status","active").lowercase()=="active";val s=(lecturerName(it.optString("lecturer_id"))+" "+it.toString()).lowercase();(!activeOnly||active)&&(query.isBlank()||s.contains(query))};if(shown.isEmpty()){list.addView(card("No matching assignments","Try another search or include inactive assignments."));return};shown.forEach{o->val lec=lecturerName(o.optString("lecturer_id"));val code=o.optString("course_code").ifBlank{"Course"};val title=o.optString("course_title");val meta=listOf(lec,o.optString("level"),o.optString("semester"),"${o.optString("credit_load").ifBlank{"0"}} credits",o.optString("assignment_status","active")).filter{it.isNotBlank()}.joinToString(" · ");list.addView(card(code,title+"\n"+meta))}}
    private fun showAssignmentEditor(){
        val r=root();r.addView(label("NEW TEACHING ASSIGNMENT"));r.addView(title("Assign Course"));r.addView(text("Select an existing lecturer and an existing academic course. The app writes only to lecturer_courses."))
        val lecturerLabels=lecturers.map{(it.optString("full_name").ifBlank{listOf(it.optString("first_name"),it.optString("middle_name"),it.optString("last_name")).filter{it.isNotBlank()}.joinToString(" ")}).ifBlank{"Unnamed lecturer"}};val courseLabels=courses.map{"${it.optString("course_code")} — ${it.optString("course_title")}"}
        val ls=Spinner(this).apply{adapter=ArrayAdapter(this@ManagementTeachingLoadActivity,android.R.layout.simple_spinner_dropdown_item,lecturerLabels)};r.addView(ls,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(5),0,dp(5))})
        val cs=Spinner(this).apply{adapter=ArrayAdapter(this@ManagementTeachingLoadActivity,android.R.layout.simple_spinner_dropdown_item,courseLabels)};r.addView(cs,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(5),0,dp(5))})
        val status=text("",13f,ink);r.addView(status)
        r.addView(button("Create Assignment"){if(lecturers.isEmpty()||courses.isEmpty()){status.text="Lecturers or courses are unavailable.";return@button};val l=lecturers[ls.selectedItemPosition];val c=courses[cs.selectedItemPosition];val lecturerId=l.optString("user_id").ifBlank{l.optString("id")};val courseId=c.optString("id");if(lecturerId.isBlank()||courseId.isBlank()){status.text="The selected lecturer/course has no usable identifier.";return@button};val exists=assignments.any{it.optString("lecturer_id")==lecturerId&&it.optString("course_id")==courseId&&it.optString("assignment_status","active").lowercase()=="active"};if(exists){status.text="That active assignment already exists.";return@button};val payload=JSONObject().put("lecturer_id",lecturerId).put("course_id",courseId).put("course_code",c.optString("course_code")).put("course_title",c.optString("course_title")).put("level",c.optString("level").ifBlank{JSONObject.NULL}).put("semester",c.optString("semester").ifBlank{JSONObject.NULL}).put("credit_load",c.optDouble("credit_load",0.0)).put("assignment_status","active");status.text="Saving…";executor.execute{try{request("POST","/rest/v1/lecturer_courses",payload.toString());runOnUiThread{Toast.makeText(this,"Teaching assignment created.",Toast.LENGTH_SHORT).show();show()}}catch(x:Exception){runOnUiThread{status.text="Could not create assignment. ${"Request failed. Please use the authoritative MTI workspace if the problem persists."}"}}}});r.addView(button("Cancel"){show()});set(r)
    }
}
