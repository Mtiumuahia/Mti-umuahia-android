package ng.org.mtiumuahia.app

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.text.method.LinkMovementMethod
import android.view.Gravity
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class NewsArticleActivity : MtiBaseActivity() {
    private val cream = Color.rgb(247, 244, 237)
    private val green = Color.rgb(11, 61, 46)
    private val deep = Color.rgb(5, 37, 28)
    private val gold = Color.rgb(190, 157, 82)
    private val ink = Color.rgb(25, 45, 39)
    private val muted = Color.rgb(91, 105, 99)
    private val white = Color.WHITE
    private val exec = Executors.newFixedThreadPool(3)
    private var mediaPlayer: MediaPlayer? = null
    private var playButton: Button? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(s: String, n: Float, c: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = n
        setTextColor(c)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setLineSpacing(0f, 1.3f)
    }
    private fun cardBg() = GradientDrawable().apply {
        setColor(white)
        cornerRadius = dp(22).toFloat()
        setStroke(dp(1), Color.rgb(229, 225, 216))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val raw = intent.getStringExtra("news_json")
        if (raw.isNullOrBlank()) { finish(); return }
        render(JSONObject(raw))
    }

    private fun render(o: JSONObject) {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cream)
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(9), dp(16), dp(9))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(deep, green))
        }
        top.addView(TextView(this).apply {
            text = "‹"
            textSize = 34f
            setTextColor(white)
            gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(46), dp(48)))
        top.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("MTI · UMUAHIA", 10f, gold, true))
            addView(tv("News", 18f, white, true))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(top)

        val scroll = ScrollView(this).apply { isFillViewport = true }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(36))
        }
        scroll.addView(root)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(shell)

        root.addView(tv(value(o, "category", "section", "type").ifBlank { "MTI NEWS" }.uppercase(), 11f, gold, true))
        root.addView(tv(value(o, "title").ifBlank { "MTI News" }, 30f, ink, true).apply { setPadding(0, dp(6), 0, dp(7)) })
        val date = value(o, "published_at", "created_at")
        if (date.isNotBlank()) root.addView(tv(formatDate(date), 12f, muted, true).apply { setPadding(0, 0, 0, dp(18)) })

        val hero = value(o, "featured_image_url", "cover_image_url", "image_url", "photo_url", "thumbnail_url")
        if (hero.isNotBlank()) addRemoteImage(root, hero, value(o, "title").ifBlank { "MTI News" }, 260)

        val excerpt = value(o, "excerpt", "summary")
        if (excerpt.isNotBlank()) {
            root.addView(tv(stripHtml(excerpt), 17f, green, true).apply { setPadding(0, dp(6), 0, dp(18)) })
        }

        val video = value(o, "video_url", "video", "video_link")
        if (video.isNotBlank()) addVideo(root, video)

        val audio = value(o, "audio_url", "audio", "audio_link", "podcast_url")
        if (audio.isNotBlank()) addAudio(root, audio)

        val body = value(o, "body", "content", "article", "article_body", "description", "details")
        if (body.isNotBlank()) {
            val articleCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(19), dp(20), dp(19), dp(20))
                background = cardBg()
            }
            articleCard.addView(tv("THE STORY", 10.5f, gold, true))
            val content = tv("", 16f, ink)
            content.text = Html.fromHtml(body, Html.FROM_HTML_MODE_LEGACY)
            content.movementMethod = LinkMovementMethod.getInstance()
            articleCard.addView(content.apply { setPadding(0, dp(10), 0, 0) })
            root.addView(articleCard, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(12)) })
        }

        val link = value(o, "link_url", "external_url", "article_url", "source_url", "url")
        if (link.isNotBlank()) {
            val button = Button(this).apply {
                text = "Open related link"
                isAllCaps = false
                textSize = 14f
                setTextColor(white)
                backgroundTintList = android.content.res.ColorStateList.valueOf(green)
                setOnClickListener { openExternal(link) }
            }
            root.addView(button, LinearLayout.LayoutParams(-1, dp(52)).apply { setMargins(0, dp(3), 0, dp(8)) })
        }

        root.addView(tv("Published by Methodist Theological Institute, Umuahia", 12f, muted, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
        root.alpha = 0f
        root.translationY = dp(18).toFloat()
        root.animate().alpha(1f).translationY(0f).setDuration(420L).start()
    }

    private fun addVideo(root: LinearLayout, raw: String) {
        val url = resolveUrl(raw)
        if (url.isBlank()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = cardBg()
        }
        box.addView(tv("VIDEO", 10.5f, gold, true))
        val video = VideoView(this)
        video.setVideoURI(Uri.parse(url))
        video.setMediaController(MediaController(this))
        box.addView(video, LinearLayout.LayoutParams(-1, dp(235)).apply { setMargins(0, dp(8), 0, 0) })
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) })
    }

    private fun addAudio(root: LinearLayout, raw: String) {
        val url = resolveUrl(raw)
        if (url.isBlank()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = cardBg()
        }
        box.addView(tv("AUDIO", 10.5f, gold, true))
        box.addView(tv("Listen to this MTI story", 17f, green, true).apply { setPadding(0, dp(6), 0, dp(10)) })
        playButton = Button(this).apply {
            text = "Play audio"
            isAllCaps = false
            setTextColor(white)
            backgroundTintList = android.content.res.ColorStateList.valueOf(green)
            setOnClickListener { toggleAudio(url) }
        }
        box.addView(playButton, LinearLayout.LayoutParams(-1, dp(50)))
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) })
    }

    private fun toggleAudio(url: String) {
        val current = mediaPlayer
        if (current?.isPlaying == true) {
            current.pause()
            playButton?.text = "Resume audio"
            return
        }
        if (current != null) {
            current.start()
            playButton?.text = "Pause audio"
            return
        }
        playButton?.isEnabled = false
        playButton?.text = "Loading audio…"
        exec.execute {
            try {
                val mp = MediaPlayer()
                mp.setAudioStreamType(AudioManager.STREAM_MUSIC)
                mp.setDataSource(url)
                mp.setOnPreparedListener {
                    mediaPlayer = mp
                    runOnUiThread {
                        playButton?.isEnabled = true
                        playButton?.text = "Pause audio"
                    }
                    mp.start()
                }
                mp.setOnCompletionListener { runOnUiThread { playButton?.text = "Play audio" } }
                mp.setOnErrorListener { _, _, _ ->
                    runOnUiThread { playButton?.isEnabled = true; playButton?.text = "Audio unavailable" }
                    true
                }
                mp.prepareAsync()
            } catch (_: Exception) {
                runOnUiThread { playButton?.isEnabled = true; playButton?.text = "Audio unavailable" }
            }
        }
    }

    private fun addRemoteImage(root: LinearLayout, raw: String, description: String, height: Int) {
        val url = resolveUrl(raw)
        if (url.isBlank()) return
        val iv = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = description
            setBackgroundColor(Color.rgb(231, 228, 219))
        }
        root.addView(iv, LinearLayout.LayoutParams(-1, dp(height)).apply { setMargins(0, 0, 0, dp(16)) })
        exec.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 15000
                c.instanceFollowRedirects = true
                val bmp = if (c.responseCode in 200..299) c.inputStream.use { BitmapFactory.decodeStream(it) } else null
                c.disconnect()
                if (bmp != null) runOnUiThread {
                    iv.setImageBitmap(bmp)
                    iv.alpha = 0f
                    iv.animate().alpha(1f).setDuration(420L).start()
                }
            } catch (_: Exception) { }
        }
    }

    private fun value(o: JSONObject, vararg names: String): String {
        for (n in names) {
            val v = o.optString(n).trim()
            if (v.isNotBlank() && v != "null") return v
        }
        return ""
    }

    private fun stripHtml(text: String): String = Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY).toString().replace("\u00a0", " ").trim()

    private fun formatDate(raw: String): String = raw.replace("T", " ").replace("Z", "").take(16)

    private fun resolveUrl(raw: String): String {
        val value = raw.trim()
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        val base = getString(R.string.mti_base_url).trimEnd('/')
        return if (value.startsWith("/")) base + value else value
    }

    private fun openExternal(raw: String) {
        val url = resolveUrl(raw)
        if (url.isNotBlank()) startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url)))
    }

    override fun onStop() {
        super.onStop()
        mediaPlayer?.let {
            try { if (it.isPlaying) it.pause() } catch (_: Exception) { }
        }
    }

    override fun onDestroy() {
        try { mediaPlayer?.release() } catch (_: Exception) { }
        mediaPlayer = null
        exec.shutdownNow()
        super.onDestroy()
    }
}
