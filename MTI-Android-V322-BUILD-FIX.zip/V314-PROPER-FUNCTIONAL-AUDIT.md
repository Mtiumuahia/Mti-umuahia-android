# MTI Android V314 — Proper Functional Audit

Baseline: V313, preserved native Kotlin/View architecture and existing Supabase/RLS/portal architecture.

## Repairs
- Corrected the native app's `mti_base_url` from the retired `startling-klepon-ce7270.netlify.app` hostname to the current MTI production hostname `nimble-faun-2c7fb5.netlify.app`. This fixes website deep links used by Admissions, management and other existing native screens.
- Preserved Admissions workflow and its existing `/apply-now` route.
- Added explicit Android handling for HTTP 429 so the app displays: `MTI AI is unavailable now, check back soon.` when OpenAI credits are exhausted.
- Added safe relative-path handling for Leadership/SUG media URLs; full HTTPS URLs remain untouched.
- Preserved Gallery bucket normalization from V313.
- Preserved the distinct Campus Life and MTI Community destinations.
- Preserved Programme fallback content when the public table is empty.
- Version: 314 / 10.0.0.

## Architecture
No tables, RPCs, roles, authentication architecture, or storage buckets recreated. No secrets added to Android.
