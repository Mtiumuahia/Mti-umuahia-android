# MTI Android V313 — Proper Functional Audit

## Baseline
- Built directly from the V312 verified source package.
- Existing native Kotlin/View architecture retained.
- Existing Supabase project, tables, RLS, authentication and portal architecture retained.
- No new database tables, RPCs, roles or storage buckets created.

## Confirmed findings from V312 testing
1. Ask MTI reached the confirmed Netlify hostname but returned HTTP 401/403.
   - The Android website-compatible contract is `messages[]`.
   - For compatibility with the separately packaged legacy function, V313 also sends `message` and `history` without exposing any secret.
   - The V221 website function was inspected and confirmed to use `messages[]` and to handle upstream OpenAI failures server-side.
   - The standalone AI repair function previously packaged separately used `message` + `history` and could propagate OpenAI authentication errors. It must not replace the V221 website function.

2. Explore → Programmes returned an empty-state message.
   - V313 retains the live Supabase query.
   - If the public table currently returns zero rows, the app now displays an approved fallback based on the current MTI website's published programme structure rather than an empty screen.

3. Explore → Leadership displayed names but no photographs.
   - V312 did not render `photo_url` at all.
   - V313 reads `photo_url` / `image_url` / `photo` and renders the image when available.

4. Explore → Gallery displayed no photographs.
   - V312 attempted to open the stored URL directly.
   - The current MTI website normalizes gallery media to the `Mti Umuahia Gallery` public storage bucket. V313 applies the same bucket normalization before loading images.

5. Campus Life and MTI Community opened the same Community screen.
   - V313 separates these destinations.
   - Campus Life opens a dedicated native Campus Life content page.
   - MTI Community continues to open the native community experience.

6. Admissions had no direct application action.
   - V313 adds `Apply on the MTI website`.
   - It opens the existing website's `/apply-now` route.
   - No applicant account/password is created by the Android app.

7. Explore used visible numbering and repeated card actions.
   - V313 removes directory numbering and the `9 institutional destinations` count.
   - Explore cards are now title/icon/content driven and do not repeat numbered labels or `Explore →` controls.

8. General interface quality.
   - V313 reduces duplicate destinations, separates Campus Life from Community, uses larger content hierarchy, and gives public-content pages richer content cards.
   - Existing restrained MTI green/ivory/champagne visual language is retained.

## Version integrity
- `versionCode = 313`
- `versionName = 9.9.0`
- `applicationId = ng.org.mtiumuahia.app`
- GitHub Actions verifies both source metadata and the generated APK metadata before publishing the artifact.

## SQL decision
No new SQL migration is included in V313. The existing V307 public-content access migration already grants the required public reads and is retained. The reported issues were primarily native rendering, routing, fallback/content handling and AI deployment alignment rather than a need to recreate database architecture.

## Build status
Source syntax and structural checks were completed locally. A full Android Gradle build must still be performed by GitHub Actions; the workflow is configured to fail if the generated APK is not version 9.9.0 / build 313.
