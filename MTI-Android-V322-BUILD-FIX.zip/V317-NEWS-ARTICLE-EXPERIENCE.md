# MTI Android V317 — News Article Experience

## Changes
- News cards are now fully clickable and open a dedicated article screen.
- Dedicated article screen presents the selected story independently with title, publication date, excerpt and full article body.
- News supports optional featured/cover images.
- News supports optional video playback through Android VideoView/MediaController.
- News supports optional audio playback with play/pause/resume controls.
- News supports optional related/external links.
- HTML article body is rendered as readable rich text where supported by Android's HTML parser.
- News cards use a richer editorial layout with category, image, excerpt and “Read full article” affordance.
- Article and media sections use restrained entrance/fade animation.
- Existing Supabase news table and public content architecture are reused; no database recreation or destructive migration was added.

## Media field compatibility
The app checks common public field names without requiring a schema change:
- Images: `featured_image_url`, `cover_image_url`, `image_url`, `photo_url`, `thumbnail_url`
- Video: `video_url`, `video`, `video_link`
- Audio: `audio_url`, `audio`, `audio_link`, `podcast_url`
- Related link: `link_url`, `external_url`, `article_url`, `source_url`, `url`
- Article body: `body`, `content`, `article`, `article_body`, `description`, `details`

If MTI's existing `news` table uses different media column names, those columns should be mapped in a later audited update rather than creating duplicate columns blindly.
