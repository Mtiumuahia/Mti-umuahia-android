plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ng.org.mtiumuahia.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ng.org.mtiumuahia.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 315
        versionName = "10.1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }

    kotlinOptions {
        jvmTarget = "21"
    }
}
