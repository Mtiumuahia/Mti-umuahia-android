-- MTI Android V307 — Public Content Access Repair
-- Targeted repair for native Android Explore/public-content screens.
-- Reuses existing MTI tables and RLS. No tables are recreated and no data is deleted.

begin;

-- PostgREST needs schema usage plus table SELECT grants.
grant usage on schema public to anon, authenticated;
grant select on table
  public.news,
  public.events,
  public.gallery_albums,
  public.gallery_photos,
  public.leadership,
  public.programmes,
  public.sug_executives_v142
  to anon, authenticated;

alter table public.news enable row level security;
alter table public.events enable row level security;
alter table public.gallery_albums enable row level security;
alter table public.gallery_photos enable row level security;
alter table public.leadership enable row level security;
alter table public.programmes enable row level security;
alter table public.sug_executives_v142 enable row level security;

drop policy if exists "public read published news" on public.news;
drop policy if exists mti_public_news_read on public.news;
create policy mti_public_news_read
on public.news for select
to anon, authenticated
using (published = true);

drop policy if exists "public read events" on public.events;
drop policy if exists mti_public_events_read on public.events;
create policy mti_public_events_read
on public.events for select
to anon, authenticated
using (true);

drop policy if exists "public read albums" on public.gallery_albums;
drop policy if exists mti_public_gallery_albums_read on public.gallery_albums;
create policy mti_public_gallery_albums_read
on public.gallery_albums for select
to anon, authenticated
using (true);

drop policy if exists "public read photos" on public.gallery_photos;
drop policy if exists mti_public_gallery_photos_read on public.gallery_photos;
create policy mti_public_gallery_photos_read
on public.gallery_photos for select
to anon, authenticated
using (true);

drop policy if exists "public read leadership" on public.leadership;
drop policy if exists mti_public_leadership_read on public.leadership;
create policy mti_public_leadership_read
on public.leadership for select
to anon, authenticated
using (true);

drop policy if exists "public read programmes" on public.programmes;
drop policy if exists mti_public_programmes_read on public.programmes;
create policy mti_public_programmes_read
on public.programmes for select
to anon, authenticated
using (true);

drop policy if exists mti_public_sug_read on public.sug_executives_v142;
create policy mti_public_sug_read
on public.sug_executives_v142 for select
to anon, authenticated
using (active = true);

commit;

-- Refresh PostgREST's schema/config cache after the privilege/RLS change.
notify pgrst, 'reload schema';
notify pgrst, 'reload config';
