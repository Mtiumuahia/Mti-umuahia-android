# MTI Android V311 — Functional Audit

## Baseline
V311 continues directly from V310. No Supabase tables, authentication architecture, Community schema, or portal architecture were recreated.

## AI findings
- The deployed MTI website function expects `POST { messages: [...] }`.
- V310 sent the older `message` + `history` contract and also did not include the current question in the request history.
- V311 restores the website-compatible `messages` contract and appends the current user question before the request.
- OpenAI credentials remain server-side on Netlify. No OpenAI secret is bundled in Android.
- V311 preserves the production endpoint `https://nimble-faun-2c7fb5.netlify.app/.netlify/functions/mti-assistant`.

## Explore findings
- V310 used a different Supabase publishable key from the working MTI web project. V311 aligns the native app with the publishable key used by the working public web/server code.
- Public content screens remain direct read-only Supabase clients; RLS remains authoritative.
- Explore content rendering was upgraded from sparse single-label cards to richer institutional sections, larger typography, dates, biographies, descriptions, metadata and gallery imagery.
- Leadership/SUG/programme/news/event fields now have safe fallbacks for the known MTI schema variants.
- Added in-app back navigation on public content pages.

## Verification
- ZIP integrity: checked after packaging.
- Version: 311 / 9.7.0.
- GitHub Actions artifact: `MTI-Umuahia-debug-apk-v311`.
- Full Android compile is expected in GitHub Actions because the local environment does not contain the Gradle wrapper JAR/full Android SDK.
