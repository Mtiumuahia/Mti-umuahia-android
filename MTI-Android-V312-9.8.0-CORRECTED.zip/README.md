# MTI Umuahia Android — V305 Digital Campus

V305 continues the audited V304 native Android baseline.

- versionCode: 312
- versionName: 9.8.0
- package: ng.org.mtiumuahia.app
- compile/target SDK: 35
- min SDK: 24
- 38 Kotlin activities retained from V304
- Native-first navigation expanded to Home / Community / Academics / Explore / Profile
- Professional card entrance and press motion using Android platform APIs
- Reduced-motion aware animations
- Existing Supabase/Auth/RLS architecture preserved
- No community SQL migration added in V305; the available authoritative SQL audit did not establish existing social tables, so backend design remains a separate audited phase
- GitHub Actions builds the checked-out Android project directly with Java 21 and Gradle 8.9

## Important
Community UI in V305 is a native experience scaffold. It does not pretend that posts, chat, stories or notifications are cloud-backed yet. The next backend phase must first audit the complete available Supabase SQL/source before introducing any community tables, policies, storage or RPCs.
