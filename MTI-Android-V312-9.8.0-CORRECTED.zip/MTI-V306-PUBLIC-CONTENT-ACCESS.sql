-- MTI Android V306 — Public Content Access Repair
-- Purpose: repair REST access for public institutional content used by the native app.
-- Does NOT recreate or replace the MTI portal architecture.
-- Safe to run after the existing MTI public-content schema and community migration.

begin;

-- Keep the public mobile/app content read-only.
grant select on table public.news, public.events, public.gallery_albums,
    public.gallery_photos, public.leadership, public.programmes
    to anon, authenticated;

alter table public.news enable row level security;
alter table public.events enable row level security;
alter table public.gallery_albums enable row level security;
alter table public.gallery_photos enable row level security;
alter table public.leadership enable row level security;
alter table public.programmes enable row level security;

-- Recreate the public read policies using explicit MTI-prefixed names.
drop policy if exists "public read published news" on public.news;
drop policy if exists "mti_public_news_read" on public.news;
create policy "mti_public_news_read"
on public.news for select
to anon, authenticated
using (published = true);

drop policy if exists "public read events" on public.events;
drop policy if exists "mti_public_events_read" on public.events;
create policy "mti_public_events_read"
on public.events for select
to anon, authenticated
using (true);

drop policy if exists "public read albums" on public.gallery_albums;
drop policy if exists "mti_public_gallery_albums_read" on public.gallery_albums;
create policy "mti_public_gallery_albums_read"
on public.gallery_albums for select
to anon, authenticated
using (true);

drop policy if exists "public read photos" on public.gallery_photos;
drop policy if exists "mti_public_gallery_photos_read" on public.gallery_photos;
create policy "mti_public_gallery_photos_read"
on public.gallery_photos for select
to anon, authenticated
using (true);

drop policy if exists "public read leadership" on public.leadership;
drop policy if exists "mti_public_leadership_read" on public.leadership;
create policy "mti_public_leadership_read"
on public.leadership for select
to anon, authenticated
using (true);

drop policy if exists "public read programmes" on public.programmes;
drop policy if exists "mti_public_programmes_read" on public.programmes;
create policy "mti_public_programmes_read"
on public.programmes for select
to anon, authenticated
using (true);

commit;
