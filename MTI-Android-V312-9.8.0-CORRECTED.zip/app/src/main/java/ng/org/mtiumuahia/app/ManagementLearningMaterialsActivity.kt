package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.content.res.ColorStateList
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementLearningMaterialsActivity : Activity() {
    private val executor=Executors.newFixedThreadPool(2)
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private val supabaseUrl="https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabaseKey="sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken:String?=null
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);accessToken=intent.getStringExtra("access_token");show()}
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun scroll(v:View)=ScrollView(this).apply{isFillViewport=true;addView(v)}
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,27f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(16),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun card(h:String,b:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));addView(text(h,16f,green,true));addView(text(b,13f,ink))}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun set(v:View){setContentView(scroll(v))}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}")
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";headers().forEach{(k,v)->c.setRequestProperty(k,v)};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return body}
    private fun parseError(b:String)=try{val j=JSONObject(b);j.optString("message").ifBlank{j.optString("msg").ifBlank{"Request failed"}}}catch(_:Exception){"Request failed"}
    private fun show(){
        val r=root();r.addView(label("MANAGEMENT · DIGITAL LIBRARY"));r.addView(title("Learning Materials & Digital Library"));r.addView(text("Monitor the existing MTI lecturer-materials catalogue and published learning resources without creating a duplicate library system. Lecturer publishing, student access and storage remain governed by the established Supabase architecture."))
        val summary=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(summary);summary.addView(card("Loading materials…","Reading existing authorised lecturer-material records."))
        r.addView(label("ADMINISTRATION"));r.addView(button("Open Full Learning Materials Workspace"){openWeb("/learning-materials")});r.addView(button("Open Digital Library"){openWeb("/library")});r.addView(button("Open Management Command Centre"){openWeb("/management-dashboard")});r.addView(button("Back to Management Portal"){finish()})
        r.addView(label("SECURITY"));r.addView(text("This Android layer uses the signed-in management access token and existing Supabase RLS. It does not create storage buckets, duplicate material tables, expose service-role credentials, or alter lecturer/student permissions."));set(r);load(summary)
    }
    private fun load(box:LinearLayout){executor.execute{try{
        val arr=JSONArray(get("/rest/v1/lecturer_materials?select=*&limit=500"));var published=0;var drafts=0;val types=linkedMapOf<String,Int>()
        for(i in 0 until arr.length()){val x=arr.getJSONObject(i);if(x.optBoolean("published",false))published++ else drafts++;val t=x.optString("material_type").ifBlank{"Other"};types[t]=(types[t]?:0)+1}
        runOnUiThread{box.removeAllViews();box.addView(card("Materials","${arr.length()} material record${if(arr.length()==1)"" else "s"}"));box.addView(card("Publication","$published published · $drafts draft/unpublished"));if(types.isNotEmpty())box.addView(card("Types",types.entries.joinToString(" · "){"${it.key}: ${it.value}"}));if(arr.length()==0)box.addView(card("No materials","No lecturer-material records were returned by the existing authorised data source."));for(i in 0 until minOf(arr.length(),60)){val x=arr.getJSONObject(i);val title=x.optString("title").ifBlank{"Untitled material"};val body=listOf(x.optString("course_code"),x.optString("course_title"),x.optString("material_type"),if(x.optBoolean("published",false))"Published" else "Draft").filter{it.isNotBlank()}.joinToString("\n");val c=card(title,body);val url=x.optString("resource_url").ifBlank{x.optString("file_url")};if(url.isNotBlank())c.setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))};box.addView(c)}}
    }catch(e:Exception){runOnUiThread{box.removeAllViews();box.addView(card("Learning-material records unavailable","The existing management-authorised material source could not be read. Open the full management workspace for the authoritative view."))}}}}
    private fun openWeb(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
}
