package ng.org.mtiumuahia.app

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class PublicContentActivity: Activity() {
    private val cream=Color.rgb(247,244,237); private val green=Color.rgb(11,61,46); private val deep=Color.rgb(5,37,28)
    private val gold=Color.rgb(190,157,82); private val ink=Color.rgb(25,45,39); private val muted=Color.rgb(91,105,99); private val white=Color.WHITE
    private val supa="https://vjpwllvssblgpwckbiff.supabase.co"
    // Public/publishable Supabase key used by the working MTI web project. It is safe for client use; RLS remains authoritative.
    private val key="sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private lateinit var root:LinearLayout
    private val exec=Executors.newFixedThreadPool(4)

    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun tv(s:String,n:Float,c:Int=ink,b:Boolean=false)=TextView(this).apply{text=s;textSize=n;setTextColor(c);typeface=if(b)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;setLineSpacing(0f,1.22f)}
    private fun cardBg(c:Int=white)=GradientDrawable().apply{setColor(c);cornerRadius=dp(20).toFloat();setStroke(dp(1),Color.rgb(229,225,216))}

    override fun onCreate(b:Bundle?){super.onCreate(b);build();load(intent.getStringExtra("type") ?: "about")}

    private fun build(){
        val shell=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream)}
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(16),dp(12),dp(16),dp(12));background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(deep,green))}
        val back=TextView(this).apply{text="‹";textSize=34f;setTextColor(white);gravity=Gravity.CENTER;setOnClickListener{finish()}}
        top.addView(back,LinearLayout.LayoutParams(dp(46),dp(48)))
        top.addView(LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;addView(tv("MTI · UMUAHIA",10f,gold,true));addView(tv("Explore MTI",18f,white,true).apply{setPadding(0,dp(2),0,0)})},LinearLayout.LayoutParams(0,-2,1f))
        shell.addView(top)
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(20),dp(18),dp(32))}
        shell.addView(ScrollView(this).apply{isFillViewport=true;addView(root)},LinearLayout.LayoutParams(-1,0,1f))
        setContentView(shell)
    }

    private fun load(type:String){
        root.removeAllViews()
        root.addView(tv(kicker(type),11f,gold,true))
        root.addView(tv(title(type),30f,ink,true).apply{setPadding(0,dp(5),0,dp(8))})
        root.addView(tv(intro(type),15f,muted).apply{setPadding(0,0,0,dp(18))})
        if(type in listOf("news","events","gallery","leadership","programmes","sug")){
            val loading=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));background=cardBg()}
            loading.addView(tv("Loading MTI content…",16f,green,true));loading.addView(tv("Retrieving approved public information from the MTI service.",13.5f,muted).apply{setPadding(0,dp(5),0,0)})
            root.addView(loading)
            exec.execute{try{val data=fetch(type);runOnUiThread{render(type,data)}}catch(e:Exception){runOnUiThread{renderError(type,e)}}}
        } else renderStatic(type)
    }

    private fun kicker(t:String)=when(t){"about"->"THE INSTITUTE";"governance"->"GOVERNANCE & OVERSIGHT";"admissions"->"ADMISSIONS";"contact"->"VISIT MTI";else->"MTI PUBLIC INFORMATION"}
    private fun title(t:String)=when(t){"about"->"About MTI";"governance"->"Governance";"programmes"->"Programmes";"admissions"->"Admissions";"news"->"News & Updates";"events"->"Events";"gallery"->"Gallery";"leadership"->"Leadership";"sug"->"Student Leadership";"contact"->"Visit & Contact";else->"MTI"}
    private fun intro(t:String)=when(t){
        "about"->"A theological institution shaped by Christian faith, academic formation, spiritual growth and service.";
        "governance"->"The leadership and institutional standards that support MTI's academic, spiritual and administrative life.";
        "programmes"->"Explore the academic pathways and programme information currently published by the Institute.";
        "admissions"->"Understand the MTI application and Selection Conference journey before you apply.";
        "news"->"Read published MTI stories, announcements and institutional updates.";
        "events"->"Keep up with Institute activities, services, ceremonies and community events.";
        "gallery"->"A visual record of MTI community life, ministry, learning and institutional moments.";
        "leadership"->"Meet the people currently presented as MTI leadership through the Institute's public content.";
        "sug"->"Meet the Student Union Government executives serving the MTI student community.";
        else->"Methodist Theological Institute, Mission Hill, Umuahia, Abia State, Nigeria."
    }

    private fun renderStatic(t:String){when(t){
        "about"->{section("ROOTED IN FAITH", "Methodist Theological Institute, Umuahia exists to equip people for faithful Christian ministry through theological education, formation and service.");section("FAITH · FORMATION · SCHOLARSHIP","MTI combines spiritual formation with academic study and practical preparation for ministry, serving the Methodist Church and the wider body of Christ.");section("THE MTI EXPERIENCE","The Institute seeks to form people who can think carefully, live faithfully and serve responsibly in the Church and society.")}
        "governance"->{personCard("Rector","Very Rev. Kingsley Raphael Nwaike Ph.D.","Institute leadership");personCard("Registrar","Very Rev. Washington Okpara","Registry and institutional administration");section("INSTITUTIONAL STANDARD","MTI's academic, spiritual and administrative life is supported by recognised leadership, responsible stewardship, academic integrity and respectful community conduct.");section("OFFICIAL INFORMATION","Formal regulations, current fees, admission requirements and other official policies should be confirmed directly with MTI. The app does not invent or replace official institutional documents.")}
        "admissions"->{section("THE APPLICATION JOURNEY","Applicants submit an online application only. Submission does not create Student Portal access or a password.");section("SELECTION CONFERENCE","When invited, applicants attend the Selection Conference, write the required examination, present required documents and details, participate in interview and undergo the required medical/physical checks.");section("AFTER SELECTION","Admission is decided through the Institute's approved process and Methodist Church Nigeria conference structures. Admitted students subsequently receive their MTI registration number and one-time activation token for Student Portal account activation.")}
        "contact"->{personCard("Address","Methodist Theological Institute, Mission Hill, Umuahia, Abia State, Nigeria","Campus location");section("VISIT","For an official visit, confirm the current office schedule and visitor arrangements with MTI before travelling.");section("DIGITAL SUPPORT","For app or website technical issues, use the MTI digital support channel provided by the Institute.")}
    }}

    private fun section(label:String,body:String){val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(17),dp(18),dp(17));background=cardBg()};b.addView(tv(label,11f,gold,true));b.addView(tv(body,16f,ink).apply{setPadding(0,dp(8),0,0)});root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})}
    private fun personCard(role:String,name:String,detail:String){val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(17),dp(18),dp(17));background=cardBg()};b.addView(tv(role,11f,gold,true));b.addView(tv(name,21f,green,true).apply{setPadding(0,dp(6),0,dp(3))});b.addView(tv(detail,13.5f,muted));root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})}

    private fun fetch(t:String):JSONArray{
        val path=when(t){
            "news"->"news?select=*&published=eq.true&order=published_at.desc,created_at.desc&limit=30";
            "events"->"events?select=*&order=starts_at.desc,created_at.desc&limit=30";
            "gallery"->"gallery_photos?select=*&order=created_at.desc&limit=60";
            "leadership"->"leadership?select=*&order=sort_order.asc,created_at.asc&limit=30";
            "programmes"->"programmes?select=*&order=name.asc&limit=50";
            "sug"->"sug_executives_v142?select=*&active=eq.true&order=display_order.asc,full_name.asc&limit=50";
            else->throw Exception("Unsupported content section")
        }
        val c=URL("$supa/rest/v1/$path").openConnection() as HttpURLConnection
        c.requestMethod="GET";c.setRequestProperty("apikey",key);c.setRequestProperty("Authorization","Bearer $key");c.setRequestProperty("Accept","application/json");c.connectTimeout=12000;c.readTimeout=15000
        val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input?.bufferedReader()?.use{it.readText()}.orEmpty();c.disconnect()
        if(code !in 200..299)throw Exception("HTTP $code${parseError(body)}")
        return JSONArray(body)
    }
    private fun parseError(body:String):String=try{val o=JSONObject(body);(o.optString("message").ifBlank{o.optString("hint")}).let{if(it.isBlank())"" else ": ${it.take(160)}"}}catch(_:Exception){""}

    private fun renderError(t:String,e:Exception){
        root.removeViewAt(root.childCount-1)
        val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(19),dp(19),dp(19),dp(19));background=cardBg()}
        b.addView(tv("We couldn't load this MTI section",19f,green,true));b.addView(tv("The app reached the MTI content service, but the request was not completed. You can try again without leaving the app.",14f,muted).apply{setPadding(0,dp(8),0,dp(14))})
        b.addView(Button(this).apply{text="Try again";isAllCaps=false;setTextColor(white);backgroundTintList=android.content.res.ColorStateList.valueOf(green);setOnClickListener{load(t)}})
        root.addView(b)
    }

    private fun render(t:String,a:JSONArray){
        root.removeViewAt(root.childCount-1)
        if(a.length()==0){section("NO PUBLISHED CONTENT","There is currently no published information in this section.");return}
        for(i in 0 until a.length()){val o=a.getJSONObject(i);when(t){
            "news"->newsCard(o);"events"->eventCard(o);"gallery"->galleryCard(o);"leadership"->leadershipCard(o);"programmes"->programmeCard(o);"sug"->sugCard(o)
        }}
    }

    private fun baseCard():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(17),dp(18),dp(17));background=cardBg()}
    private fun addCard(b:LinearLayout){root.addView(b,LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,dp(10))})}
    private fun value(o:JSONObject,vararg names:String):String{for(n in names){val v=o.optString(n).trim();if(v.isNotBlank()&&v!="null")return v};return ""}
    private fun newsCard(o:JSONObject){val b=baseCard();b.addView(tv(value(o,"title").ifBlank{"MTI News"},19f,green,true));val date=value(o,"published_at","created_at");if(date.isNotBlank())b.addView(tv(date.replace("T"," ").take(16),11f,gold,true).apply{setPadding(0,dp(5),0,0)});val body=value(o,"excerpt","body","content","description");if(body.isNotBlank())b.addView(tv(body,15f,ink).apply{setPadding(0,dp(9),0,0)});addCard(b)}
    private fun eventCard(o:JSONObject){val b=baseCard();b.addView(tv(value(o,"title").ifBlank{"MTI Event"},19f,green,true));val whenText=value(o,"starts_at","start_date","event_date");if(whenText.isNotBlank())b.addView(tv(whenText.replace("T"," ").take(16),11f,gold,true).apply{setPadding(0,dp(5),0,0)});val loc=value(o,"location","venue");if(loc.isNotBlank())b.addView(tv(loc,13.5f,green,true).apply{setPadding(0,dp(7),0,0)});val body=value(o,"description","details","body");if(body.isNotBlank())b.addView(tv(body,15f,ink).apply{setPadding(0,dp(8),0,0)});addCard(b)}
    private fun programmeCard(o:JSONObject){val b=baseCard();b.addView(tv(value(o,"name","title","programme","program_name").ifBlank{"MTI Programme"},20f,green,true));val duration=value(o,"duration","length");if(duration.isNotBlank())b.addView(tv(duration,12f,gold,true).apply{setPadding(0,dp(5),0,0)});val body=value(o,"description","overview","details");if(body.isNotBlank())b.addView(tv(body,15f,ink).apply{setPadding(0,dp(8),0,0)});addCard(b)}
    private fun leadershipCard(o:JSONObject){val b=baseCard();b.addView(tv(value(o,"role","office","position").ifBlank{"MTI Leadership"},11f,gold,true));b.addView(tv(value(o,"name","full_name").ifBlank{"MTI Leader"},20f,green,true).apply{setPadding(0,dp(6),0,0)});val bio=value(o,"bio","biography","description");if(bio.isNotBlank())b.addView(tv(bio,15f,ink).apply{setPadding(0,dp(8),0,0)});addCard(b)}
    private fun sugCard(o:JSONObject){val b=baseCard();b.addView(tv(value(o,"office","position").ifBlank{"SUG Executive"},11f,gold,true));b.addView(tv(value(o,"full_name","name").ifBlank{"MTI Student Leader"},20f,green,true).apply{setPadding(0,dp(6),0,dp(3))});val bio=value(o,"biography","bio","description");if(bio.isNotBlank())b.addView(tv(bio,14.5f,ink));addCard(b)}
    private fun galleryCard(o:JSONObject){val b=baseCard();val image=value(o,"image_url","photo_url","media_url","url","file_url");if(image.isNotBlank()){val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_CROP;contentDescription=value(o,"title").ifBlank{"MTI gallery image"}};b.addView(iv,LinearLayout.LayoutParams(-1,dp(210)));exec.execute{try{val bmp=URL(image).openStream().use{BitmapFactory.decodeStream(it)};runOnUiThread{iv.setImageBitmap(bmp)}}catch(_:Exception){}}};b.addView(tv(value(o,"title","caption").ifBlank{"MTI Community"},17f,green,true).apply{setPadding(0,dp(9),0,dp(2))});val cat=value(o,"category","album");if(cat.isNotBlank())b.addView(tv(cat,12f,gold,true));addCard(b)}
    override fun onDestroy(){exec.shutdownNow();super.onDestroy()}
}
