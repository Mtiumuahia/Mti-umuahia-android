package ng.org.mtiumuahia.app

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class ManagementReportingActivity : Activity() {
    private val base = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val key = "sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private val executor = Executors.newSingleThreadExecutor()
    private var token = ""
    private val ink = Color.rgb(31, 47, 38)
    private val cream = Color.rgb(248, 245, 237)
    private val gold = Color.rgb(169, 132, 57)

    override fun onCreate(b: Bundle?) { super.onCreate(b); token = intent.getStringExtra("access_token") ?: ""; show() }
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun get(path:String):String {
        val c=URL(base+path).openConnection() as HttpURLConnection
        c.requestMethod="GET"; c.setRequestProperty("apikey",key); c.setRequestProperty("Authorization","Bearer $token"); c.setRequestProperty("Accept","application/json")
        val code=c.responseCode; val stream=if(code in 200..299)c.inputStream else c.errorStream
        val body=stream.bufferedReader().use{it.readText()}; if(code !in 200..299) throw Exception("Request failed ($code)"); return body
    }
    private fun root():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,28,28,28);setBackgroundColor(cream)}
    private fun text(v:String,size:Float=14f,bold:Boolean=false)=TextView(this).apply{this.text=v;textSize=size;setTextColor(ink);setPadding(0,8,0,8);if(bold)setTypeface(null,1)}
    private fun card(title:String,value:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,14,18,14);setBackgroundColor(Color.WHITE);addView(text(title.uppercase(),11f,true));addView(text(value,22f,true))}
    private fun button(label:String,action:()->Unit)=android.widget.Button(this).apply{text=label;setOnClickListener{action()}}
    private fun show(){
        val r=root();r.addView(text("MTI · UMUAHIA",12f,true));r.addView(text("Institutional Reporting & Executive Dashboard",24f,true));r.addView(text("Live descriptive indicators from existing management-readable records. This screen does not create a separate reporting database or alter academic records."));
        val summary=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(summary)
        r.addView(text("REPORTING SCOPE",12f,true));r.addView(text("Students · Lecturers · Courses · Applications · Payments · Published Results · Attendance",13f));
        r.addView(button("Refresh Report"){show()});r.addView(button("Open Management Command Centre"){openWeb("/management-dashboard")});r.addView(button("Back"){finish()});setContentView(r)
        summary.addView(card("Status","Loading current indicators…"))
        executor.execute{try{
            val students=JSONArray(get("/rest/v1/student_profiles?select=id&limit=10000"));
            val lecturers=JSONArray(get("/rest/v1/lecturer_profiles?select=id&limit=5000"));
            val courses=JSONArray(get("/rest/v1/academic_courses?select=id,active&limit=3000"));
            val apps=JSONArray(get("/rest/v1/applications?select=id,status&limit=10000"));
            val payments=JSONArray(get("/rest/v1/student_payments?select=id&limit=20000"));
            val results=JSONArray(get("/rest/v1/student_results?select=id,status&status=eq.published&limit=20000"));
            val attendance=JSONArray(get("/rest/v1/student_attendance_v123?select=id,status&limit=30000"));
            val activeCourses=(0 until courses.length()).count{courses.optJSONObject(it)?.optBoolean("active",false)==true};
            val submitted=(0 until apps.length()).count{val s=apps.optJSONObject(it)?.optString("status")?.lowercase();s=="submitted"};
            val present=(0 until attendance.length()).count{val s=attendance.optJSONObject(it)?.optString("status")?.lowercase();s=="present"};
            val late=(0 until attendance.length()).count{val s=attendance.optJSONObject(it)?.optString("status")?.lowercase();s=="late"};
            runOnUiThread{summary.removeAllViews();summary.addView(card("Students",students.length().toString()));summary.addView(card("Lecturers",lecturers.length().toString()));summary.addView(card("Active Courses","$activeCourses / ${courses.length()}"));summary.addView(card("Applications","${apps.length()} total · $submitted submitted"));summary.addView(card("Payment Records",payments.length().toString()));summary.addView(card("Published Result Records",results.length().toString()));summary.addView(card("Attendance Records","${attendance.length()} · $present present · $late late"));summary.addView(text("These are current record counts from the existing Supabase tables; they are descriptive snapshots, not forecasts or institutional performance ratings.",13f))}
        }catch(x:Exception){runOnUiThread{summary.removeAllViews();summary.addView(card("Report unavailable","Unable to load current indicators."));summary.addView(text("Use the full Management Command Centre for authoritative operational reports.",13f))}}}
    }
    private fun openWeb(path:String){startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(getString(R.string.mti_base_url)+path)))}
}
