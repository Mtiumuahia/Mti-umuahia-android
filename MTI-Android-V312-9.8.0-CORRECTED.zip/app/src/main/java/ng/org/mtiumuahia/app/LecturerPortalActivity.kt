package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class LecturerPortalActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(2)
    private val green = Color.rgb(11,61,46)
    private val darkGreen = Color.rgb(6,40,30)
    private val cream = Color.rgb(246,241,230)
    private val gold = Color.rgb(184,149,74)
    private val ink = Color.rgb(23,53,44)
    private val white = Color.WHITE
    private val supabaseUrl = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabaseKey = "sb_publishable_oWYV2aWyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken: String? = null
    private var userId: String? = null
    private var email: String? = null
    private var profile: JSONObject? = null
    private var assigned = JSONArray()
    private var classes = JSONArray()
    private var courses = JSONArray()
    private var sessions = JSONArray()

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE); showLogin() }
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun scroll(r:View)=ScrollView(this).apply{isFillViewport=true;addView(r)}
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(16),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun card(head:String,body:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));addView(text(head,16f,green,true));addView(text(body,13f,ink))}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun set(r:View){setContentView(scroll(r))}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Content-Type" to "application/json")
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";headers().forEach{(k,v)->c.setRequestProperty(k,v)};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return body}
    private fun postAuth(email:String,password:String):JSONObject{val c=URL("$supabaseUrl/auth/v1/token?grant_type=password").openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("apikey",supabaseKey);c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(JSONObject().put("email",email).put("password",password).toString().toByteArray())};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return JSONObject(body)}
    private fun parseError(body:String)=try{val j=JSONObject(body);j.optString("error_description").ifBlank{j.optString("msg").ifBlank{j.optString("message").ifBlank{"Request failed"}}}}catch(_:Exception){"Request failed"}

    private fun revokeSession(token:String){try{val c=URL("$supabaseUrl/auth/v1/logout").openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=10000;c.readTimeout=10000;c.setRequestProperty("apikey",supabaseKey);c.setRequestProperty("Authorization","Bearer $token");c.connect();c.inputStream?.close();c.disconnect()}catch(_:Exception){}}
    private fun showLogin(message:String=""){
        accessToken=null;userId=null;email=null;profile=null;assigned=JSONArray();classes=JSONArray()
        val r=root();r.setBackgroundColor(green);r.addView(text("METHODIST THEOLOGICAL INSTITUTE · UMUAHIA",12f,gold,true));r.addView(title("Lecturer Portal").apply{setTextColor(white)});r.addView(text("Secure academic workspace for teaching, learning materials, attendance and virtual classes.",15f,white))
        val emailInput=EditText(this).apply{hint="Lecturer email";inputType=33;setTextColor(white);setHintTextColor(Color.LTGRAY)}
        val passInput=EditText(this).apply{hint="Password";inputType=129;setTextColor(white);setHintTextColor(Color.LTGRAY)}
        r.addView(emailInput,LinearLayout.LayoutParams(-1,dp(56)).apply{setMargins(0,dp(10),0,dp(4))});r.addView(passInput,LinearLayout.LayoutParams(-1,dp(56)).apply{setMargins(0,dp(4),0,dp(10))})
        val status=text(message,14f,white);r.addView(status);r.addView(button("Sign In"){val e=emailInput.text.toString().trim();val p=passInput.text.toString();if(e.isBlank()||p.isBlank()){status.text="Enter your lecturer email and password.";return@button};status.text="Signing in…";executor.execute{try{val d=postAuth(e,p);accessToken=d.optString("access_token").ifBlank{throw Exception("No access token was returned.")};userId=d.optJSONObject("user")?.optString("id") ?: d.optString("user_id");email=e;loadProfile(status)}catch(x:Exception){runOnUiThread{status.text=x.message ?: "Sign in failed."}}}})
        r.addView(button("Back to MTI Website"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url))))})
        r.addView(text("Lecturer accounts are created and authorised by MTI Management. This app does not create lecturer accounts or change lecturer permissions.",13f,white))
        set(r)
    }
    private fun loadProfile(status:TextView){try{val uid=userId?:throw Exception("No authenticated MTI user was found.");val arr=JSONArray(get("/rest/v1/lecturer_profiles?select=*&user_id=eq.${URLEncoder.encode(uid,"UTF-8")}&limit=1"));if(arr.length()==0)throw Exception("No MTI lecturer profile is linked to this account.");profile=arr.getJSONObject(0);assigned=JSONArray(get("/rest/v1/lecturer_courses?select=*&lecturer_id=eq.${URLEncoder.encode(uid,"UTF-8")}&order=created_at.desc&limit=200"));classes=JSONArray(get("/rest/v1/online_classes?select=*&lecturer_id=eq.${URLEncoder.encode(uid,"UTF-8")}&order=scheduled_start.asc&limit=200"));runOnUiThread{showDashboard()}}catch(x:Exception){runOnUiThread{status.text=x.message?:"Lecturer profile could not be loaded."}}}
    private fun fullName():String{val p=profile?:JSONObject();return listOf(p.optString("first_name"),p.optString("middle_name"),p.optString("last_name")).filter{it.isNotBlank()}.joinToString(" ").ifBlank{p.optString("full_name").ifBlank{email?:"MTI Lecturer"}}}
    private fun courseId(o:JSONObject)=o.optString("course_id").ifBlank{o.optString("id")}
    private fun courseLabel(o:JSONObject):String { val code=o.optString("course_code").ifBlank{o.optString("code").ifBlank{"—"}}; val title=o.optString("course_title").ifBlank{o.optString("title").ifBlank{"Untitled Course"}}; return "$code — $title" }
    private fun fmt(v:String)=try{java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a",java.util.Locale("en","NG")).format(java.util.Date.from(java.time.Instant.parse(v)))}catch(_:Exception){v.ifBlank{"—"}}

    private fun showDashboard(){val r=root();r.addView(label("LECTURER ACADEMIC WORKSPACE"));r.addView(title("Welcome, ${fullName()}"));r.addView(text("Your authenticated MTI teaching workspace. Existing Supabase Auth, RLS and lecturer records remain the source of truth."));r.addView(label("ACCOUNT"));val p=profile?:JSONObject();r.addView(card("Staff Number",p.optString("staff_no").ifBlank{"Not available"}));r.addView(card("Department",p.optString("department").ifBlank{"Not available"}));r.addView(card("Email",email?:p.optString("email")));r.addView(label("TEACHING CENTRE"));r.addView(button("My Profile"){showProfile()});r.addView(button("Teaching Dashboard & Analytics"){showTeachingAnalytics()});r.addView(button("My Assigned Courses"){showCourses()});r.addView(button("Course & Class Management"){showCourseManagement()});r.addView(button("Online Classroom"){showOnline()});r.addView(button("Learning Materials"){showMaterials()});r.addView(button("Result Entry & Gradebook"){showGradebook()});r.addView(button("Attendance Management"){showAttendance()});r.addView(button("Notice Board"){showNotices()});r.addView(button("Open Full Lecturer Portal"){openWeb("/lecturer-portal")});r.addView(label("SECURITY"));r.addView(text("The Android lecturer layer only uses the authenticated lecturer's existing records. No service-role key, second database, or new permission model is introduced."));r.addView(button("Sign Out"){ val token=accessToken; accessToken=null; userId=null; email=null; profile=null; assigned=JSONArray(); classes=JSONArray(); if(!token.isNullOrBlank()) executor.execute { revokeSession(token) }; showLogin("You have been signed out. Please sign in again.") });set(r)}
    private fun showTeachingAnalytics() {
        val r = root()
        r.addView(label("TEACHING ANALYTICS"))
        r.addView(title("Teaching Dashboard"))
        r.addView(text("A read-only snapshot of your current MTI teaching workload. Figures are calculated from the existing lecturer, course, class, material, registration and academic-result records."))
        val summary = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val detail = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(summary); r.addView(label("COURSE SNAPSHOT")); r.addView(detail)
        r.addView(button("Refresh Analytics") { showTeachingAnalytics() })
        r.addView(button("Back to Dashboard") { showDashboard() })
        set(r)
        summary.addView(card("Loading analytics", "Reading your current teaching records…"))
        executor.execute {
            try {
                val uid = userId ?: throw Exception("No authenticated lecturer was found.")
                val activeAssignments = JSONArray(get("/rest/v1/lecturer_courses?select=*&lecturer_id=eq.${URLEncoder.encode(uid, "UTF-8")}&assignment_status=eq.active&limit=200"))
                val courseRows = JSONArray(get("/rest/v1/academic_courses?select=*&active=eq.true&limit=500"))
                val sessionRows = JSONArray(get("/rest/v1/online_classes?select=*&lecturer_id=eq.${URLEncoder.encode(uid, "UTF-8")}&order=scheduled_start.asc&limit=200"))
                val materialsRows = JSONArray(get("/rest/v1/lecturer_materials?select=id,published,created_at&lecturer_id=eq.${URLEncoder.encode(uid, "UTF-8")}&limit=500"))
                val resultRows = JSONArray(get("/rest/v1/student_results?select=id,status,course_id,created_at&entered_by=eq.${URLEncoder.encode(uid, "UTF-8")}&limit=1000"))
                val assignedIds = mutableSetOf<String>()
                for (i in 0 until activeAssignments.length()) {
                    val a = activeAssignments.getJSONObject(i); courseId(a).takeIf { it.isNotBlank() }?.let { assignedIds.add(it) }
                }
                var registeredTotal = 0
                val seenStudents = mutableSetOf<String>()
                val courseStats = mutableListOf<String>()
                for (cid in assignedIds) {
                    try {
                        val rows = JSONArray(get("/rest/v1/student_courses?select=student_id,id,course_id&course_id=eq.${URLEncoder.encode(cid, "UTF-8")}&limit=500"))
                        var count = 0
                        for (j in 0 until rows.length()) {
                            count++
                            val sid = rows.getJSONObject(j).optString("student_id").ifBlank { rows.getJSONObject(j).optString("id") }
                            if (sid.isNotBlank()) seenStudents.add(sid)
                        }
                        registeredTotal += count
                        val c = findCourseIn(courseRows, cid)
                        courseStats.add("${if (c != null) courseLabel(c) else "Course $cid"}: $count registered")
                    } catch (_: Exception) {
                        courseStats.add("Course $cid: registration count unavailable")
                    }
                }
                var upcoming = 0
                var activeSessions = 0
                val now = System.currentTimeMillis()
                for (i in 0 until sessionRows.length()) {
                    val x = sessionRows.getJSONObject(i)
                    val status = x.optString("status").lowercase()
                    if (status == "live" || status == "ongoing") activeSessions++
                    try {
                        val t = java.util.Date.from(java.time.Instant.parse(x.optString("scheduled_start"))).time
                        if (t >= now && status != "cancelled") upcoming++
                    } catch (_: Exception) {}
                }
                var publishedMaterials = 0
                var draftMaterials = 0
                for (i in 0 until materialsRows.length()) if (materialsRows.getJSONObject(i).optBoolean("published")) publishedMaterials++ else draftMaterials++
                var draftResults = 0
                var publishedResults = 0
                for (i in 0 until resultRows.length()) {
                    val st = resultRows.getJSONObject(i).optString("status").lowercase()
                    if (st == "published") publishedResults++ else draftResults++
                }
                runOnUiThread {
                    summary.removeAllViews()
                    summary.addView(card("Assigned Courses", activeAssignments.length().toString()))
                    summary.addView(card("Registered Students", seenStudents.size.toString().ifBlank { registeredTotal.toString() }))
                    summary.addView(card("Upcoming Virtual Sessions", upcoming.toString()))
                    summary.addView(card("Live / Ongoing Sessions", activeSessions.toString()))
                    summary.addView(card("Published Materials", publishedMaterials.toString()))
                    summary.addView(card("Draft Materials", draftMaterials.toString()))
                    summary.addView(card("Draft Results Entered", draftResults.toString()))
                    summary.addView(card("Published Results Entered", publishedResults.toString()))
                    detail.removeAllViews()
                    if (courseStats.isEmpty()) detail.addView(card("No active teaching assignments", "No active lecturer courses were returned for this account."))
                    else courseStats.forEach { detail.addView(card("Course", it)) }
                    detail.addView(text("Attendance and result details remain available in their dedicated management screens. This dashboard does not create or modify academic records.", 13f, ink))
                }
            } catch (x: Exception) {
                runOnUiThread {
                    summary.removeAllViews(); detail.removeAllViews()
                    summary.addView(card("Analytics unavailable", x.message ?: "Unable to load teaching analytics."))
                }
            }
        }
    }

    private fun showProfile(){val p=profile?:JSONObject();val r=root();r.addView(label("MY PROFILE"));r.addView(title("Lecturer Biodata"));r.addView(text("Personal information can be updated through the existing lecturer profile row. Institutional identity fields remain protected."));val fields=listOf("first_name","middle_name","last_name","full_name","phone","phone_number","date_of_birth","gender","address");val inputs=mutableMapOf<String,EditText>();fields.filter{p.has(it)}.forEach{k->val e=EditText(this).apply{setText(p.optString(k));hint=k.replace('_',' ').replaceFirstChar{it.uppercase()};setTextColor(ink);setHintTextColor(Color.GRAY)};inputs[k]=e;r.addView(e)};r.addView(card("Protected Institutional Identity","Staff Number: ${p.optString("staff_no").ifBlank{"—"}}\nDepartment: ${p.optString("department").ifBlank{"—"}}\nEmail: ${email?:p.optString("email").ifBlank{"—"}}"));val status=text("",14f);r.addView(status);r.addView(button("Save Biodata"){val id=p.optString("id");if(id.isBlank()){status.text="Lecturer profile ID is unavailable.";return@button};val obj=JSONObject();inputs.forEach{(k,e)->obj.put(k,e.text.toString().trim().ifBlank{JSONObject.NULL})};status.text="Saving…";executor.execute{try{patch("/rest/v1/lecturer_profiles?id=eq.${URLEncoder.encode(id,"UTF-8")}&user_id=eq.${URLEncoder.encode(userId?:"","UTF-8")}",obj);runOnUiThread{status.text="✓ Biodata saved successfully."}}catch(x:Exception){runOnUiThread{status.text="Unable to save: ${x.message}"}}}});r.addView(button("Back to Dashboard"){showDashboard()});set(r)}
    private fun patch(path:String,obj:JSONObject){val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="PATCH";c.doOutput=true;headers().forEach{(k,v)->c.setRequestProperty(k,v)};c.setRequestProperty("Prefer","return=minimal");c.outputStream.use{it.write(obj.toString().toByteArray())};val code=c.responseCode;val body=(if(code in 200..299)c.inputStream else c.errorStream).bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body))}
    private fun showCourseManagement() {
        val r = root()
        r.addView(label("COURSE & CLASS MANAGEMENT"))
        r.addView(title("Teaching Workspace"))
        r.addView(text("Manage the courses assigned to your MTI lecturer account and schedule virtual teaching sessions using the existing MTI course and online-class architecture."))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(box)
        r.addView(button("Back to Dashboard") { showDashboard() })
        set(r)
        box.addView(card("Loading teaching load", "Reading your current lecturer course assignments…"))
        executor.execute {
            try {
                val assignments = JSONArray(get("/rest/v1/lecturer_courses?select=*&lecturer_id=eq.${URLEncoder.encode(userId ?: "", "UTF-8")}&assignment_status=eq.active&order=created_at.desc&limit=200"))
                val courses = JSONArray(get("/rest/v1/academic_courses?select=*&active=eq.true&order=course_code.asc&limit=500"))
                val sessions = JSONArray(get("/rest/v1/online_classes?select=*&lecturer_id=eq.${URLEncoder.encode(userId ?: "", "UTF-8")}&order=scheduled_start.asc&limit=200"))
                runOnUiThread {
                    box.removeAllViews()
                    if (assignments.length() == 0) {
                        box.addView(card("No active assignments", "MTI Management has not returned any active lecturer course assignments for this account."))
                    } else {
                        for (i in 0 until assignments.length()) {
                            val a = assignments.getJSONObject(i)
                            val cid = courseId(a)
                            val c = findCourseIn(courses, cid)
                            val label = if (c != null) courseLabel(c) else "Course ${cid.ifBlank { "—" }}"
                            val relevant = mutableListOf<JSONObject>()
                            for (j in 0 until sessions.length()) {
                                val x = sessions.getJSONObject(j)
                                if (x.optString("course_id") == cid) relevant.add(x)
                            }
                            val body = listOf(a.optString("academic_session"), a.optString("semester"), a.optString("level")).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "Assignment details unavailable" } +
                                    "\n${relevant.size} scheduled virtual session${if (relevant.size == 1) "" else "s"}"
                            box.addView(button(label) { showCourseWorkspace(cid, label, a, relevant) })
                            box.addView(text(body, 12f, ink))
                        }
                    }
                }
            } catch (x: Exception) {
                runOnUiThread { box.removeAllViews(); box.addView(card("Unable to load courses", x.message ?: "Request failed")) }
            }
        }
    }

    private fun findCourseIn(courses: JSONArray, cid: String): JSONObject? {
        for (i in 0 until courses.length()) if (courses.getJSONObject(i).optString("id") == cid) return courses.getJSONObject(i)
        return null
    }

    private fun showCourseWorkspace(cid: String, labelText: String, assignment: JSONObject, sessions: List<JSONObject>) {
        val r = root()
        r.addView(label("COURSE WORKSPACE"))
        r.addView(title(labelText))
        r.addView(text("This workspace connects your assigned course to the existing MTI gradebook, attendance, learning-materials and virtual-class systems."))
        r.addView(card("Assignment", listOf(assignment.optString("academic_session"), assignment.optString("semester"), assignment.optString("level")).filter { it.isNotBlank() }.joinToString(" · ").ifBlank { "Active lecturer assignment" }))
        r.addView(button("Result Entry & Gradebook") { showGradebook() })
        r.addView(button("Attendance Management") { showAttendance() })
        r.addView(button("Learning Materials") { showMaterials() })
        r.addView(label("VIRTUAL CLASSES"))
        if (sessions.isEmpty()) r.addView(card("No scheduled sessions", "Create a virtual class session below when you are ready."))
        else for (x in sessions) {
            val meeting = x.optString("meeting_url").ifBlank { x.optString("meeting_link") }.ifBlank { x.optString("join_url") }
            val c = card(x.optString("title").ifBlank { "Online Session" }, "${x.optString("session_type").ifBlank { "class" }.replaceFirstChar { it.uppercase() }} · ${fmt(x.optString("scheduled_start"))}\nStatus: ${x.optString("status").ifBlank { "scheduled" }}")
            if (meeting.isNotBlank()) c.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(meeting))) }
            r.addView(c)
        }
        r.addView(button("Schedule New Virtual Session") { showCreateClass(cid, labelText) })
        r.addView(button("Back to Course Management") { showCourseManagement() })
        set(r)
    }

    private fun showCreateClass(cid: String, courseLabelText: String) {
        val r = root()
        r.addView(label("VIRTUAL CLASS SCHEDULER"))
        r.addView(title("Schedule a Session"))
        r.addView(card("Course", courseLabelText))
        val titleInput = EditText(this).apply { hint = "Session title"; setTextColor(ink); setHintTextColor(Color.GRAY) }
        val description = EditText(this).apply { hint = "Description (optional)"; setTextColor(ink); setHintTextColor(Color.GRAY); minLines = 2 }
        val type = android.widget.Spinner(this).apply { adapter = android.widget.ArrayAdapter(this@LecturerPortalActivity, android.R.layout.simple_spinner_dropdown_item, listOf("class", "conference")) }
        val provider = EditText(this).apply { hint = "Meeting provider (e.g. Zoom, Google Meet)"; setTextColor(ink); setHintTextColor(Color.GRAY) }
        val url = EditText(this).apply { hint = "Meeting URL (https://...)"; inputType = 33; setTextColor(ink); setHintTextColor(Color.GRAY) }
        val start = EditText(this).apply { hint = "Start (ISO, e.g. 2026-09-21T10:00:00+01:00)"; setTextColor(ink); setHintTextColor(Color.GRAY) }
        val end = EditText(this).apply { hint = "End (ISO, e.g. 2026-09-21T12:00:00+01:00)"; setTextColor(ink); setHintTextColor(Color.GRAY) }
        r.addView(titleInput); r.addView(description); r.addView(label("SESSION TYPE")); r.addView(type); r.addView(provider); r.addView(url); r.addView(start); r.addView(end)
        val status = text("", 13f, ink); r.addView(status)
        r.addView(button("Create Scheduled Session") {
            val ttl = titleInput.text.toString().trim(); val link = url.text.toString().trim(); val st = start.text.toString().trim(); val en = end.text.toString().trim()
            if (ttl.isBlank() || st.isBlank() || en.isBlank()) { status.text = "Enter the session title, start time and end time."; return@button }
            if (link.isBlank() || !(link.startsWith("https://"))) { status.text = "Enter a valid meeting URL."; return@button }
            status.text = "Creating session…"
            executor.execute {
                try {
                    val payload = JSONObject().put("course_id", cid).put("lecturer_id", userId).put("title", ttl).put("description", description.text.toString().trim().ifBlank { JSONObject.NULL }).put("session_type", type.selectedItem.toString()).put("meeting_provider", provider.text.toString().trim().ifBlank { JSONObject.NULL }).put("meeting_url", link).put("scheduled_start", st).put("scheduled_end", en).put("status", "scheduled")
                    val created = JSONArray(post("/rest/v1/online_classes", payload.toString()))
                    val classId = if (created.length() > 0) created.getJSONObject(0).optString("id") else ""
                    if (classId.isNotBlank()) {
                        try { post("/rest/v1/online_meeting_config", JSONObject().put("online_class_id", classId).put("provider", provider.text.toString().trim().ifBlank { "custom" }).put("meeting_url", link).put("host_user_id", userId).toString()) } catch (_: Exception) {}
                        try { post("/rest/v1/online_class_features", JSONObject().put("online_class_id", classId).put("chat_enabled", true).put("attendance_enabled", true).put("recording_enabled", false).toString()) } catch (_: Exception) {}
                    }
                    runOnUiThread { status.text = "✓ Virtual session scheduled successfully." }
                } catch (x: Exception) { runOnUiThread { status.text = "Unable to schedule session: ${x.message ?: "Request failed"}" } }
            }
        })
        r.addView(button("Back to Course Workspace") { showCourseManagement() })
        set(r)
    }

    private fun showCourses(){val r=root();r.addView(label("TEACHING LOAD"));r.addView(title("My Assigned Courses"));r.addView(text("These assignments are read from the existing MTI lecturer course records."));val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(box);r.addView(button("Back to Dashboard"){showDashboard()});set(r);executor.execute{runOnUiThread{box.removeAllViews();if(assigned.length()==0)box.addView(card("No assigned courses","No current lecturer course assignments were returned."));for(i in 0 until assigned.length()){val x=assigned.getJSONObject(i);val details=listOf(x.optString("academic_session"),x.optString("semester"),x.optString("level")).filter{it.isNotBlank()}.joinToString(" · ").ifBlank{"Assignment details unavailable"};box.addView(card(courseLabel(x),details))}}}}
    private fun showOnline(){val r=root();r.addView(label("ONLINE CLASSROOM"));r.addView(title("Virtual Teaching Centre"));r.addView(text("View your scheduled virtual sessions. Session creation and provider configuration remain available through the existing MTI Lecturer Portal."));val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(box);r.addView(button("Open Full Online Classroom"){openWeb("/online-classroom")});r.addView(button("Back to Dashboard"){showDashboard()});set(r);executor.execute{try{val arr=JSONArray(get("/rest/v1/online_classes?select=*&lecturer_id=eq.${URLEncoder.encode(userId?:"","UTF-8")}&order=scheduled_start.asc&limit=200"));classes=arr;runOnUiThread{box.removeAllViews();if(arr.length()==0)box.addView(card("No virtual sessions","No online classes or conference sessions are currently scheduled for your account."));for(i in 0 until arr.length()){val x=arr.getJSONObject(i);val body="${x.optString("course_code").ifBlank{"Course"}}\n${x.optString("session_type").ifBlank{"class"}.replaceFirstChar{it.uppercase()}} · ${fmt(x.optString("scheduled_start"))}\nStatus: ${x.optString("status").ifBlank{"scheduled"}}";val c=card(x.optString("title").ifBlank{"Online Session"},body);if(x.optString("meeting_url").isNotBlank())c.setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(x.optString("meeting_url"))))};box.addView(c)}}}catch(x:Exception){runOnUiThread{box.removeAllViews();box.addView(card("Unable to load sessions",x.message?:"Request failed"))}}}}
    private fun post(path:String, body:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;headers().forEach{(k,v)->c.setRequestProperty(k,v)};c.setRequestProperty("Prefer","return=representation");c.outputStream.use{it.write(body.toByteArray())};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val out=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(out));return out}

    private fun showMaterials() {
        val r = root()
        r.addView(label("LEARNING MATERIALS"))
        r.addView(title("Lecturer Materials"))
        r.addView(text("Create resource records for your assigned courses and publish them to students through the existing MTI Digital Library."))
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(form)
        val course = android.widget.Spinner(this)
        val titles = assignedLabels()
        course.adapter = android.widget.ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, titles.first)
        form.addView(label("COURSE")); form.addView(course)
        val titleInput = EditText(this).apply { hint = "Resource title"; setTextColor(ink); setHintTextColor(Color.GRAY) }
        form.addView(titleInput)
        val type = android.widget.Spinner(this)
        type.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayOf("document", "pdf", "slide", "video", "audio", "link", "note"))
        form.addView(label("TYPE")); form.addView(type)
        val url = EditText(this).apply { hint = "Resource URL (https://...)"; inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI; setTextColor(ink); setHintTextColor(Color.GRAY) }
        form.addView(url)
        val desc = EditText(this).apply { hint = "Description (optional)"; minLines = 3; gravity = android.view.Gravity.TOP; setTextColor(ink); setHintTextColor(Color.GRAY) }
        form.addView(desc)
        val publish = android.widget.CheckBox(this).apply { text = "Publish to students now"; setTextColor(ink) }
        form.addView(publish)
        val status = text("", 13f, ink); form.addView(status)
        form.addView(button("Save Resource") {
            val idx = course.selectedItemPosition
            if (idx < 0 || idx >= titles.second.size) { status.text = "Select an assigned course."; return@button }
            val cid = titles.second[idx]
            val ttl = titleInput.text.toString().trim()
            val link = url.text.toString().trim()
            if (ttl.isBlank()) { status.text = "Enter a resource title."; return@button }
            if (link.isBlank() || !link.startsWith("https://")) { status.text = "Enter a valid resource URL."; return@button }
            status.text = "Saving…"
            executor.execute {
                try {
                    val payload = JSONObject().put("lecturer_id", userId).put("course_id", cid).put("title", ttl).put("material_type", type.selectedItem.toString()).put("file_url", link).put("description", desc.text.toString().trim().ifBlank { JSONObject.NULL }).put("published", publish.isChecked)
                    post("/rest/v1/lecturer_materials", payload.toString())
                    runOnUiThread { status.text = "✓ Resource saved successfully."; showMaterials() }
                } catch (x: Exception) {
                    runOnUiThread { status.text = "Unable to save: ${x.message ?: "Request failed"}" }
                }
            }
        })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(label("MY RESOURCES")); r.addView(box)
        r.addView(button("Open Full Learning Materials") { openWeb("/lecturer-portal#materials") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        set(r)
        executor.execute {
            try {
                val arr = JSONArray(get("/rest/v1/lecturer_materials?select=*&lecturer_id=eq.${URLEncoder.encode(userId ?: "", "UTF-8")}&order=created_at.desc&limit=200"))
                runOnUiThread {
                    box.removeAllViews()
                    if (arr.length() == 0) box.addView(card("No materials", "No lecturer resources have been created yet."))
                    for (i in 0 until arr.length()) {
                        val x = arr.getJSONObject(i)
                        val body = "${x.optString("material_type").ifBlank { "Resource" }} · ${if (x.optBoolean("published")) "Published" else "Draft"}\n${x.optString("description").ifBlank { "No description" }}"
                        val c = card(x.optString("title").ifBlank { "Untitled Resource" }, body)
                        val u = x.optString("file_url")
                        if (u.isNotBlank()) c.setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
                        box.addView(c)
                    }
                }
            } catch (x: Exception) {
                runOnUiThread { box.removeAllViews(); box.addView(card("Unable to load materials", x.message ?: "Request failed")) }
            }
        }
    }

    private fun assignedLabels():Pair<List<String>,List<String>>{val labels=mutableListOf<String>();val ids=mutableListOf<String>();for(i in 0 until assigned.length()){val c=assigned.getJSONObject(i);val id=courseId(c);if(id.isBlank())continue;labels.add(courseLabel(c));ids.add(id)};return labels to ids}


    private fun gradeFor(score: Double): Pair<String, Int> = when {
        score >= 70 -> "A" to 5
        score >= 60 -> "B" to 4
        score >= 50 -> "C" to 3
        score >= 45 -> "D" to 2
        score >= 40 -> "E" to 1
        else -> "F" to 0
    }

    private fun showGradebook() {
        val r = root()
        r.addView(label("ACADEMIC GRADEBOOK"))
        r.addView(title("Result Entry & Gradebook"))
        r.addView(text("Enter draft results for registered students in an active assigned course. The existing MTI gradebook RPC remains the save authority."))
        val board = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        r.addView(board)
        r.addView(button("Back to Dashboard") { showDashboard() })
        set(r)
        executor.execute {
            try {
                val assignments = JSONArray(get("/rest/v1/lecturer_courses?select=*&lecturer_id=eq.${URLEncoder.encode(userId ?: "", "UTF-8")}&assignment_status=eq.active&limit=200"))
                courses = JSONArray(get("/rest/v1/academic_courses?select=id,course_code,course_title,credit_load,active&active=eq.true&order=course_code.asc&limit=500"))
                sessions = JSONArray(get("/rest/v1/academic_sessions_v89?select=*&status=eq.active&order=session_name.desc&limit=50"))
                runOnUiThread {
                    board.removeAllViews()
                    val open = mutableListOf<Pair<String, String>>()
                    for (i in 0 until sessions.length()) {
                        val x = sessions.getJSONObject(i)
                        if (x.optBoolean("result_entry_open")) open.add(x.optString("session_name") to x.optString("semester"))
                    }
                    if (open.isEmpty()) {
                        board.addView(card("Result entry is closed", "There is no active MTI result-entry window."))
                        return@runOnUiThread
                    }
                    val session = open.first().first
                    val semester = open.first().second
                    board.addView(text("Open window: $session · $semester", 13f, ink, true))
                    if (assignments.length() == 0) {
                        board.addView(card("No active assignments", "No active lecturer course assignments were returned."))
                        return@runOnUiThread
                    }
                    for (i in 0 until assignments.length()) {
                        val a = assignments.getJSONObject(i)
                        val c = findCourse(a.optString("course_id")) ?: continue
                        board.addView(button("${c.optString("course_code")} — ${c.optString("course_title")}") {
                            loadGradebook(a.optString("course_id"), session, semester, board)
                        })
                    }
                    board.addView(text("Select an assigned course to load its registered-student roster.", 13f, ink))
                }
            } catch (x: Exception) {
                runOnUiThread { board.addView(card("Unable to load gradebook", x.message ?: "Request failed")) }
            }
        }
    }

    private fun findCourse(cid: String): JSONObject? {
        for (i in 0 until courses.length()) {
            val c = courses.getJSONObject(i)
            if (c.optString("id") == cid) return c
        }
        return null
    }

    private fun loadGradebook(cid: String, session: String, semester: String, board: LinearLayout) {
        board.removeAllViews()
        board.addView(card("Loading gradebook", "Loading registered students and existing draft results…"))
        executor.execute {
            try {
                val en = JSONArray(get("/rest/v1/student_courses?select=*&course_id=eq.${URLEncoder.encode(cid, "UTF-8")}&limit=500"))
                val profiles = JSONArray(get("/rest/v1/student_profiles?select=*&limit=1000"))
                val existing = JSONArray(get("/rest/v1/student_results?select=*&course_id=eq.${URLEncoder.encode(cid, "UTF-8")}&semester=eq.${URLEncoder.encode(semester, "UTF-8")}&entered_by=eq.${URLEncoder.encode(userId ?: "", "UTF-8")}&order=created_at.desc&limit=1000"))
                val ids = mutableSetOf<String>()
                for (i in 0 until en.length()) ids.add(en.getJSONObject(i).optString("student_id"))
                val roster = mutableListOf<JSONObject>()
                for (i in 0 until profiles.length()) {
                    val student = profiles.getJSONObject(i)
                    if (ids.contains(student.optString("id"))) roster.add(student)
                }
                roster.sortBy { it.optString("student_number") }
                runOnUiThread { renderGradebook(cid, session, semester, roster, existing, board) }
            } catch (x: Exception) {
                runOnUiThread { board.removeAllViews(); board.addView(card("Unable to load roster", x.message ?: "Request failed")) }
            }
        }
    }

    private fun renderGradebook(cid: String, session: String, semester: String, roster: List<JSONObject>, existing: JSONArray, board: LinearLayout) {
        board.removeAllViews()
        val course = findCourse(cid)
        val courseName = if (course != null) "${course.optString("course_code")} — ${course.optString("course_title")}" else "Gradebook"
        board.addView(card(courseName, "$session · $semester · ${roster.size} registered students"))
        val rows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val entries = mutableListOf<Triple<String, EditText, EditText>>()
        for (student in roster) {
            var old: JSONObject? = null
            for (i in 0 until existing.length()) {
                val candidate = existing.getJSONObject(i)
                if (candidate.optString("student_id") == student.optString("id")) { old = candidate; break }
            }
            val name = listOf(student.optString("first_name"), student.optString("middle_name"), student.optString("last_name"))
                .filter { it.isNotBlank() }.joinToString(" ").ifBlank { student.optString("full_name").ifBlank { "Unnamed Student" } }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(white)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
            }
            box.addView(text(name, 15f, green, true))
            box.addView(text("Student No.: ${student.optString("student_number").ifBlank { "—" }}", 12f, ink))
            val score = EditText(this).apply {
                hint = "Score (0–100)"
                inputType = 2 or 8192
                if (old?.has("score") == true && !old!!.isNull("score")) setText(old!!.optString("score"))
                setTextColor(ink)
            }
            val remark = EditText(this).apply {
                hint = "Optional remark"
                setText(old?.optString("remark") ?: "")
                setTextColor(ink)
            }
            val gradeView = text("Grade: ${old?.optString("grade")?.ifBlank { "—" } ?: "—"} · GP: ${old?.optString("grade_points")?.ifBlank { "—" } ?: "—"}", 12f, ink)
            score.setOnFocusChangeListener { _, _ -> updateGrade(score, gradeView) }
            score.setOnKeyListener { _, _, _ -> updateGrade(score, gradeView); false }
            box.addView(score); box.addView(remark); box.addView(gradeView); rows.addView(box)
            entries.add(Triple(student.optString("id"), score, remark))
        }
        if (roster.isEmpty()) rows.addView(card("No registered students", "No students are currently registered for this course."))
        board.addView(rows)
        board.addView(button("Save All Drafts") { saveGradeRows(cid, semester, entries, board) })
        board.addView(button("Back to Gradebook Courses") { showGradebook() })
    }

    private fun updateGrade(score: EditText, view: TextView) {
        val n = score.text.toString().toDoubleOrNull()
        if (n == null || n !in 0.0..100.0) { view.text = "Grade: — · GP: —"; return }
        val g = gradeFor(n)
        view.text = "Grade: ${g.first} · GP: ${g.second}"
    }

    private fun saveGradeRows(cid: String, semester: String, entries: List<Triple<String, EditText, EditText>>, board: LinearLayout) {
        val rows = JSONArray()
        for ((studentId, scoreInput, remarkInput) in entries) {
            val n = scoreInput.text.toString().toDoubleOrNull() ?: continue
            if (n !in 0.0..100.0) continue
            val g = gradeFor(n)
            rows.put(JSONObject().put("student_id", studentId).put("score", n).put("grade", g.first).put("grade_points", g.second).put("remark", remarkInput.text.toString().trim().ifBlank { JSONObject.NULL }))
        }
        if (rows.length() == 0) { board.addView(card("Nothing saved", "Enter at least one valid score between 0 and 100.")); return }
        executor.execute {
            try {
                val result = postRpc("mti_bulk_save_student_results_v91", JSONObject().put("p_course_id", cid).put("p_semester", semester).put("p_section", JSONObject.NULL).put("p_rows", rows))
                runOnUiThread { board.addView(card("Draft results saved", result.optString("message").ifBlank { result.toString() })) }
            } catch (x: Exception) {
                runOnUiThread { board.addView(card("Unable to save results", x.message ?: "Request failed")) }
            }
        }
    }

    private fun postRpc(name: String, body: JSONObject): JSONObject {
        val c = URL("$supabaseUrl/rest/v1/rpc/$name").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; headers().forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val response = stream.bufferedReader().use { it.readText() }
        c.disconnect()
        if (code !in 200..299) throw Exception(parseError(response))
        return try { JSONObject(response) } catch (_: Exception) { JSONObject().put("message", response) }
    }

    private fun showAttendance(messageText: String? = null) {
        val r = root()
        r.addView(label("ATTENDANCE CENTRE"))
        r.addView(title("Class Attendance"))
        r.addView(text("Record attendance only for courses assigned to you. Each student's attendance is securely linked to the Student Portal."))
        val courseBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sheet = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val status = text(messageText ?: "Choose an assigned course and attendance date.", 13f, ink)
        r.addView(label("TEACHING CLASS")); r.addView(courseBox); r.addView(status); r.addView(sheet)
        r.addView(button("Open Full Attendance Centre") { openWeb("/lecturer-portal#attendance") })
        r.addView(button("Back to Dashboard") { showDashboard() })
        set(r)
        val courseNames = mutableListOf<String>()
        val courseIds = mutableListOf<String>()
        val courseSessions = mutableListOf<String>()
        val courseSemesters = mutableListOf<String>()
        val spinner = android.widget.Spinner(this)
        val labels = mutableListOf("Choose an assigned course")
        for (i in 0 until assigned.length()) {
            val a = assigned.getJSONObject(i)
            val cid = courseId(a)
            val c = findCourse(cid)
            if (c != null) {
                courseIds.add(cid)
                courseNames.add(courseLabel(c))
                courseSessions.add(a.optString("academic_session").ifBlank { c.optString("academic_session") })
                courseSemesters.add(a.optString("semester").ifBlank { c.optString("semester") })
                labels.add(courseLabel(c))
            }
        }
        spinner.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val date = EditText(this).apply {
            hint = "Attendance date (YYYY-MM-DD)"
            setText(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date()))
            inputType = 1
            setTextColor(ink); setHintTextColor(Color.GRAY)
        }
        courseBox.addView(spinner); courseBox.addView(date)
        val load = button("Load Attendance Sheet") {
            val pos = spinner.selectedItemPosition
            if (pos <= 0 || pos > courseIds.size) { status.text = "Select an assigned course first."; return@button }
            val d = date.text.toString().trim()
            if (!d.matches(Regex("\\d{4}-\\d{2}-\\d{2}"))) { status.text = "Enter the attendance date as YYYY-MM-DD."; return@button }
            loadAttendanceRoster(courseIds[pos - 1], courseSessions[pos - 1], courseSemesters[pos - 1], d, courseNames[pos - 1], sheet, status)
        }
        courseBox.addView(load)
    }

    private fun loadAttendanceRoster(cid: String, session: String, semester: String, date: String, courseName: String, sheet: LinearLayout, status: TextView) {
        sheet.removeAllViews(); sheet.addView(card("Attendance Sheet", "Loading enrolled students…")); status.text = ""
        executor.execute {
            try {
                val roster = postRpc("mti_get_lecturer_attendance_roster_v124", JSONObject().put("p_course_id", cid).put("p_academic_session", session.ifBlank { JSONObject.NULL }).put("p_semester", semester.ifBlank { JSONObject.NULL }))
                val rows = when {
                    roster.has("data") && roster.opt("data") is JSONArray -> roster.getJSONArray("data")
                    roster.has("rows") && roster.opt("rows") is JSONArray -> roster.getJSONArray("rows")
                    roster is JSONObject -> JSONArray().apply { put(roster) }
                    else -> JSONArray()
                }
                runOnUiThread { renderAttendanceSheet(cid, session, semester, date, courseName, rows, sheet, status) }
            } catch (x: Exception) {
                runOnUiThread { sheet.removeAllViews(); sheet.addView(card("Unable to load attendance roster", x.message ?: "Request failed")); status.text = "" }
            }
        }
    }

    private fun renderAttendanceSheet(cid: String, session: String, semester: String, date: String, courseName: String, roster: JSONArray, sheet: LinearLayout, status: TextView) {
        sheet.removeAllViews()
        sheet.addView(card(courseName, "$date · ${roster.length()} registered student${if (roster.length() == 1) "" else "s"}"))
        val entries = mutableListOf<Triple<String, android.widget.Spinner, EditText>>()
        for (i in 0 until roster.length()) {
            val x = roster.getJSONObject(i)
            val studentId = x.optString("student_id").ifBlank { x.optString("id") }
            val name = listOf(x.optString("first_name"), x.optString("middle_name"), x.optString("last_name")).filter { it.isNotBlank() }.joinToString(" ").ifBlank { "Student" }
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(white); setPadding(dp(12), dp(8), dp(12), dp(8)); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) } }
            box.addView(text(name, 15f, green, true)); box.addView(text("Student No.: ${x.optString("student_number").ifBlank { "—" }}", 12f, ink))
            val statusSpinner = android.widget.Spinner(this)
            statusSpinner.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("present", "late", "absent", "excused"))
            val note = EditText(this).apply { hint = "Optional note"; setTextColor(ink); setHintTextColor(Color.GRAY) }
            box.addView(statusSpinner); box.addView(note); sheet.addView(box); entries.add(Triple(studentId, statusSpinner, note))
        }
        if (roster.length() == 0) sheet.addView(card("No registered students", "No students are currently registered for this course."))
        sheet.addView(button("Save Attendance") { saveAttendance(cid, session, semester, date, entries, sheet, status) })
    }

    private fun saveAttendance(cid: String, session: String, semester: String, date: String, entries: List<Triple<String, android.widget.Spinner, EditText>>, sheet: LinearLayout, status: TextView) {
        if (entries.isEmpty()) { status.text = "There are no students to record."; return }
        status.text = "Saving attendance…"
        executor.execute {
            try {
                for ((studentId, spinner, note) in entries) {
                    postRpc("mti_record_student_attendance_v123", JSONObject().put("p_student_id", studentId).put("p_course_id", cid).put("p_academic_session", session).put("p_semester", semester).put("p_attendance_date", date).put("p_status", spinner.selectedItem.toString()).put("p_schedule_id", JSONObject.NULL).put("p_note", note.text.toString().trim().ifBlank { JSONObject.NULL }))
                }
                runOnUiThread { status.text = "✓ Attendance saved successfully." }
            } catch (x: Exception) {
                runOnUiThread { status.text = "Unable to save attendance: ${x.message ?: "Request failed"}" }
            }
        }
    }

    private fun showNotices(){val r=root();r.addView(label("NOTICE BOARD"));r.addView(title("Official Communications"));val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(box);r.addView(button("Open Full Notice Board"){openWeb("/lecturer-portal#notices")});r.addView(button("Back to Dashboard"){showDashboard()});set(r);executor.execute{try{val arr=JSONArray(get("/rest/v1/portal_announcements?select=*&order=created_at.desc&limit=30"));runOnUiThread{box.removeAllViews();if(arr.length()==0)box.addView(card("No notices","No current notices were returned."));for(i in 0 until arr.length()){val x=arr.getJSONObject(i);box.addView(card(x.optString("title").ifBlank{"MTI Notice"},x.optString("body").ifBlank{x.optString("content").ifBlank{"No content"}}))}}}catch(x:Exception){runOnUiThread{box.removeAllViews();box.addView(card("Unable to load notices",x.message?:"Request failed"))}}}}
    private fun openWeb(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    override fun onBackPressed(){super.onBackPressed()}
}
