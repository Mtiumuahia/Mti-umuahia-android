package ng.org.mtiumuahia.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class CommunityActivity : Activity() {
    private val cream = Color.rgb(247, 244, 237)
    private val green = Color.rgb(11, 61, 46)
    private val gold = Color.rgb(190, 157, 82)
    private val ink = Color.rgb(25, 45, 39)
    private val muted = Color.rgb(91, 105, 99)
    private val white = Color.WHITE
    private val supabaseUrl = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabaseKey = "sb_publishable_oWY2vA2WyoQ4SnLYJHKVbhQ_2V-_TZal"
    private val executor = Executors.newSingleThreadExecutor()
    private var accessToken: String? = null
    private var userId: String? = null
    private var email: String? = null
    private lateinit var root: LinearLayout
    private lateinit var body: LinearLayout
    private var activeTab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        showLogin()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(s: String, size: Float = 14f, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color); setLineSpacing(0f, 1.16f)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun button(s: String, click: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; textSize = 14f; setTextColor(white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(green)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { setMargins(dp(18), dp(5), dp(18), dp(5)) }
    }
    private fun field(hint: String, password: Boolean = false) = EditText(this).apply {
        this.hint = hint; textSize = 15f; setPadding(dp(15), dp(8), dp(15), dp(8))
        if (password) inputType = 0x81
        layoutParams = LinearLayout.LayoutParams(-1, dp(56)).apply { setMargins(dp(18), dp(4), dp(18), dp(4)) }
    }
    private fun rootLayout() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cream) }
    private fun scroll(v: View) = ScrollView(this).apply { isFillViewport = true; addView(v) }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(15), dp(16), dp(15))
        background = android.graphics.drawable.GradientDrawable().apply { setColor(white); cornerRadius = dp(18).toFloat() }
        elevation = dp(2).toFloat()
    }
    private fun header(title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(20), dp(18), dp(18)); setBackgroundColor(green)
        addView(tv("MTI COMMUNITY", 11f, gold, true)); addView(tv(title, 27f, white, true).apply { setPadding(0, dp(4), 0, dp(5)) }); addView(tv(subtitle, 14f, white))
    }

    private fun showLogin(message: String? = null) {
        val r = rootLayout(); r.addView(header("A community that connects.", "Sign in with your existing MTI account to use Feed, Chats and Groups."))
        r.addView(tv("Community uses the existing MTI Supabase authentication. It does not create a second account.", 14f, ink).apply { setPadding(dp(18), dp(18), dp(18), dp(8)) })
        val e = field("MTI email address"); val p = field("Password", true); r.addView(e); r.addView(p)
        val status = tv(message ?: "", 14f, ink).apply { setPadding(dp(18), dp(8), dp(18), dp(8)) }; r.addView(status)
        r.addView(button("Sign in to MTI Community") {
            val em = e.text.toString().trim().lowercase(); val pw = p.text.toString()
            if (em.isBlank() || pw.isBlank()) { status.text = "Enter your MTI email and password."; return@button }
            status.text = "Authenticating…"
            executor.execute {
                try {
                    val obj = requestJson("POST", "/auth/v1/token?grant_type=password", JSONObject().put("email", em).put("password", pw).toString(), false)
                    val token = obj.optString("access_token"); val uid = obj.optJSONObject("user")?.optString("id")
                    if (token.isBlank() || uid.isNullOrBlank()) throw Exception("The MTI session could not be established.")
                    accessToken = token; userId = uid; email = em
                    runOnUiThread { showCommunity() }
                } catch (x: Exception) { runOnUiThread { status.text = x.message ?: "Sign in failed." } }
            }
        })
        r.addView(tv("Use the same credentials you use for an activated MTI account.", 13f, muted).apply { setPadding(dp(18), dp(12), dp(18), dp(20)) })
        setContentView(scroll(r))
    }

    private fun showCommunity() {
        val r = rootLayout()
        val top = header("A community that connects.", "Share, discover and communicate with the MTI family.")
        r.addView(top)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(12), dp(10), dp(12), dp(10)) }
        listOf("Feed", "Chats", "Groups").forEachIndexed { i, label ->
            val b = TextView(this@CommunityActivity).apply {
                text = label; gravity = Gravity.CENTER; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(8), dp(12), dp(8), dp(12)); isClickable = true
                setTextColor(if (activeTab == i) white else green)
                background = android.graphics.drawable.GradientDrawable().apply { setColor(if (activeTab == i) green else Color.TRANSPARENT); cornerRadius = dp(15).toFloat() }
                setOnClickListener { activeTab = i; showCommunity() }
            }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        r.addView(tabs)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), dp(30)) }
        r.addView(body)
        r.addView(button("Sign out") { signOut() })
        setContentView(scroll(r))
        when (activeTab) { 0 -> loadFeed(); 1 -> loadChats(); 2 -> loadGroups() }
    }

    private fun loadFeed() {
        body.removeAllViews()
        val add = button("＋  Create a post") { createPostDialog() }; body.addView(add)
        body.addView(tv("Latest from the MTI family", 18f, ink, true).apply { setPadding(0, dp(10), 0, dp(8)) })
        body.addView(tv("Loading community feed…", 14f, muted))
        executor.execute {
            try {
                val arr = JSONArray(requestText("GET", "/rest/v1/community_posts?select=*&order=created_at.desc&limit=50", null, true))
                runOnUiThread { renderFeed(arr) }
            } catch (x: Exception) { runOnUiThread { showError("Feed", x) } }
        }
    }

    private fun renderFeed(arr: JSONArray) {
        body.removeAllViews(); body.addView(button("＋  Create a post") { createPostDialog() })
        if (arr.length() == 0) { body.addView(tv("No community posts yet. Be the first to share something with the MTI family.", 14f, muted).apply { setPadding(0, dp(15), 0, dp(15)) }); return }
        for (i in 0 until arr.length()) {
            val post = arr.getJSONObject(i); val id = post.optString("id"); val box = card()
            val name = post.optString("display_name").ifBlank { "MTI Member" }
            box.addView(tv(name, 16f, green, true)); box.addView(tv(post.optString("created_at").replace("T", " ").take(16), 11f, muted).apply { setPadding(0, dp(3), 0, dp(10)) })
            box.addView(tv(post.optString("body"), 15f, ink))
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(12), 0, 0) }
            val like = TextView(this).apply { text = "♡ ${post.optInt("reaction_count", 0)}"; textSize = 13f; setTextColor(green); isClickable = true; setPadding(0, dp(7), dp(18), dp(7)); setOnClickListener { toggleLike(id) } }
            val comments = TextView(this).apply { text = "💬 ${post.optInt("comment_count", 0)}"; textSize = 13f; setTextColor(green); isClickable = true; setPadding(dp(8), dp(7), dp(18), dp(7)); setOnClickListener { commentsDialog(id, name) } }
            val share = TextView(this).apply { text = "↗ Share"; textSize = 13f; setTextColor(green); isClickable = true; setPadding(dp(8), dp(7), dp(8), dp(7)); setOnClickListener { sharePost(post.optString("body")) } }
            actions.addView(like); actions.addView(comments); actions.addView(share); box.addView(actions)
            box.setOnClickListener { commentsDialog(id, name) }
            body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
    }

    private fun createPostDialog() {
        val input = EditText(this).apply { hint = "What would you like to share?"; minLines = 4; gravity = Gravity.TOP; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        AlertDialog.Builder(this).setTitle("Create a post").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Post") { _, _ ->
            val text = input.text.toString().trim(); if (text.isBlank()) return@setPositiveButton
            executor.execute {
                try { requestText("POST", "/rest/v1/community_posts", JSONObject().put("author_id", userId).put("body", text).toString(), true); runOnUiThread { loadFeed() } }
                catch (x: Exception) { runOnUiThread { toast(x.message ?: "Could not publish post.") } }
            }
        }.show()
    }

    private fun toggleLike(postId: String) {
        executor.execute {
            try {
                val q = "/rest/v1/community_reactions?select=id&post_id=eq.${URLEncoder.encode(postId, "UTF-8")}&user_id=eq.${URLEncoder.encode(userId ?: "", "UTF-8")}&reaction_type=eq.like&limit=1"
                val arr = JSONArray(requestText("GET", q, null, true))
                if (arr.length() > 0) requestText("DELETE", "/rest/v1/community_reactions?id=eq.${URLEncoder.encode(arr.getJSONObject(0).optString("id"), "UTF-8")}", null, true)
                else requestText("POST", "/rest/v1/community_reactions", JSONObject().put("post_id", postId).put("user_id", userId).put("reaction_type", "like").toString(), true)
                runOnUiThread { loadFeed() }
            } catch (x: Exception) { runOnUiThread { toast(x.message ?: "Reaction failed.") } }
        }
    }

    private fun commentsDialog(postId: String, author: String) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(4), dp(4), dp(4)) }
        val input = EditText(this).apply { hint = "Write a comment…" }
        box.addView(tv("Comments on $author's post", 15f, green, true)); box.addView(input)
        AlertDialog.Builder(this).setTitle("Comments").setView(box).setNegativeButton("Close", null).setPositiveButton("Comment") { _, _ ->
            val text = input.text.toString().trim(); if (text.isBlank()) return@setPositiveButton
            executor.execute { try { requestText("POST", "/rest/v1/community_comments", JSONObject().put("post_id", postId).put("author_id", userId).put("body", text).toString(), true); runOnUiThread { loadFeed() } } catch (x: Exception) { runOnUiThread { toast(x.message ?: "Comment failed.") } } }
        }.show()
        executor.execute {
            try {
                val arr = JSONArray(requestText("GET", "/rest/v1/community_comments?select=*&post_id=eq.${URLEncoder.encode(postId, "UTF-8")}&order=created_at.asc&limit=100", null, true))
                runOnUiThread {
                    if (arr.length() == 0) box.addView(tv("No comments yet.", 13f, muted).apply { setPadding(0, dp(8), 0, 0) })
                    for (i in 0 until arr.length()) { val c = arr.getJSONObject(i); box.addView(tv("${c.optString("display_name").ifBlank { "MTI Member" }}: ${c.optString("body")}", 13f, ink).apply { setPadding(0, dp(7), 0, dp(0)) }) }
                }
            } catch (_: Exception) { }
        }
    }

    private fun loadChats() {
        body.removeAllViews(); body.addView(button("＋  New private chat") { newDirectChatDialog() }); body.addView(tv("Your private conversations", 18f, ink, true).apply { setPadding(0, dp(10), 0, dp(8)) })
        executor.execute {
            try {
                val arr = JSONArray(requestText("GET", "/rest/v1/community_conversations?select=*&kind=eq.direct&order=updated_at.desc&limit=50", null, true)); runOnUiThread { renderConversations(arr, false) }
            } catch (x: Exception) { runOnUiThread { showError("Chats", x) } }
        }
    }

    private fun loadGroups() {
        body.removeAllViews(); body.addView(button("＋  Create a group") { createGroupDialog() }); body.addView(tv("Your MTI groups", 18f, ink, true).apply { setPadding(0, dp(10), 0, dp(8)) })
        executor.execute {
            try {
                val arr = JSONArray(requestText("GET", "/rest/v1/community_conversations?select=*&kind=eq.group&order=updated_at.desc&limit=50", null, true)); runOnUiThread { renderConversations(arr, true) }
            } catch (x: Exception) { runOnUiThread { showError("Groups", x) } }
        }
    }

    private fun renderConversations(arr: JSONArray, groups: Boolean) {
        if (arr.length() == 0) { body.addView(tv(if (groups) "No groups yet." else "No private chats yet.", 14f, muted).apply { setPadding(0, dp(10), 0, dp(15)) }); return }
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i); val id = c.optString("id"); val box = card(); val title = c.optString("title").ifBlank { if (groups) "MTI Group" else "MTI Direct Chat" }
            box.addView(tv(title, 16f, green, true)); box.addView(tv(c.optString("last_message").ifBlank { "Start the conversation." }, 13f, muted).apply { setPadding(0, dp(6), 0, 0) }); box.isClickable = true; box.setOnClickListener { openChat(id, title, groups) }
            body.addView(box, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) })
        }
    }

    private fun newDirectChatDialog() {
        val input = EditText(this).apply { hint = "MTI account email" }
        AlertDialog.Builder(this).setTitle("New private chat").setMessage("Enter the MTI email address of the person you want to message.").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Start chat") { _, _ ->
            val em = input.text.toString().trim().lowercase(); if (em.isBlank()) return@setPositiveButton
            executor.execute { try { val raw = requestText("POST", "/rest/v1/rpc/mti_community_create_direct", JSONObject().put("p_email", em).toString(), true); val id = JSONArray("[$raw]").optString(0); runOnUiThread { openChat(id, "MTI Direct Chat", false) } } catch (x: Exception) { runOnUiThread { toast(x.message ?: "Could not start chat.") } } }
        }.show()
    }

    private fun createGroupDialog() {
        val input = EditText(this).apply { hint = "Group name" }
        AlertDialog.Builder(this).setTitle("Create MTI group").setMessage("You will be the group creator. Member management can be expanded from the group workspace.").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
            val name = input.text.toString().trim().ifBlank { "MTI Group" }
            executor.execute {
                try {
                    val arr = JSONArray(requestText("POST", "/rest/v1/community_conversations", JSONObject().put("kind", "group").put("created_by", userId).put("title", name).toString(), true)); val id = arr.optJSONObject(0)?.optString("id") ?: throw Exception("Group was not created.")
                    requestText("POST", "/rest/v1/community_conversation_members", JSONObject().put("conversation_id", id).put("user_id", userId).toString(), true)
                    runOnUiThread { openChat(id, name, true) }
                } catch (x: Exception) { runOnUiThread { toast(x.message ?: "Could not create group.") } }
            }
        }.show()
    }

    private fun openChat(conversationId: String, title: String, group: Boolean) {
        val r = rootLayout(); r.addView(header(title, if (group) "MTI group conversation" else "Private MTI conversation"))
        val messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(10), dp(18), dp(10)) }; val input = EditText(this).apply { hint = "Write a message…" }
        r.addView(scroll(messages), LinearLayout.LayoutParams(-1, 0, 1f)); val send = button("Send") { val text = input.text.toString().trim(); if (text.isBlank()) return@button; executor.execute { try { requestText("POST", "/rest/v1/community_messages", JSONObject().put("conversation_id", conversationId).put("sender_id", userId).put("body", text).toString(), true); runOnUiThread { input.setText(""); loadMessages(messages, conversationId) } } catch (x: Exception) { runOnUiThread { toast(x.message ?: "Message failed.") } } } }; r.addView(input); r.addView(send); r.addView(button("Back") { showCommunity() }); setContentView(r); loadMessages(messages, conversationId)
    }

    private fun loadMessages(messages: LinearLayout, id: String) {
        executor.execute { try { val arr = JSONArray(requestText("GET", "/rest/v1/community_messages?select=*&conversation_id=eq.${URLEncoder.encode(id, "UTF-8")}&order=created_at.asc&limit=200", null, true)); runOnUiThread { messages.removeAllViews(); for (i in 0 until arr.length()) { val m = arr.getJSONObject(i); messages.addView(tv(m.optString("body"), 14f, ink).apply { setPadding(dp(12), dp(9), dp(12), dp(9)); background = android.graphics.drawable.GradientDrawable().apply { setColor(white); cornerRadius = dp(14).toFloat() }; layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) } }) } } } catch (x: Exception) { runOnUiThread { messages.removeAllViews(); messages.addView(tv(x.message ?: "Messages could not be loaded.", 13f, muted)) } } }
    }

    private fun sharePost(body: String) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, body) }, "Share MTI post")) }
    private fun signOut() { accessToken = null; userId = null; email = null; showLogin("You have been signed out.") }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun showError(label: String, x: Exception) { body.removeAllViews(); body.addView(tv("$label could not be loaded.", 18f, ink, true)); body.addView(tv(x.message ?: "Unknown error", 13f, muted).apply { setPadding(0, dp(8), 0, dp(15)) }); body.addView(button("Retry") { showCommunity() }) }

    private fun requestJson(method: String, path: String, payload: String?, authenticated: Boolean): JSONObject {
        val body = requestRaw(method, path, payload, authenticated); return JSONObject(body.ifBlank { "{}" })
    }
    private fun requestText(method: String, path: String, payload: String?, authenticated: Boolean): String = requestRaw(method, path, payload, authenticated)
    private fun requestRaw(method: String, path: String, payload: String?, authenticated: Boolean): String {
        val c = URL(supabaseUrl + path).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 12000; c.readTimeout = 18000; c.setRequestProperty("apikey", supabaseKey); c.setRequestProperty("Accept", "application/json"); if (method == "POST" || method == "PATCH") c.setRequestProperty("Prefer", "return=representation")
        if (authenticated) c.setRequestProperty("Authorization", "Bearer ${accessToken ?: throw Exception("MTI session expired. Please sign in again.")}") else c.setRequestProperty("Authorization", "Bearer $supabaseKey")
        if (payload != null) { c.doOutput = true; c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(payload.toByteArray()) } }
        val code = c.responseCode; val input = if (code in 200..299) c.inputStream else c.errorStream; val text = input?.bufferedReader()?.use { it.readText() }.orEmpty(); c.disconnect()
        if (code !in 200..299) throw Exception(parseError(code, text)); return text
    }
    private fun parseError(code: Int, body: String): String {
        return try { val o = JSONObject(body); o.optString("message").ifBlank { o.optString("hint").ifBlank { "HTTP $code" } } } catch (_: Exception) { "HTTP $code" }
    }

    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
}
