# MTI Android V310 — Ask MTI Contract Fix

V310 is a targeted continuation of V309. No Supabase/community architecture is changed.

## Change
The deployed MTI Netlify AI function is shared with the working MTI website AI. V309 sent a `messages` payload, while the existing function contract accepts `message` plus `history`. V310 restores the compatible request shape:

- `message`: current user question
- `history`: prior conversation turns

The Android app still calls the production function at `https://nimble-faun-2c7fb5.netlify.app/.netlify/functions/mti-assistant`.

## Security
No OpenAI API key is included in the Android project. The key remains server-side in Netlify.

## Version
- versionCode: 310
- versionName: 9.6.0
- GitHub Actions artifact: `MTI-Umuahia-debug-apk-v310`
