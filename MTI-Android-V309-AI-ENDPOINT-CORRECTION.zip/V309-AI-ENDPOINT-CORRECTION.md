# MTI Android V309 — AI Endpoint Correction

V309 is a targeted continuation of V308. It does not rebuild the app or change the Supabase/community architecture.

## Exact production AI endpoint
`https://nimble-faun-2c7fb5.netlify.app/.netlify/functions/mti-assistant`

## Change
- Updated the native Android Ask MTI client from the previously configured Netlify hostname to the exact production hostname supplied from the deployed Netlify Functions project.
- No OpenAI API key is stored in Android.
- Native Android still calls the Netlify Function directly; it does not open a browser or redirect to the website.
- Version code: 309
- Version name: 9.5.0
- GitHub Actions artifact: `MTI-Umuahia-debug-apk-v309`

## Baseline
V308 remains the functional baseline. All other V308 work is preserved.
