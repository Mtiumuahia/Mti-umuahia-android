package ng.org.mtiumuahia.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class AIAssistantActivity:Activity(){
 private val cream=Color.rgb(247,244,237);private val green=Color.rgb(11,61,46);private val deep=Color.rgb(5,37,28);private val gold=Color.rgb(190,157,82);private val ink=Color.rgb(25,45,39);private val muted=Color.rgb(91,105,99);private val white=Color.WHITE
 private lateinit var messages:LinearLayout;private lateinit var input:EditText;private lateinit var scroll:ScrollView;private lateinit var send:TextView
 private val exec=Executors.newSingleThreadExecutor();private val history=JSONArray()
 private val base="https://nimble-faun-2c7fb5.netlify.app"
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun bg(c:Int,r:Int=18)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()}
 private fun tv(s:String,n:Float,c:Int=ink,b:Boolean=false)=TextView(this).apply{text=s;textSize=n;setTextColor(c);typeface=if(b)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;setLineSpacing(0f,1.16f)}
 override fun onCreate(b:Bundle?){super.onCreate(b);buildUi()}
 private fun buildUi(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream)}
  val head=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(18));background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(deep,green)) .apply{cornerRadius=dp(0).toFloat()}}
  head.addView(tv("MTI · UMUAHIA",11f,gold,true));head.addView(tv("Ask MTI",28f,white,true).apply{setPadding(0,dp(5),0,dp(5))});head.addView(tv("Your digital guide to admissions, programmes, Institute life and public MTI information.",13.5f,Color.rgb(224,236,229)))
  root.addView(head)
  val quick=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(14),dp(12),dp(14),dp(5))}
  listOf("Admissions","Programmes","MTI life").forEach{label->val q=TextView(this@AIAssistantActivity).apply{text=label;textSize=11f;gravity=Gravity.CENTER;setTextColor(green);background=GradientDrawable().apply{setColor(Color.rgb(239,235,224));cornerRadius=dp(15).toFloat();setStroke(dp(1),Color.rgb(224,214,190))};setPadding(dp(12),dp(8),dp(12),dp(8));setOnClickListener{input.setText("Tell me about $label at MTI.");input.setSelection(input.length());ask()}};quick.addView(q,LinearLayout.LayoutParams(0,dp(38),1f).apply{if(label!="MTI life")marginEnd=dp(6)})}
  root.addView(quick)
  messages=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(18))}
  scroll=ScrollView(this).apply{isFillViewport=true;addView(messages)};root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(9),dp(12),dp(10));setBackgroundColor(white)}
  input=EditText(this).apply{hint="Ask a question…";textSize=15f;setTextColor(ink);setHintTextColor(muted);background=bg(cream,18);setPadding(dp(15),0,dp(15),0);maxLines=3;imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEND;setOnEditorActionListener{_,_,_->ask();true}}
  send=TextView(this).apply{text="Ask";gravity=Gravity.CENTER;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;background=bg(green,18);setPadding(dp(20),0,dp(20),0);setOnClickListener{ask()}}
  bar.addView(input,LinearLayout.LayoutParams(0,dp(54),1f));bar.addView(send,LinearLayout.LayoutParams(dp(78),dp(54)).apply{marginStart=dp(8)});root.addView(bar);setContentView(root)
  addMessage("assistant","Hello. I’m MTI’s assistant. Ask me about admissions, programmes, MTI life or public institutional information.")
 }
 private fun addMessage(who:String,text:String){messages.addView(tv(text,14.5f,if(who=="user")white else ink).apply{background=bg(if(who=="user")green else white,18);setPadding(dp(15),dp(13),dp(15),dp(13));elevation=dp(1).toFloat();layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5));if(who=="user")marginStart=dp(38) else marginEnd=dp(18)}});scroll.post{scroll.fullScroll(ScrollView.FOCUS_DOWN)}}
 private fun ask(){val q=input.text.toString().trim();if(q.isBlank()||send.isEnabled.not())return;if(q.length>600){input.error="Please keep your question under 600 characters.";return};input.setText("");addMessage("user",q);send.isEnabled=false;send.text="…"
  val wait=tv("MTI is thinking…",13f,muted).apply{setPadding(dp(15),dp(10),dp(15),dp(10));tag="ai_wait"};messages.addView(wait);scroll.post{scroll.fullScroll(ScrollView.FOCUS_DOWN)}
  exec.execute{try{
   val body=JSONObject().apply{put("messages", JSONArray(history.toString()))}
   val c=URL("$base/.netlify/functions/mti-assistant").openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Accept","application/json");c.connectTimeout=15000;c.readTimeout=30000;c.outputStream.use{it.write(body.toString().toByteArray())}
   val code=c.responseCode;val stream=if(code in 200..299)c.inputStream else c.errorStream;val raw=stream?.bufferedReader()?.use{it.readText()}.orEmpty();c.disconnect();if(code !in 200..299)throw Exception("MTI AI service returned HTTP $code${parseServerMessage(raw)}")
   val o=JSONObject(raw);val answer=o.optString("answer",o.optString("output",o.optString("text","I could not get an answer right now.")));history.put(JSONObject().put("role","user").put("content",q));history.put(JSONObject().put("role","assistant").put("content",answer));runOnUiThread{removeWait();addMessage("assistant",answer);send.isEnabled=true;send.text="Ask"}
  }catch(e:Exception){runOnUiThread{removeWait();addMessage("assistant",friendlyError(e));send.isEnabled=true;send.text="Ask"}}}
 }
 private fun parseServerMessage(raw:String):String{if(raw.isBlank())return "";return try{val o=JSONObject(raw);val m=o.optString("error").ifBlank{o.optString("message").ifBlank{o.optString("detail")}};if(m.isBlank())"" else ": ${m.take(180)}"}catch(_:Exception){""}}
 private fun friendlyError(e:Exception):String{val m=e.message.orEmpty();return when{m.contains("UnknownHostException",true)||m.contains("Unable to resolve host",true)->"The MTI AI service address could not be reached. The app is online, but its server-side AI service needs to be checked.";m.contains("HTTP 404")->"The MTI AI endpoint is not available at the configured Netlify address. The server-side function needs to be deployed or its address updated.";m.contains("HTTP 401")||m.contains("HTTP 403")->"The MTI AI server is reachable, but its server-side authentication/configuration is not valid. The OpenAI key must remain on the Netlify server, not inside the app.";else->"I could not reach the MTI AI service right now. Please try again shortly.\n\nTechnical status: ${m.take(180)}"}}
 private fun removeWait(){val v=messages.findViewWithTag<TextView>("ai_wait");if(v!=null)messages.removeView(v)}
 override fun onDestroy(){exec.shutdownNow();super.onDestroy()}
}
