package ng.org.mtiumuahia.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*

class MainActivity : Activity() {
    private val cream = Color.rgb(247, 244, 237)
    private val green = Color.rgb(11, 61, 46)
    private val deep = Color.rgb(5, 37, 28)
    private val gold = Color.rgb(190, 157, 82)
    private val ink = Color.rgb(25, 45, 39)
    private val muted = Color.rgb(91, 105, 99)
    private val white = Color.WHITE
    private lateinit var content: FrameLayout

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)
        content = findViewById(R.id.content)
        findViewById<TextView>(R.id.navHome).setOnClickListener { home() }
        findViewById<TextView>(R.id.navCommunity).setOnClickListener { community() }
        findViewById<TextView>(R.id.navAcademics).setOnClickListener { academics() }
        findViewById<TextView>(R.id.navExplore).setOnClickListener { explore() }
        findViewById<TextView>(R.id.navProfile).setOnClickListener { profile() }
        findViewById<TextView>(R.id.aiFab).setOnClickListener { startActivity(Intent(this, AIAssistantActivity::class.java)) }
        home()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun tv(s: String, size: Float, color: Int = ink, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setLineSpacing(0f, 1.16f)
    }
    private fun pill(s: String) = tv(s.uppercase(), 10f, gold, true).apply { letterSpacing = .16f }
    private fun scroll(v: View) = ScrollView(this).apply { isFillViewport = true; addView(v) }
    private fun bg(color: Int, r: Float = 18f) = GradientDrawable().apply { setColor(color); cornerRadius = dp(r.toInt()).toFloat() }
    private fun primary(s: String, click: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; gravity = Gravity.CENTER; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        background = bg(green, 16f); setPadding(dp(18), dp(14), dp(18), dp(14)); isClickable = true
        setOnClickListener { press(this); click() }
    }
    private fun ghost(s: String, click: () -> Unit) = TextView(this).apply {
        text = s; textSize = 14f; gravity = Gravity.CENTER; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(1), Color.rgb(190,210,201)); cornerRadius = dp(16).toFloat() }
        setPadding(dp(18), dp(14), dp(18), dp(14)); isClickable = true
        setOnClickListener { press(this); click() }
    }
    private fun card(title: String, desc: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18)); background = bg(white, 20f)
        elevation = dp(3).toFloat(); isClickable = true; isFocusable = true
        setOnClickListener { press(this); click() }
        addView(tv(title, 18f, green, true))
        addView(tv(desc, 13f, muted).apply { setPadding(0, dp(7), 0, 0) })
        addView(tv("→", 21f, gold, true).apply { gravity = Gravity.END; setPadding(0, dp(8), 0, 0) })
    }
    private fun featureCard(title: String, desc: String, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(16)); background = bg(white, 22f)
        elevation = dp(4).toFloat(); isClickable = true; isFocusable = true
        addView(tv(title, 20f, green, true)); addView(tv(desc, 14f, muted).apply { setPadding(0, dp(8), 0, 0) })
        addView(tv("Open  →", 13f, gold, true).apply { setPadding(0, dp(18), 0, 0) })
        setOnClickListener { press(this); click() }
    }
    private fun row(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginEnd = dp(7) })
        addView(b, LinearLayout.LayoutParams(0, dp(128), 1f).apply { marginStart = dp(7) })
    }
    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(cream); setPadding(dp(18), dp(14), dp(18), dp(30))
    }
    private fun press(v: View) {
        if (android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) return
        v.animate().scaleX(.975f).scaleY(.975f).setDuration(70).withEndAction { v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }.start()
    }
    private fun animateIn(container: ViewGroup) {
        if (android.provider.Settings.Global.getFloat(contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f) return
        for (i in 0 until container.childCount) {
            val child = container.getChildAt(i); child.alpha = 0f; child.translationY = dp(12).toFloat()
            child.animate().alpha(1f).translationY(0f).setStartDelay((i * 45L).coerceAtMost(450L)).setDuration(330).setInterpolator(DecelerateInterpolator()).start()
        }
    }
    private fun header(label: String, title: String, subtitle: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; addView(pill(label)); addView(tv(title, 30f, ink, true).apply { setPadding(0, dp(5), 0, dp(6)) }); addView(tv(subtitle, 14f, muted).apply { setPadding(0, 0, 0, dp(18)) })
    }

    private fun home() {
        content.removeAllViews(); val p = page()
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        top.addView(ImageView(this).apply { setImageResource(R.drawable.mti_logo); contentDescription = "MTI Umuahia"; scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(54), dp(54)))
        top.addView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(tv("MTI · UMUAHIA", 12f, gold, true)); addView(tv("Methodist Theological Institute", 14f, green, true)) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        p.addView(top)
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(deep, green)).apply { cornerRadius = dp(26).toFloat() }
            addView(pill("Faith · Formation · Scholarship"))
            addView(tv("Rooted in faith.\nGrowing in truth.", 31f, white, true).apply { setPadding(0, dp(12), 0, dp(6)) })
            addView(tv("A theological community preparing people for faithful Christian ministry and service.", 14f, Color.rgb(229,238,232)))
            addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.HORIZONTAL; addView(primary("Explore MTI") { explore() }, LinearLayout.LayoutParams(0, dp(50), 1f)); addView(ghost("Admissions") { openContent("admissions") }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(8) }) }.apply { setPadding(0, dp(18), 0, 0) })
        }
        p.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(18), 0, 0) })
        p.addView(tv("Featured at MTI", 21f, ink, true).apply { setPadding(2, dp(25), 2, dp(10)) })
        p.addView(featureCard("What's happening at MTI", "News, events and moments from the Institute.") { openContent("news") }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(4), 0, dp(8)) })
        p.addView(row(featureCard("Campus Life", "Worship, learning and community.") { community() }, featureCard("MTI Community", "Connect with the MTI family.") { community() }), LinearLayout.LayoutParams(-1, dp(128)))
        p.addView(tv("Your MTI", 21f, ink, true).apply { setPadding(2, dp(26), 2, dp(10)) })
        p.addView(row(card("Student Portal", "Courses, results and services.") { startActivity(Intent(this, StudentPortalActivity::class.java)) }, card("Lecturer Portal", "Teaching, results and materials.") { startActivity(Intent(this, LecturerPortalActivity::class.java)) }))
        p.addView(tv("Explore MTI", 21f, ink, true).apply { setPadding(2, dp(26), 2, dp(10)) })
        p.addView(row(card("Programmes", "Study pathways at MTI.") { openContent("programmes") }, card("Leadership", "Meet MTI's leadership.") { openContent("leadership") }))
        content.addView(scroll(p)); animateIn(p)
    }

    private fun community() {
        content.removeAllViews(); val p = page(); p.addView(header("MTI COMMUNITY", "A community that connects.", "Share, discover and communicate with the MTI family."))
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Feed", "Chats", "Groups").forEachIndexed { i, s ->
            val b = TextView(this@MainActivity).apply { text = s; gravity = Gravity.CENTER; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (i == 0) white else green); background = bg(if (i == 0) green else Color.TRANSPARENT, 15f); setPadding(dp(15), dp(11), dp(15), dp(11)) }
            tabs.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(4) })
        }
        p.addView(tabs, LinearLayout.LayoutParams(-1, dp(46)).apply { setMargins(0, 0, 0, dp(14)) })
        p.addView(statusRow())
        p.addView(post("John E.", "Today · MDiv Year 1", "Today's lecture has been moved to 2:00 PM.", "14 likes · 6 comments"))
        p.addView(post("MTI Chapel", "Yesterday", "Thank God for a successful chapel service. 🙏", "31 likes · 8 comments"))
        p.addView(post("Mary C.", "2 days ago", "Grateful for a successful presentation today.", "22 likes · 4 comments"))
        p.addView(tv("Community services", 19f, ink, true).apply { setPadding(2, dp(22), 2, dp(9)) })
        p.addView(row(card("Private Chats", "One-to-one conversations.") { toast("Chat backend will be connected after the community database audit.") }, card("Groups", "Classes, chapel and SUG groups.") { toast("Group backend will be connected after the community database audit.") }))
        content.addView(scroll(p)); animateIn(p)
    }
    private fun statusRow() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; setPadding(0, 0, 0, dp(12))
        val people = listOf("Your\nStatus", "John", "Grace", "Samuel", "Chapel")
        people.forEachIndexed { i, name ->
            val box = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(2), dp(4), dp(2)) }
            val circle = TextView(this@MainActivity).apply { text = if (i == 0) "+" else name.take(1); gravity = Gravity.CENTER; textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (i == 0) green else white); background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (i == 0) Color.rgb(225,232,226) else green); setStroke(dp(2), gold) } }
            box.addView(circle, LinearLayout.LayoutParams(dp(54), dp(54))); box.addView(tv(name, 11f, muted, i == 0).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0) }); addView(box, LinearLayout.LayoutParams(0, dp(88), 1f))
        }
    }
    private fun post(name: String, time: String, body: String, meta: String) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(16), dp(17), dp(16)); background = bg(white, 20f); elevation = dp(2).toFloat()
        addView(tv(name, 16f, green, true)); addView(tv(time, 11f, muted).apply { setPadding(0, dp(3), 0, dp(10)) }); addView(tv(body, 15f, ink)); addView(tv("♡   💬   ↗    $meta", 12f, muted).apply { setPadding(0, dp(13), 0, 0) })
        setOnClickListener { press(this); toast("Community post opened. Backend connection is the next implementation phase.") }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(5), 0, dp(5)) }
    }

    private fun academics() {
        content.removeAllViews(); val p = page(); p.addView(header("ACADEMICS", "Your academic life.", "Access the native MTI academic workspaces."))
        p.addView(featureCard("Student Portal", "Registration, results, fees, materials, schedule and services.") { startActivity(Intent(this, StudentPortalActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(4), 0, dp(8)) })
        p.addView(featureCard("Lecturer Portal", "Courses, gradebook, attendance, materials and virtual classes.") { startActivity(Intent(this, LecturerPortalActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(150)).apply { setMargins(0, dp(4), 0, dp(8)) })
        p.addView(card("Online Classroom", "Continue to the existing native classroom workspace.") { startActivity(Intent(this, StudentPortalActivity::class.java)) })
        content.addView(scroll(p)); animateIn(p)
    }

    private fun explore() {
        content.removeAllViews(); val p = page(); p.addView(header("DISCOVER MTI", "Explore the Institute.", "Institutional information presented inside the app."))
        val items = listOf("About MTI" to "about", "Leadership" to "leadership", "Governance" to "governance", "Programmes" to "programmes", "Admissions" to "admissions", "News" to "news", "Events" to "events", "Gallery" to "gallery", "SUG" to "sug")
        items.chunked(2).forEach { pair -> val a = card(pair[0].first, "Open ${pair[0].first.lowercase()}.") { openContent(pair[0].second) }; if (pair.size == 2) p.addView(row(a, card(pair[1].first, "Open ${pair[1].first.lowercase()}.") { openContent(pair[1].second) })) else p.addView(a) }
        p.addView(tv("Visit & contact", 21f, ink, true).apply { setPadding(2, dp(24), 2, dp(10)) }); p.addView(primary("MTI · Mission Hill, Umuahia") { openContent("contact") })
        content.addView(scroll(p)); animateIn(p)
    }

    private fun profile() {
        content.removeAllViews(); val p = page(); p.addView(header("MY MTI", "Profile & settings.", "Your account area will grow with the Digital Campus."))
        p.addView(card("Student Portal", "Open your authenticated MTI services.") { startActivity(Intent(this, StudentPortalActivity::class.java)) })
        p.addView(card("Notifications", "Institutional and account notifications.") { toast("Notifications centre is planned for the Digital Campus backend phase.") })
        p.addView(card("Privacy & security", "Account controls remain governed by MTI Supabase Auth and RLS.") { toast("Your existing authentication and RLS architecture remains authoritative.") })
        content.addView(scroll(p)); animateIn(p)
    }

    private fun openContent(type: String) { startActivity(Intent(this, PublicContentActivity::class.java).putExtra("type", type)) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
