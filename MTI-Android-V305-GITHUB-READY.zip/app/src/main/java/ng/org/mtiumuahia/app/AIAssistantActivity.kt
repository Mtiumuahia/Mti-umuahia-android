package ng.org.mtiumuahia.app

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class AIAssistantActivity:Activity(){
 private val cream=Color.rgb(247,244,237);private val green=Color.rgb(11,61,46);private val gold=Color.rgb(190,157,82);private val ink=Color.rgb(25,45,39);private val muted=Color.rgb(91,105,99);private val white=Color.WHITE
 private lateinit var messages:LinearLayout;private lateinit var input:EditText;private val exec=Executors.newSingleThreadExecutor();private val history=JSONArray();private val base="https://startling-klepon-ce7270.netlify.app"
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt();private fun bg(c:Int,r:Int=18)=GradientDrawable().apply{setColor(c);cornerRadius=dp(r).toFloat()};private fun tv(s:String,n:Float,c:Int,b:Boolean=false)=TextView(this).apply{text=s;textSize=n;setTextColor(c);typeface=if(b)Typeface.DEFAULT_BOLD else Typeface.DEFAULT;setPadding(dp(15),dp(12),dp(15),dp(12))}
 override fun onCreate(b:Bundle?){super.onCreate(b);val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream)};val head=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(18),dp(20),dp(12));background=bg(green,0)};head.addView(tv("MTI · UMUAHIA",11f,gold,true));head.addView(tv("Ask MTI",27f,white,true));head.addView(tv("Ask about admissions, programmes, life at MTI and public institutional information.",13f,Color.rgb(222,235,228)));root.addView(head);messages=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding(18)};root.addView(ScrollView(this).apply{isFillViewport=true;addView(messages)},LinearLayout.LayoutParams(-1,0,1f));val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(10),dp(12),dp(10));setBackgroundColor(white)};input=EditText(this).apply{hint="Ask a question…";textSize=15f;setTextColor(ink);setHintTextColor(muted);background=bg(cream,18);setPadding(dp(15),0,dp(15),0);maxLines=3};val send=TextView(this).apply{text="Ask";gravity=Gravity.CENTER;setTextColor(white);typeface=Typeface.DEFAULT_BOLD;background=bg(green,18);setPadding(dp(20),0,dp(20),0);setOnClickListener{ask()}};bar.addView(input,LinearLayout.LayoutParams(0,dp(54),1f));bar.addView(send,LinearLayout.LayoutParams(dp(78),dp(54)).apply{marginStart=dp(8)});root.addView(bar);setContentView(root);addMessage("assistant","Hello. I’m MTI’s assistant. How can I help you?")}
 private fun LinearLayout.padding(v:Int){setPadding(dp(v),dp(v),dp(v),dp(v))}
 private fun addMessage(who:String,text:String){messages.addView(tv(text,14.5f,if(who=="user")white else ink).apply{background=bg(if(who=="user")green else white,18);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(5),0,dp(5));if(who=="user")marginStart=dp(38) else marginEnd=dp(18)}})}
 private fun ask(){val q=input.text.toString().trim();if(q.isBlank())return;if(q.length>600){input.error="Please keep your question under 600 characters.";return};input.setText("");addMessage("user",q);exec.execute{try{val body=JSONObject().apply{put("message",q);put("history",history)};val c=URL("$base/.netlify/functions/mti-assistant").openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("Content-Type","application/json");c.connectTimeout=15000;c.readTimeout=25000;c.outputStream.use{it.write(body.toString().toByteArray())};val raw=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().readText();if(c.responseCode !in 200..299)throw Exception("Request failed");val o=JSONObject(raw);val answer=o.optString("answer",o.optString("output",o.optString("text","I could not get an answer right now.")));history.put(JSONObject().put("role","user").put("content",q));history.put(JSONObject().put("role","assistant").put("content",answer));runOnUiThread{addMessage("assistant",answer)}}catch(e:Exception){runOnUiThread{addMessage("assistant","I’m having trouble connecting right now. Please try again in a moment.")}}}}
 override fun onDestroy(){exec.shutdownNow();super.onDestroy()}
}
