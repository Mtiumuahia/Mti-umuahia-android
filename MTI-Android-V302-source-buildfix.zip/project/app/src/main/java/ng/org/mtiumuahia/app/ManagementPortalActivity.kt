package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.res.ColorStateList
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors

class ManagementPortalActivity : Activity() {
    private val executor = Executors.newFixedThreadPool(2)
    private val green = Color.rgb(11,61,46)
    private val darkGreen = Color.rgb(6,40,30)
    private val cream = Color.rgb(246,241,230)
    private val gold = Color.rgb(184,149,74)
    private val ink = Color.rgb(23,53,44)
    private val white = Color.WHITE
    private val supabaseUrl = "https://vjpwllvssblgpwckbiff.supabase.co"
    private val supabaseKey = "sb_publishable_oWY2vA2WyoQ4SnLYJHKVbhQ_2V-_TZal"
    private var accessToken: String? = null
    private var userId: String? = null
    private var email: String? = null

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE); showLogin() }
    override fun onDestroy(){
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(12),dp(16),dp(18))}
    private fun scroll(r:View)=ScrollView(this).apply{isFillViewport=true;addView(r)}
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun title(s:String)=text(s,28f,ink,true).apply{setPadding(dp(4),dp(10),dp(4),dp(4))}
    private fun label(s:String)=text(s.uppercase(),12f,gold,true).apply{letterSpacing=.12f;setPadding(dp(4),dp(16),dp(4),dp(5))}
    private fun button(s:String,click:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{click()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(5),0,dp(5))}}
    private fun card(head:String,body:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(white);elevation=dp(2).toFloat();setPadding(dp(14),dp(12),dp(14),dp(12));addView(text(head,16f,green,true));addView(text(body,13f,ink))}.also{it.layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,dp(6),0,dp(6))}}
    private fun set(r:View){setContentView(scroll(r))}
    private fun headers()=mapOf("apikey" to supabaseKey,"Authorization" to "Bearer ${accessToken ?: ""}","Content-Type" to "application/json")
    private fun get(path:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="GET";headers().forEach{(k,v)->c.setRequestProperty(k,v)};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return body}
    private fun post(path:String,payload:String):String{val c=URL(supabaseUrl+path).openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;headers().forEach{(k,v)->c.setRequestProperty(k,v)};c.outputStream.use{it.write(payload.toByteArray())};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return body}
    private fun postAuth(e:String,p:String):JSONObject{val c=URL("$supabaseUrl/auth/v1/token?grant_type=password").openConnection() as HttpURLConnection;c.requestMethod="POST";c.doOutput=true;c.setRequestProperty("apikey",supabaseKey);c.setRequestProperty("Content-Type","application/json");c.outputStream.use{it.write(JSONObject().put("email",e).put("password",p).toString().toByteArray())};val code=c.responseCode;val input=if(code in 200..299)c.inputStream else c.errorStream;val body=input.bufferedReader().use{it.readText()};c.disconnect();if(code !in 200..299)throw Exception(parseError(body));return JSONObject(body)}
    private fun parseError(body:String)=try{val j=JSONObject(body);j.optString("error_description").ifBlank{j.optString("msg").ifBlank{j.optString("message").ifBlank{"Request failed"}}}}catch(_:Exception){"Request failed"}

    private fun revokeSession(token:String){try{val c=URL("$supabaseUrl/auth/v1/logout").openConnection() as HttpURLConnection;c.requestMethod="POST";c.connectTimeout=10000;c.readTimeout=10000;c.setRequestProperty("apikey",supabaseKey);c.setRequestProperty("Authorization","Bearer $token");c.connect();c.inputStream?.close();c.disconnect()}catch(_:Exception){}}
    private fun showLogin(message:String=""){
        accessToken=null;userId=null;email=null
        val r=root();r.setBackgroundColor(green)
        r.addView(text("METHODIST THEOLOGICAL INSTITUTE · UMUAHIA",12f,gold,true))
        r.addView(title("Management Portal").apply{setTextColor(white)})
        r.addView(text("Secure institutional administration workspace. Access is limited to MTI accounts authorised with the existing management portal role.",15f,white))
        val emailInput=EditText(this).apply{hint="Management email";inputType=33;setTextColor(white);setHintTextColor(Color.LTGRAY)}
        val passInput=EditText(this).apply{hint="Password";inputType=129;setTextColor(white);setHintTextColor(Color.LTGRAY)}
        r.addView(emailInput,LinearLayout.LayoutParams(-1,dp(56)).apply{setMargins(0,dp(10),0,dp(4))})
        r.addView(passInput,LinearLayout.LayoutParams(-1,dp(56)).apply{setMargins(0,dp(4),0,dp(10))})
        val status=text(message,14f,white);r.addView(status)
        r.addView(button("Sign In"){
            val e=emailInput.text.toString().trim();val p=passInput.text.toString()
            if(e.isBlank()||p.isBlank()){status.text="Enter your management email and password.";return@button}
            status.text="Signing in and checking management authorisation…"
            executor.execute{try{
                val d=postAuth(e,p);accessToken=d.optString("access_token").ifBlank{throw Exception("No access token was returned.")};userId=d.optJSONObject("user")?.optString("id") ?: d.optString("user_id");email=e
                val ok=post("/rest/v1/rpc/is_portal_role",JSONObject().put("required_role","management").toString()).trim().lowercase().let{it=="true" || it=="1"}
                if(!ok){ accessToken=null; userId=null; email=null; revokeSession(d.optString("access_token")); throw Exception("This account is not authorised for the MTI Management Portal.") }
                runOnUiThread{showDashboard()}
            }catch(x:Exception){runOnUiThread{status.text=x.message?:"Management sign in failed."}}}
        })
        r.addView(button("Open Existing Management Website"){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url)+"/management-dashboard")))})
        r.addView(text("The Android app does not create management accounts or change roles. Existing Supabase Auth and the MTI management role check remain authoritative.",13f,white))
        set(r)
    }

    private fun showDashboard(){
        val r=root();r.addView(label("MANAGEMENT COMMAND CENTRE"));r.addView(title("Institutional Overview"));r.addView(button("Executive Quick Actions"){openExecutiveHome()});r.addView(button("Global Workspace Launcher"){openWorkspaceLauncher()});r.addView(text("Signed in as ${email ?: "authorised MTI management user"}. Use the grouped workspaces below for faster administration; the full management website remains available for detailed operations."))
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};r.addView(box);box.addView(text("Loading institutional statistics…"))
        r.addView(label("ADMISSIONS & STUDENT LIFE"));r.addView(button("Admissions Administration · Applicants · Activation"){openAdmissionsNative()});r.addView(button("Student Registry & Lifecycle"){openStudentLifecycleNative()});r.addView(button("SUG & Student Leadership"){openSugNative()});r.addView(button("Hostel & Student Services"){openHostelNative()})
        r.addView(label("ACADEMIC ADMINISTRATION"));r.addView(button("Academic Courses & Teaching Load"){openAcademicNative()});r.addView(button("Academic Records & Results Review"){openAcademicRecordsNative()});r.addView(button("Examination Number Registry"){openExamRegistryNative()});r.addView(button("Calendar & Attendance Monitoring"){openCalendarNative()})
        r.addView(label("TEACHING & DIGITAL LEARNING"));r.addView(button("Online Classroom & Virtual Learning"){openOnlineClassroomNative()});r.addView(button("Learning Materials & Digital Library"){openLearningMaterialsNative()});r.addView(button("Communications & Notices"){openCommunicationsNative()})
        r.addView(label("FINANCE & INSTITUTIONAL RECORDS"));r.addView(button("Finance & Payment Administration"){openFinanceNative()});r.addView(button("Document & Records Administration"){openRecordsNative()});r.addView(button("Institutional Reporting"){openReportingNative()})
        r.addView(label("NOTIFICATIONS & OPERATIONS"));r.addView(button("Notifications & Operational Alerts"){openNotificationsNative()});r.addView(label("SECURITY & CONTROL"));r.addView(button("Audit, Security & Activity Monitoring"){openSecurityNative()});r.addView(button("Admission & SUG Controls"){openControlsNative()})
        r.addView(label("NAVIGATION & SEARCH"));r.addView(button("Search Management Workspaces"){openSearchNative()})
        r.addView(label("AUTHORITATIVE WEB WORKSPACES"));r.addView(button("Full Management Command Centre"){openWeb("/management-dashboard")});r.addView(button("Student Registry (Web)"){openWeb("/student-registry")})
        r.addView(label("ACCOUNT & SESSION"));r.addView(button("Secure Account & Session Controls"){openAccountControlsNative()});r.addView(button("App Settings & Accessibility"){openSettingsNative()};r.addView(button("About, System Information & Architecture"){openSystemInfoNative()}));r.addView(label("SECURITY"));r.addView(text("Management authorisation is checked server-side through the existing is_portal_role RPC. No service-role key or new permission model is used."));r.addView(button("Sign Out"){ val token=accessToken; accessToken=null; userId=null; email=null; if(!token.isNullOrBlank()) executor.execute { revokeSession(token) }; showLogin("You have been signed out. Please sign in again.") })
        set(r);loadStats(box)
    }

    private fun loadStats(box:LinearLayout){executor.execute{try{
        val applications=JSONArray(get("/rest/v1/applications?select=id&limit=5000"));val students=JSONArray(get("/rest/v1/student_profiles?select=id&limit=5000"));val payments=JSONArray(get("/rest/v1/student_payments?select=id&limit=5000"));val lecturers=JSONArray(get("/rest/v1/lecturer_profiles?select=id&limit=1000"));val courses=JSONArray(get("/rest/v1/academic_courses?select=id&active=eq.true&limit=2000"));val activeApplications=JSONArray(get("/rest/v1/applications?select=id&status=eq.submitted&limit=5000"))
        runOnUiThread{box.removeAllViews();box.addView(card("Students","${students.length()} student profile record${if(students.length()==1)"" else "s"}"));box.addView(card("Lecturers","${lecturers.length()} lecturer profile record${if(lecturers.length()==1)"" else "s"}"));box.addView(card("Active Courses","${courses.length()} active academic course${if(courses.length()==1)"" else "s"}"));box.addView(card("Applications","${applications.length()} application record${if(applications.length()==1)"" else "s"} · ${activeApplications.length()} submitted"));box.addView(card("Payments","${payments.length()} payment record${if(payments.length()==1)"" else "s"}"))}
    }catch(x:Exception){runOnUiThread{box.removeAllViews();box.addView(card("Statistics unavailable","Some management statistics could not be loaded from the existing authorised data sources. Open the full Management Command Centre for complete records.\n\n${"Request failed. Please use the authoritative MTI workspace if the problem persists."}"))}}}}

    private fun openHelpNative(){startActivity(Intent(this,ManagementHelpActivity::class.java))}
    private fun openSettingsNative(){startActivity(Intent(this,ManagementSettingsActivity::class.java))}
    private fun openSystemInfoNative(){startActivity(Intent(this,ManagementSystemInfoActivity::class.java))}
    private fun openAccountControlsNative(){startActivity(Intent(this,ManagementAccountControlsActivity::class.java).apply{putExtra("access_token",accessToken);putExtra("email",email);putExtra("user_id",userId)})}

    private fun openAcademicNative(){startActivity(Intent(this,ManagementAcademicActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openTeachingLoadNative(){startActivity(Intent(this,ManagementTeachingLoadActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openControlsNative(){startActivity(Intent(this,ManagementControlsActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openSugNative(){startActivity(Intent(this,ManagementSugActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openExamRegistryNative(){startActivity(Intent(this,ManagementExamRegistryActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openFinanceNative(){startActivity(Intent(this,ManagementFinanceActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openHostelNative(){startActivity(Intent(this,ManagementHostelActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openStudentServicesNative(){startActivity(Intent(this,ManagementStudentServicesActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openReportingNative(){startActivity(Intent(this,ManagementReportingActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openSecurityNative(){startActivity(Intent(this,ManagementSecurityActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openRecordsNative(){startActivity(Intent(this,ManagementRecordsActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openStudentLifecycleNative(){startActivity(Intent(this,ManagementStudentLifecycleActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openAcademicRecordsNative(){
        startActivity(Intent(this, ManagementAcademicRecordsActivity::class.java).putExtra("access_token",accessToken))
    }
    private fun openResultReviewNative(){startActivity(Intent(this,ManagementResultReviewActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openAdmissionsNative(){startActivity(Intent(this,ManagementAdmissionsActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openApplicantSelectionNative(){startActivity(Intent(this,ManagementApplicantSelectionActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openAdmissionActivationNative(){startActivity(Intent(this,ManagementAdmissionActivationActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openSearchNative(){startActivity(Intent(this,ManagementSearchActivity::class.java).apply{putExtra("access_token",accessToken)})}

    private fun openWeb(path:String){startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+path)))}
    private fun openCalendarNative(){
        startActivity(Intent(this,ManagementCalendarActivity::class.java).apply{putExtra("access_token",accessToken)})
    }

    private fun openOnlineClassroomNative(){
        startActivity(Intent(this,ManagementOnlineClassroomActivity::class.java).apply{putExtra("access_token",accessToken)})
    }

    private fun openLearningMaterialsNative(){
        startActivity(Intent(this,ManagementLearningMaterialsActivity::class.java).apply{putExtra("access_token",accessToken)})
    }

    private fun openAttendanceMonitoringNative(){
        startActivity(Intent(this,ManagementAttendanceMonitoringActivity::class.java).apply{putExtra("access_token",accessToken)})
    }

    private fun openNotificationsNative(){startActivity(Intent(this,ManagementNotificationsActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openExecutiveHome(){startActivity(Intent(this,ManagementExecutiveHomeActivity::class.java).apply{putExtra("access_token",accessToken)})}
    private fun openWorkspaceLauncher(){startActivity(Intent(this,ManagementWorkspaceLauncherActivity::class.java).apply{putExtra("access_token",accessToken)})}

    private fun openCommunicationsNative(){
        startActivity(Intent(this,ManagementCommunicationsActivity::class.java).apply{putExtra("access_token",accessToken)})
    }

}
