package ng.org.mtiumuahia.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.*
import android.content.res.ColorStateList

class ManagementWorkspaceLauncherActivity : Activity() {
    private val green=Color.rgb(11,61,46); private val cream=Color.rgb(246,241,230); private val gold=Color.rgb(184,149,74); private val ink=Color.rgb(23,53,44); private val white=Color.WHITE
    private var token:String?=null
    private lateinit var list:LinearLayout
    private lateinit var search:EditText
    private val prefs by lazy { getSharedPreferences("management_workspace_launcher",MODE_PRIVATE) }
    data class Item(val name:String,val group:String,val action:()->Unit)
    override fun onCreate(b:Bundle?){super.onCreate(b);token=intent.getStringExtra("access_token");show()}
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun text(s:String,size:Float=14f,color:Int=ink,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);setPadding(dp(4),dp(7),dp(4),dp(7));if(bold)typeface=Typeface.DEFAULT_BOLD;setLineSpacing(0f,1.12f)}
    private fun button(s:String,c:()->Unit)=Button(this).apply{text=s;textSize=14f;isAllCaps=false;setTextColor(white);backgroundTintList=ColorStateList.valueOf(green);minHeight=dp(50);setOnClickListener{c()};layoutParams=LinearLayout.LayoutParams(-1,dp(50)).apply{setMargins(0,dp(4),0,dp(4))}}
    private fun native(c:Class<*>,label:String){remember(label);startActivity(Intent(this,c).apply{putExtra("access_token",token)})}
    private fun remember(label:String){val old=prefs.getStringSet("recent",emptySet())?.toMutableList()?: mutableListOf();old.remove(label);old.add(0,label);while(old.size>5)old.removeAt(old.lastIndex);prefs.edit().putStringSet("recent",old.toSet()).apply()}
    private fun show(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(cream);setPadding(dp(16),dp(14),dp(16),dp(18))}
        val scroll=ScrollView(this).apply{isFillViewport=true;addView(root)}
        root.addView(text("METHODIST THEOLOGICAL INSTITUTE · UMUAHIA",12f,gold,true));root.addView(text("Global Workspace Launcher",27f,ink,true));root.addView(text("Find an existing management workspace quickly. Recent items are stored only on this device for convenience; they are not an institutional audit log."))
        search=EditText(this).apply{hint="Search workspaces…";singleLine=true;setPadding(dp(12),0,dp(12),0)};root.addView(search,LinearLayout.LayoutParams(-1,dp(54)).apply{setMargins(0,dp(8),0,dp(8))})
        val recentBox=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(recentBox);renderRecent(recentBox)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};root.addView(list);renderItems()
        search.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){};override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){renderItems()};override fun afterTextChanged(e:android.text.Editable?){} })
        root.addView(text("Architecture boundary: this launcher only routes to existing native activities. Existing Supabase Auth, RLS, roles, RPCs and authoritative web workspaces remain unchanged.",12f,ink))
        setContentView(scroll)
    }
    private fun renderRecent(box:LinearLayout){box.removeAllViews();val recent=prefs.getStringSet("recent",emptySet())?.toList()?:emptyList();if(recent.isEmpty())return;box.addView(text("RECENT ON THIS DEVICE",12f,gold,true));recent.forEach{label->box.addView(text("• $label",13f,ink))}}
    private fun renderItems(){list.removeAllViews();val q=search.text.toString().trim().lowercase();val items=workspaceItems().filter{q.isBlank()||it.name.lowercase().contains(q)||it.group.lowercase().contains(q)};var group="";items.forEach{item->if(item.group!=group){group=item.group;list.addView(text(group.uppercase(),12f,gold,true))};list.addView(button(item.name){item.action()})};if(items.isEmpty())list.addView(text("No matching management workspace found."))}
    private fun workspaceItems()=listOf(
        Item("Applicant & Selection Review","Admissions"){native(ManagementApplicantSelectionActivity::class.java,"Applicant & Selection Review")},
        Item("Admission Activation & Onboarding","Admissions"){native(ManagementAdmissionActivationActivity::class.java,"Admission Activation & Onboarding")},
        Item("Student Registry & Lifecycle","Admissions"){native(ManagementStudentLifecycleActivity::class.java,"Student Registry & Lifecycle")},
        Item("SUG & Student Leadership","Student Life"){native(ManagementSugActivity::class.java,"SUG & Student Leadership")},
        Item("Hostel & Student Services","Student Life"){native(ManagementHostelActivity::class.java,"Hostel & Student Services")},
        Item("Academic Administration","Academic"){native(ManagementAcademicActivity::class.java,"Academic Administration")},
        Item("Teaching Load","Academic"){native(ManagementTeachingLoadActivity::class.java,"Teaching Load")},
        Item("Result Review","Academic"){native(ManagementResultReviewActivity::class.java,"Result Review")},
        Item("Academic Records & Transcripts","Academic"){native(ManagementAcademicRecordsActivity::class.java,"Academic Records & Transcripts")},
        Item("Attendance Monitoring","Academic"){native(ManagementAttendanceMonitoringActivity::class.java,"Attendance Monitoring")},
        Item("Academic Calendar & Scheduling","Academic"){native(ManagementCalendarActivity::class.java,"Academic Calendar & Scheduling")},
        Item("Examination Number Registry","Academic"){native(ManagementExamRegistryActivity::class.java,"Examination Number Registry")},
        Item("Online Classroom","Digital Learning"){native(ManagementOnlineClassroomActivity::class.java,"Online Classroom")},
        Item("Learning Materials & Digital Library","Digital Learning"){native(ManagementLearningMaterialsActivity::class.java,"Learning Materials & Digital Library")},
        Item("Communications & Notices","Communications"){native(ManagementCommunicationsActivity::class.java,"Communications & Notices")},
        Item("Notifications & Operational Alerts","Communications"){native(ManagementNotificationsActivity::class.java,"Notifications & Operational Alerts")},
        Item("Finance & Payment Administration","Finance & Records"){native(ManagementFinanceActivity::class.java,"Finance & Payment Administration")},
        Item("Document & Records Administration","Finance & Records"){native(ManagementRecordsActivity::class.java,"Document & Records Administration")},
        Item("Institutional Reporting","Executive"){native(ManagementReportingActivity::class.java,"Institutional Reporting")},
        Item("Audit, Security & Activity Monitoring","Security"){native(ManagementSecurityActivity::class.java,"Audit, Security & Activity Monitoring")},
        Item("Admission & SUG Controls","Security"){native(ManagementControlsActivity::class.java,"Admission & SUG Controls")},
        Item("Management Search","Navigation"){native(ManagementSearchActivity::class.java,"Management Search")},
        Item("Management Command Centre","Authoritative Web"){remember("Management Command Centre");startActivity(Intent(Intent.ACTION_VIEW,android.net.Uri.parse(getString(R.string.mti_base_url).trimEnd('/')+"/management-dashboard")))}
    )
}
