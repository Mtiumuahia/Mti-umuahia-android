# MTI Android V312 — Proper Pre-Build Audit & Corrections

## Baseline audited
- Package: `ng.org.mtiumuahia.app`
- Version: `312 / 9.8.0` in `app/build.gradle.kts`
- Compile/target SDK: 35
- Minimum SDK: 24
- AGP: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- Supabase project: existing MTI project; no new backend architecture introduced
- AI endpoint: existing production Netlify function `nimble-faun-2c7fb5.netlify.app/.netlify/functions/mti-assistant`

## Findings

### 1. Release metadata mismatch — corrected
`app/build.gradle.kts` correctly declares `versionCode = 312` and `versionName = "9.8.0"`, but `ManagementSystemInfoActivity.kt` displayed an unrelated hard-coded `Version 6.8.0 • Build 279`. This was a real source inconsistency. The screen now reads Android package metadata at runtime, so the displayed version cannot drift from the APK metadata.

### 2. GitHub Actions could build the wrong repository state — hardened
The workflow previously verified that files existed but did not verify the version before building and did not inspect the generated APK. It could therefore produce an APK from whatever source was actually checked out by GitHub Actions. V312 now verifies the source metadata before compilation and verifies the generated APK package metadata after compilation. The artifact name is also unique to V312/9.8.0.

### 3. Old website URL remains in resource aliases — not changed
`strings.xml` still contains `https://startling-klepon-ce7270.netlify.app` for `mti_base_url` and `base_url`. The current deployed website URL is not established by this ZIP itself, so it was not replaced with an invented URL. This should be updated only when the confirmed current MTI website domain is available. The AI endpoint is separate and correctly points to the confirmed `nimble-faun-2c7fb5` function.

### 4. Supabase publishable key — no secret exposure found
The app contains the Supabase publishable key in multiple activities and resources. This is client-side configuration and is not an OpenAI/service-role secret. No `OPENAI_API_KEY`, service-role key, or `sk-...` secret was found in the Android source inspected.

### 5. Public-content SQL — reviewed
`MTI-V307-PUBLIC-CONTENT-ACCESS.sql` is internally consistent: its gallery photo policy is applied to `gallery_photos`, and leadership policy is applied to `leadership`. No correction was required in that file.

### 6. Android security boundary — preserved
The manifest has only Internet and network-state permissions, backup is disabled, cleartext traffic is disabled, `MainActivity` is the only exported activity, and internal portal/management activities are non-exported. No new privileged Android surface was introduced.

### 7. AI secret boundary — preserved
The Android app sends requests to the existing Netlify function. The OpenAI secret is not bundled in the Android source.

### 8. Kotlin source structural check
All inspected Kotlin files have balanced parentheses; the V312 `PublicContentActivity.kt` brace/parenthesis issues previously reported by GitHub Actions were corrected. A full Android compilation is intentionally not claimed here because the provided package does not include the Gradle wrapper JAR and this environment does not provide the full Android build toolchain. GitHub Actions remains the authoritative compile gate.

## Remaining verification after upload
1. Replace the GitHub repository root with the contents of this V312 package.
2. Run the same GitHub Actions workflow.
3. Require the workflow step **Verify generated APK metadata** to pass.
4. Download only `MTI-Umuahia-debug-apk-V312-9.8.0-VERIFIED`.
5. In the app, open Management → About/System Information and confirm `Version 9.8.0 • Build 312`.

## Scope discipline
No Supabase tables, policies, RPCs, storage buckets, authentication architecture, admissions logic, or institutional data model were recreated or replaced by this V312 correction.
