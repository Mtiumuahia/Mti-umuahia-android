# MTI Android V308 — AI Backend Connection Amendment

V308 continues from V307. It does not rebuild the Android app.

Changes:
- Updated the native Android Ask MTI endpoint to the currently deployed MTI Netlify site: `https://ble-faun-2c7fb5.netlify.app/.netlify/functions/mti-assistant`.
- Updated the request body from the old standalone backend format (`message` + `history`) to the deployed MTI website backend format (`messages`).
- Preserved the existing V307 UI, Supabase integration, navigation, Community implementation, and public-content implementation.
- Version code: 308
- Version name: 9.4.0

No OpenAI API key is included in the Android project.
