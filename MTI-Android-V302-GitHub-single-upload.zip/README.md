# MTI Umuahia Android V302 — GitHub Cloud Build Package

This package is designed for phone-only GitHub setup. The Android source is kept as a ZIP because GitHub's web uploader does not unpack ZIP archives. The supplied workflow extracts the source in the GitHub Actions runner and builds the debug APK with Java 21, Gradle 8.9, Android SDK 35, AGP 8.7.3, and Kotlin 2.0.21.

Create `.github/workflows/build-apk.yml` in the repository using the contents of `GITHUB-WORKFLOW.yml`, then run the workflow from GitHub Actions.
